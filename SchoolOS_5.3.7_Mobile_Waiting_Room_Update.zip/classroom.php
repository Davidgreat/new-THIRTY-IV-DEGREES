<?php
if(!defined('SCHOOLOS_EXPERIENCE')){http_response_code(404);exit;}
function px_live_scope(array $u,int $id,bool $join=false):array{$r=q('SELECT l.*,s.name subject,c.name class_name FROM px_live l JOIN classes c ON c.id=l.class_id AND c.tenant_id=l.tenant_id AND c.session_name=l.session_name JOIN subjects s ON s.id=l.subject_id AND s.tenant_id=l.tenant_id WHERE l.tenant_id=? AND l.id=?',[$u['tenant_id'],$id])->fetch();if(!$r)throw new RuntimeException('Live lesson unavailable.');if($u['role']==='student'){$s=lp_student($u);if((int)$s['class_id']!==(int)$r['class_id']||$s['session_name']!==$r['session_name'])throw new RuntimeException('This lesson is outside your class and current session.');}elseif($u['role']==='teacher'){if((int)$r['teacher_id']!==(int)$u['id'])throw new RuntimeException('Only your own live lessons are available.');lp_scope($u,(int)$r['class_id'],(int)$r['subject_id'],$r['session_name']);}elseif($u['role']!=='school_admin')throw new RuntimeException('Teacher or learner access required.');if($join&&(in_array($r['status'],['ended','cancelled','archived','paused'],true)||strtotime($r['ends_at'])<=time()||strtotime($r['starts_at'])>time()+900))throw new RuntimeException('This lesson is outside its joining window.');return $r;}
function px_live_create(array $u):string{if(!in_array($u['role'],['teacher','school_admin'],true))throw new RuntimeException('Teacher required.');$class=(int)xp_text('class_id',20);$subject=(int)xp_text('subject_id',20);$a=lp_scope($u,$class,$subject);$start=lp_datetime(xp_text('starts_at',16));$duration=xp_text('duration_minutes',3,false);if($duration!==''&&(!ctype_digit($duration)||(int)$duration<30||(int)$duration>240||(int)$duration%30!==0))throw new RuntimeException('Choose a duration in 30-minute steps, up to four hours.');$end=$duration!==''&&$start?date('Y-m-d H:i:s',strtotime($start)+(int)$duration*60):lp_datetime(xp_text('ends_at',16));if(!$start||!$end||$end<=$start||strtotime($end)<=time()||strtotime($end)-strtotime($start)>14400)throw new RuntimeException('Choose a valid lesson window of up to four hours.');$provider=xp_text('provider',20);if(!in_array($provider,['schoolos','zoom','meet'],true))throw new RuntimeException('Choose a supported classroom provider.');$url=xp_text('join_url',1000,false);if($provider!=='schoolos'){$parts=parse_url($url);$host=strtolower($parts['host']??'');if(($parts['scheme']??'')!=='https'||isset($parts['user'])||isset($parts['pass'])||isset($parts['port'])||($provider==='meet'?$host!=='meet.google.com':!preg_match('/(^|\.)zoom\.us$/D',$host)))throw new RuntimeException('Use an HTTPS invitation URL from the selected Zoom or Google Meet provider.');}else $url=null;q('INSERT INTO px_live(tenant_id,teacher_id,class_id,subject_id,session_name,title,provider,join_url,starts_at,ends_at) VALUES(?,?,?,?,?,?,?,?,?,?)',[$u['tenant_id'],$u['id'],$class,$subject,$a['session_name'],xp_text('title',180),$provider,$url,$start,$end]);audit('learning.live.created');return 'Live lesson scheduled for the allocated class.';}
function px_live_join_impl(array $u,int $id):array{xp_rate('live-join-'.$u['id'],10,5);return xp_tx(function()use($u,$id){q('SELECT id FROM px_live WHERE tenant_id=? AND id=? FOR UPDATE',[$u['tenant_id'],$id]);$r=px_live_scope($u,$id,true);if($r['provider']!=='schoolos')throw new RuntimeException('Open the lesson provider invitation instead.');q("DELETE FROM px_signals WHERE tenant_id=? AND created_at<DATE_SUB(NOW(),INTERVAL 15 MINUTE) AND kind IN ('offer','answer','ice') LIMIT 500",[$u['tenant_id']]);$host=(int)$r['teacher_id']===(int)$u['id'];if(!$host&&$u['role']!=='student')throw new RuntimeException('Only the scheduled host or allocated learners may join.');if(!$host&&!px_live_host_ready($r))return px_live_waiting($r);$count=(int)g('SELECT COUNT(*) FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id<>? AND last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND)',[$u['tenant_id'],$id,$u['id']]);$transport=$r['join_url']??'';if($host&&$r['status']==='scheduled'&&$count===0)$transport='';if(!in_array($transport,['schoolos:sfu','schoolos:p2p'],true)){$transport=px_sfu_config((int)$u['tenant_id'])?'schoolos:sfu':'schoolos:p2p';if($host){q('UPDATE px_live SET join_url=? WHERE tenant_id=? AND id=?',[$transport,$u['tenant_id'],$id]);$r['join_url']=$transport;}}if($transport==='schoolos:p2p'&&$count>=8)throw new RuntimeException('This fallback broadcast supports eight participants. Ask the Platform Super Admin to connect the full-class media server for all schools.');if($host&&$r['status']==='scheduled')px_room_reset($r);if($host)q('UPDATE px_live SET status=? WHERE tenant_id=? AND id=?',['starting',$u['tenant_id'],$id]);$key=bin2hex(random_bytes(16));q('INSERT INTO px_peers(tenant_id,lesson_id,user_id,peer_key,last_seen) VALUES(?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE peer_key=VALUES(peer_key),last_seen=NOW()',[$u['tenant_id'],$id,$u['id'],$key]);$ice=[];$relay=px_turn_config((int)$u['tenant_id']);$url=$relay['url']??'';$secret=$relay['secret']??'';if($url&&$secret){$username=(time()+3600).':schoolos-'.$u['tenant_id'].'-'.$u['id'];$ice[]=['urls'=>$url,'username'=>$username,'credential'=>base64_encode(hash_hmac('sha1',$username,$secret,true))];}return ['key'=>$key,'host'=>$host,'hostId'=>(int)$r['teacher_id'],'userId'=>(int)$u['id'],'title'=>$r['title'],'endsAt'=>strtotime($r['ends_at'])*1000,'iceServers'=>$ice,'relayConfigured'=>(bool)$ice,'lesson'=>$id]+($transport==='schoolos:sfu'?px_sfu_join($u,$r,$host):['transport'=>'p2p']);});}
function px_peer(array $u,int $id,string $key):array{$r=px_live_scope($u,$id,true);if($r['status']!=='live')throw new RuntimeException('The broadcast has stopped. Join again when your teacher restarts it.');$p=q('SELECT * FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=? AND last_seen>DATE_SUB(NOW(),INTERVAL 45 SECOND)',[$u['tenant_id'],$id,$u['id'],$key])->fetch();if(!$p)throw new RuntimeException('Classroom session expired. Please join again.');q('UPDATE px_peers SET last_seen=NOW() WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=?',[$u['tenant_id'],$id,$u['id'],$key]);return $r;}
function px_live_poll(array $u,int $id,string $key,int $after):array{$r=px_peer($u,$id,$key);if(($r['join_url']??'')==='schoolos:sfu'){if((int)$u['id']!==(int)$r['teacher_id']&&!g('SELECT user_id FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND)',[$u['tenant_id'],$id,$r['teacher_id']]))throw new RuntimeException('Your teacher has disconnected. Rejoin when the broadcast resumes.');return ['peers'=>[],'signals'=>[],'status'=>$r['status'],'hostId'=>(int)$r['teacher_id']]+px_room_snapshot($u,$r);}$peers=q('SELECT p.user_id,p.peer_key,u.name FROM px_peers p JOIN users u ON u.id=p.user_id AND u.tenant_id=p.tenant_id AND u.active=1 WHERE p.tenant_id=? AND p.lesson_id=? AND p.last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND) AND p.user_id<>?',[$u['tenant_id'],$id,$u['id']])->fetchAll();$signals=q('SELECT id,from_user,from_key,kind,payload FROM px_signals WHERE tenant_id=? AND lesson_id=? AND to_user=? AND to_key=? AND id>? AND created_at>DATE_SUB(NOW(),INTERVAL 2 MINUTE) ORDER BY id LIMIT 100',[$u['tenant_id'],$id,$u['id'],$key,max(0,$after)])->fetchAll();return ['peers'=>$peers,'signals'=>$signals,'status'=>$r['status'],'hostId'=>(int)$r['teacher_id']]+px_room_snapshot($u,$r);}
function px_live_signal(array $u,int $id):void{$r=px_peer($u,$id,xp_text('key',32));if(($r['join_url']??'')==='schoolos:sfu')throw new RuntimeException('This classroom uses the media server for signalling.');$to=(int)xp_text('to',20);$target=q('SELECT * FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=? AND last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND)',[$u['tenant_id'],$id,$to,xp_text('to_key',32)])->fetch();if(!$target||$to===(int)$u['id']||((int)$u['id']!==(int)$r['teacher_id']&&$to!==(int)$r['teacher_id']))throw new RuntimeException('Signal recipient is outside this classroom relationship.');$kind=xp_text('kind',12);if(!in_array($kind,['offer','answer','ice'],true)||($kind==='offer'&&(int)$u['id']!==(int)$r['teacher_id'])||($kind==='answer'&&(int)$u['id']===(int)$r['teacher_id']))throw new RuntimeException('Unsupported classroom signal.');$payload=xp_text('payload',120000);$decoded=json_decode($payload,true);if(!is_array($decoded)||($kind!=='ice'&&(($decoded['type']??'')!==$kind||!is_string($decoded['sdp']??null)))||($kind==='ice'&&!is_string($decoded['candidate']??null)))throw new RuntimeException('Invalid classroom signal.');xp_rate('classroom-signal-'.$u['id'],180,1);q('INSERT INTO px_signals(tenant_id,lesson_id,from_user,to_user,from_key,to_key,kind,payload) VALUES(?,?,?,?,?,?,?,?)',[$u['tenant_id'],$id,$u['id'],$to,xp_text('key',32),$target['peer_key'],$kind,$payload]);}
function px_live_card(array $u,array $r,bool $past):void {
 $own=(int)$r['teacher_id']===(int)$u['id'];$id=(int)$r['id'];$canResume=$own&&in_array($r['status'],['ended','paused'],true)&&strtotime($r['ends_at'])>time()&&strtotime($r['starts_at'])<=time()+900;
 echo '<article id="live-lesson-'.$id.'" class="px-live-card"><span class="px-badge">'.e(px_live_label($u,$r)).' · '.e($r['status']).'</span><h3>'.e($r['title']).'</h3><p>'.e($r['class_name'].' · '.$r['subject']).'</p><time>'.e(date('D, j M · H:i',strtotime($r['starts_at']))).' – '.e(date('H:i',strtotime($r['ends_at']))).' WAT</time><p class="px-class-countdown" data-class-start="'.(strtotime($r['starts_at'])*1000).'" data-class-end="'.(strtotime($r['ends_at'])*1000).'" data-class-status="'.e($r['status']).'">'.e($past?'Past lesson':'Scheduled lesson').'</p><div class="px-card-actions">';
 if(!$past){try{px_live_scope($u,$id,true);if($r['provider']==='schoolos')echo '<button type="button" class="btn px-join" data-live-join="'.$id.'">'.($own?'Start / resume classroom':'Join classroom').' →</button>';else echo '<a class="btn" href="'.e($r['join_url']).'" target="_blank" rel="noopener noreferrer">Join '.e($r['provider']).' ↗</a>';}catch(Throwable){echo '<p>'.e($r['status']==='paused'?'Paused — your teacher can resume this lesson.':'Joining opens 15 minutes before the scheduled start.').'</p>';}}
 if($canResume)px_form('live_resume','Reactivate lesson',['lesson_id'=>$id]);
 if($own&&$r['status']!=='archived'){
  if(!$past&&$r['status']!=='paused')px_form('live_pause','Pause lesson',['lesson_id'=>$id]);
  if(!$past)px_form('live_end','End this session',['lesson_id'=>$id]);
  echo '<details class="px-close-confirm"><summary>Permanently close…</summary><p>This moves the lesson to Past lessons for everyone. It cannot be reactivated.</p>';px_form('live_archive','Confirm permanent close',['lesson_id'=>$id]);echo '</details>';
 }elseif(!$own&&$past&&$r['status']!=='archived')px_form('live_hide','Dismiss from my list',['lesson_id'=>$id]);
 echo '</div></article>';
}
function px_live_view(array $u):void {
 $intro=match($u['role']){
  'teacher'=>['YOUR LIVE TEACHING STUDIO','Room to teach.','Your classes, your learners, your lesson plan. Lead the conversation and keep each lesson together.'],
  'student'=>['YOUR LIVE LEARNING ROOM','Room to learn.','Your teacher, your classmates, your next discovery. Join your class and keep your questions and activities here.'],
  'school_admin'=>['YOUR SCHOOL’S LIVE CLASSROOMS','Room to connect.','Coordinate your school’s scheduled lessons and the live classes you lead.'],
  default=>['YOUR CLASSROOM WORKSPACE','Your scheduled lessons.','Open the classroom activities available to your account.']
 };
 echo '<section class="px-live px-studio"><header class="px-studio-hero"><span class="px-kicker">'.e($intro[0]).'</span><h2>'.e($intro[1]).'</h2><p>'.e($intro[2]).'</p><span class="px-studio-pill">✦ SchoolOS Learning Studio · WAT</span></header>';
 if(!px_ready()){echo '<p>Ask your school administrator to activate Portal Experience.</p></section>';return;}
 $host=in_array($u['role'],['teacher','school_admin'],true);
 if($host){echo '<details class="px-composer"><summary>＋ Schedule a live lesson</summary><form method="post" class="lp-form"><input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'"><input type="hidden" name="px_action" value="live_create">';lp_class_fields($u);lp_input('title','What will we learn?');lp_select('provider','Classroom',['schoolos'=>'SchoolOS Live · built-in classroom','meet'=>'Google Meet invitation link','zoom'=>'Zoom invitation link']);lp_input('join_url','Zoom / Meet invitation (external providers only)','url','',false);lp_input('starts_at','Starts at · West Africa Time','datetime-local');$durations=[];for($m=30;$m<=240;$m+=30)$durations[(string)$m]=$m.' minutes';lp_select('duration_minutes','Lesson duration',$durations);lp_end('Schedule lesson');echo '<p>Choose a duration in 30-minute steps. External provider invitations open in their own meeting app.</p></details>';}
 $params=[$u['tenant_id']];$where='';if($u['role']==='teacher'){$where=' AND teacher_id=?';$params[]=$u['id'];}elseif($u['role']==='student'){$student=lp_student($u);$where=' AND class_id=? AND session_name=?';$params[]=$student['class_id'];$params[]=$student['session_name'];}$rows=q("SELECT id FROM px_live WHERE tenant_id=?".$where." ORDER BY (ends_at>NOW() AND status NOT IN ('ended','cancelled','archived')) DESC,starts_at DESC LIMIT 300",$params)->fetchAll();$current=[];$past=[];
 foreach($rows as $row){try{$r=px_live_scope($u,(int)$row['id']);}catch(Throwable){continue;}$finished=in_array($r['status'],['ended','cancelled','archived'],true)||strtotime($r['ends_at'])<=time();$hidden=(bool)g('SELECT user_id FROM xp_progress WHERE tenant_id=? AND user_id=? AND step=?',[$u['tenant_id'],$u['id'],'hide-live-'.$r['id']]);if($finished){if(!$hidden||($_GET['dismissed']??'')==='1')$past[]=$r;}else $current[]=$r;}
 usort($current,fn($a,$b)=>strcmp($a['starts_at'],$b['starts_at']));
 echo '<div class="px-section-heading"><h3>Live & coming up</h3><span>'.count($current).' lessons</span></div><div class="px-live-grid">';if(!$current)echo '<div class="px-studio-empty"><span>☀</span><h3>A little breathing room.</h3><p>Your next scheduled lesson will appear here.</p></div>';foreach($current as $r)px_live_card($u,$r,false);echo '</div>';
 echo '<details class="px-past-lessons"><summary>Past lessons <span>'.count($past).'</span></summary><p><a href="?s=learning&amp;view=live&amp;dismissed=1">Show dismissed lessons</a></p><p>Finished and permanently closed lessons are kept here so your learning space stays clear. Teachers can reactivate an ended session before its scheduled finish.</p><div class="px-live-grid">';foreach($past as $r)px_live_card($u,$r,true);echo '</div></details>';
 echo <<<'HTML'
<section class="px-video-stage px-learning-room" id="pxLiveStage" hidden aria-label="Live learning room">
 <header class="px-room-header"><div><span class="px-kicker">TOGETHER, IN THE MOMENT</span><h3 id="pxLiveTitle">Your learning room</h3></div><div><span id="pxRoomClock" role="timer"></span><button type="button" class="btn px-quiet" id="pxRoomFullscreen">Expand room ⛶</button></div></header>
 <div id="pxLiveStatus" role="status" aria-live="polite"></div>
 <div class="px-room-layout"><div class="px-room-main"><div class="px-video-canvas"><video id="pxLiveVideo" controls autoplay playsinline></video><div id="pxWaitingRoom" class="px-waiting-room" role="status" aria-live="polite" hidden><span class="px-waiting-symbol" aria-hidden="true">✦</span><h4 id="pxWaitingTitle">Waiting for your teacher</h4><p id="pxWaitingText">You’re in the right place. We’ll connect you automatically when your teacher starts.</p></div><span class="px-video-caption">SchoolOS · a space for discovery</span><div id="pxRoomReactions" aria-live="polite"></div></div><div id="pxRoomAudio"></div>
 <div class="px-room-toolbar"><button type="button" class="btn px-share" id="pxShareScreen" hidden>▣ Share screen</button><button type="button" class="btn px-quiet" id="pxTeacherMic" hidden>Mute my microphone</button><button type="button" class="btn px-quiet" id="pxStudentMic" hidden disabled>Microphone locked by teacher</button><button type="button" class="btn px-hand" id="pxRaiseHand" hidden aria-pressed="false">✋ Raise hand</button><button type="button" class="btn px-quiet" id="pxLiveLeave">Leave classroom</button><button type="button" class="btn px-pause" id="pxPauseClass" hidden>Ⅱ Pause class</button><button type="button" class="btn px-end" id="pxEndClass" hidden>■ End session</button></div>
 <div class="px-room-reaction-bar" aria-label="Class reactions"><span>A little encouragement</span><button type="button" data-room-reaction="clap" aria-label="Applause">👏</button><button type="button" data-room-reaction="yes" aria-label="I understand">👍</button><button type="button" data-room-reaction="heart" aria-label="Love this">💚</button><button type="button" data-room-reaction="confused" aria-label="Please explain">🤔</button></div>
 <p class="px-room-hint" id="pxRoomHint">Your microphone stays off until you choose to use it and your teacher allows it. No recording is performed.</p>
 <section id="pxTeacherFloor" class="px-floor-panel" hidden><strong>Guide the conversation</strong><div><button type="button" class="btn px-quiet" data-room-floor="listen">Listen mode · mute learners</button><button type="button" class="btn px-quiet" data-room-floor="all">Open discussion · allow everyone</button></div><p id="pxFloorStatus"></p></section>
 </div><aside class="px-room-side"><nav class="px-room-tabs" aria-label="Classroom panels"><button type="button" data-room-tab="discussion" aria-pressed="true">Discussion</button><button type="button" data-room-tab="people" aria-pressed="false">People <span id="pxPeopleCount">0</span></button><button type="button" data-room-tab="quiz" aria-pressed="false">Quick check</button></nav>
 <section data-room-panel="discussion"><div id="pxRoomMessages" class="px-room-messages" role="log" aria-live="polite" aria-relevant="additions"></div><form id="pxRoomSend"><label>Message type<select id="pxRoomMessageKind"><option value="chat">Class chat</option><option value="question">Ask a question</option></select></label><label for="pxRoomBody">Your message</label><textarea id="pxRoomBody" maxlength="1000" rows="3" required placeholder="Share a thought or ask a question…"></textarea><button class="btn px-join">Send to classroom →</button></form></section>
 <section data-room-panel="people" hidden><p id="pxSpeakingMode">Listen mode</p><p class="px-room-hint">Raised hands appear in order. The teacher can invite one learner to speak.</p><div id="pxRoomPeople"></div></section>
 <section data-room-panel="quiz" hidden><div id="pxRoomQuiz"><p>A quick check will appear here when your teacher shares one.</p></div><details id="pxQuizComposer" hidden><summary>＋ Create a quick check</summary><form id="pxRoomQuizForm"><label>Question<textarea name="question" maxlength="500" required></textarea></label><label>A<input name="choice_a" maxlength="160" required></label><label>B<input name="choice_b" maxlength="160" required></label><label>C (optional)<input name="choice_c" maxlength="160"></label><label>D (optional)<input name="choice_d" maxlength="160"></label><label>Correct answer<select name="correct"><option value="0">A</option><option value="1">B</option><option value="2">C</option><option value="3">D</option></select></label><button class="btn">Share quick check</button></form></details></section>
 </aside></div>
</section>
HTML;
 echo '<p class="px-connection-note">Built-in video uses your platform’s media service. Direct fallback supports eight participants and teacher audio only; student speaking needs full-class mode. External Meet/Zoom lessons use their provider’s controls. Browser microphone/screen permissions and provider capacity still apply.</p>';
 if($u['role']==='school_admin'&&px_platform_media_state()['policy']==='overrides'){echo '<details><summary>Optional school fallback relay override</summary><form method="post" class="lp-form"><input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'"><input type="hidden" name="px_action" value="live_settings">';lp_input('turn_url','TURN URL','text','',false);lp_input('turn_secret','Shared secret','password','',false);lp_end('Save school fallback relay');echo '</details>';}
 px_sfu_settings_view($u);echo '</section><script src="classroom.js?v=535" defer></script>';
}

function px_live_leave(array $u,int $id,string $key):void {
 xp_tx(function()use($u,$id,$key){
  $r=q('SELECT * FROM px_live WHERE tenant_id=? AND id=? FOR UPDATE',[$u['tenant_id'],$id])->fetch();
  if(!$r)return;
  $p=q('SELECT user_id FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=?',[$u['tenant_id'],$id,$u['id'],$key])->fetch();
  if(!$p)return;
  if((int)$r['teacher_id']===(int)$u['id']){
   if($r['status']==='starting'){try{px_sfu_close($u,$r);}catch(Throwable $e){error_log('SchoolOS unstarted media-room cleanup failed; no learners admitted.');}}else px_sfu_close($u,$r);
   q("UPDATE px_live SET status='scheduled' WHERE tenant_id=? AND id=? AND status IN ('live','starting')",[$u['tenant_id'],$id]);
   q('DELETE FROM px_peers WHERE tenant_id=? AND lesson_id=?',[$u['tenant_id'],$id]);
   q("DELETE FROM px_signals WHERE tenant_id=? AND lesson_id=? AND kind IN ('offer','answer','ice')",[$u['tenant_id'],$id]);
  }else q('DELETE FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=?',[$u['tenant_id'],$id,$u['id'],$key]);
 });
}

function px_sfu_config(int $tid):?array {
 $state=px_platform_media_state();
 if($state['policy']==='direct')return null;
 if($state['policy']==='overrides'&&op_has('sv_settings')&&px_media_school_override($tid))return px_school_sfu_config($tid);
 if($state['sfu'])return $state['sfu'];
 // Preserve pre-update school configuration until a platform policy is first saved.
 return $state['policy']==='inherit'?px_school_sfu_config($tid):null;
}
function px_sfu_room(int $tid,int $lesson):string{return 'schoolos-'.substr(hash_hmac('sha256',__DIR__.'|'.(string)g('SELECT DATABASE()').'|'.$tid.'|'.$lesson.'|'.(px_room_state(['tenant_id'=>$tid,'id'=>$lesson])['epoch']),v23key()),0,32);}
function px_sfu_jwt(array $config,string $identity,array $grant,int $expires):string {
 $b64=static fn(string $s):string=>rtrim(strtr(base64_encode($s),'+/','-_'),'=');
 $head=$b64(json_encode(['alg'=>'HS256','typ'=>'JWT'],JSON_THROW_ON_ERROR));
 $body=$b64(json_encode(['iss'=>$config['key'],'sub'=>$identity,'nbf'=>time()-5,'exp'=>$expires,'video'=>$grant],JSON_THROW_ON_ERROR));
 return $head.'.'.$body.'.'.$b64(hash_hmac('sha256',$head.'.'.$body,$config['secret'],true));
}
function px_sfu_join(array $u,array $lesson,bool $host):array {
 $config=px_sfu_config((int)$u['tenant_id']);if(!$config)throw new RuntimeException('The scheduled media server is not configured. Ask your school administrator.');
 $room=px_sfu_room((int)$u['tenant_id'],(int)$lesson['id']);
 $state=px_room_state($lesson);$speak=$host||px_room_can_speak($state,(int)$u['id']);$grant=['roomJoin'=>true,'room'=>$room,'canSubscribe'=>true,'canPublish'=>$speak,'canPublishData'=>false];if(!$host)$grant['canPublishSources']=['microphone'];
 if($host)$grant['canPublishSources']=['camera','microphone','screen_share','screen_share_audio'];
 return ['transport'=>'sfu','serverUrl'=>$config['url'],'token'=>px_sfu_jwt($config,'user-'.$u['id'],$grant,time()+120),'room'=>$room];
}
function px_sfu_close(array $u,array $lesson):void {
 if(($lesson['join_url']??'')!=='schoolos:sfu')return;
 $config=px_sfu_config((int)$u['tenant_id']);if(!$config)throw new RuntimeException('Restore your media server configuration before ending this broadcast.');
 $room=px_sfu_room((int)$u['tenant_id'],(int)$lesson['id']);$token=px_sfu_jwt($config,'schoolos-control',['roomAdmin'=>true,'roomCreate'=>true,'room'=>$room],time()+60);
 $url=preg_replace('~^wss:~','https:',$config['url']);
 $curl=curl_init(rtrim($url,'/').'/twirp/livekit.RoomService/DeleteRoom');
 curl_setopt_array($curl,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>10,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$token,'Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode(['room'=>$room],JSON_THROW_ON_ERROR)]);
 $data=curl_exec($curl);$status=(int)curl_getinfo($curl,CURLINFO_HTTP_CODE);curl_close($curl);
 if($data===false||($status!==200&&!($status===404&&(json_decode($data,true)['code']??'')==='not_found')))throw new RuntimeException('Media server did not confirm classroom shutdown. Check its connection and try End lesson again.');
}
function px_sfu_save_impl(array $u):string {
 if($u['role']!=='school_admin'||defined('SCHOOLOS_DEMO_MODE')||px_platform_media_state()['policy']!=='overrides')throw new RuntimeException('The Platform Super Admin manages the classroom service. School overrides are not enabled.');
 if(g("SELECT l.id FROM px_live l WHERE l.tenant_id=? AND l.provider='schoolos' AND l.ends_at>NOW() AND (l.status='live' OR (l.status='starting' AND EXISTS(SELECT 1 FROM px_peers p WHERE p.tenant_id=l.tenant_id AND p.lesson_id=l.id AND p.last_seen>DATE_SUB(NOW(),INTERVAL 45 SECOND)))) LIMIT 1",[$u['tenant_id']]))throw new RuntimeException('End active built-in broadcasts before changing the school media server.');
 $url=xp_text('sfu_url',500,false);$key=xp_text('sfu_key',150,false);$secret=xp_text('sfu_secret',500,false);
 if(!$url&&!$key&&!$secret)return 'Existing media server settings retained.';
 $parts=parse_url($url);$host=$parts['host']??'';
 if(($parts['scheme']??'')!=='wss'||!preg_match('/^[A-Za-z0-9.-]+$/D',$host)||isset($parts['user'])||isset($parts['pass'])||isset($parts['query'])||isset($parts['fragment'])||!in_array($parts['path']??'',['','/'],true)||!preg_match('/^[A-Za-z0-9_-]{3,150}$/D',$key)||strlen($secret)<24)throw new RuntimeException('Use your LiveKit WSS server URL, API key and API secret (at least 24 characters).');
 sv_save_secret((int)$u['tenant_id'],'classroom_sfu_url',rtrim($url,'/'));sv_save_secret((int)$u['tenant_id'],'classroom_sfu_key',$key);sv_save_secret((int)$u['tenant_id'],'classroom_sfu_secret',$secret);
 sv_save_secret((int)$u['tenant_id'],'classroom_sfu_override','1');px_media_invalidate();audit('learning.media_server.configured');return 'Full-class media server settings saved securely. Test a new lesson before inviting the class.';
}

function px_sfu_settings_view(array $u):void {
 if($u['role']!=='school_admin')return;
 $state=px_platform_media_state();$config=px_sfu_config((int)$u['tenant_id']);
 echo '<section class="px-media-config"><h3>Your classroom service</h3><p>'.($config&&$config['scope']==='platform'?'Managed centrally by the Platform Super Admin. Your school automatically uses the shared service; no separate provider account is required.':($config?'Existing school media server is available.':'Full-class service is not configured. Ask the Platform Super Admin to connect the platform server.')).'</p>';
 if($state['policy']==='overrides'){
 echo '<details><summary>Optional school media-server override</summary><p>The platform allows your school to use its own server. Leave this unset to inherit the shared platform service.</p><form method="post"><input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'"><input type="hidden" name="px_action" value="live_sfu_settings">';
 lp_input('sfu_url','LiveKit-compatible WSS URL','text','',false);lp_input('sfu_key','API key','text','',false);lp_input('sfu_secret','API secret (encrypted)','password','',false);lp_end('Save school override');px_form('live_sfu_inherit','Use central platform service');echo '</details>';
 }echo '</section>';
}
function px_sfu_save(array $u):string{return px_media_lock(fn()=>xp_tx(fn()=>px_sfu_save_impl($u)));}

function px_live_label(array $u,array $lesson):string {
 if($lesson['provider']!=='schoolos')return $lesson['provider'];
 $mode=$lesson['join_url']??'';
 $sfu=$mode==='schoolos:sfu'||($mode===''&&px_sfu_config((int)$u['tenant_id']));
 return $sfu?'SchoolOS Live · media server':'SchoolOS Live · direct fallback (8 people)';
}

function px_live_ready(array $u,int $id,string $key):array {
 return xp_tx(function()use($u,$id,$key){
  q('SELECT id FROM px_live WHERE tenant_id=? AND id=? FOR UPDATE',[$u['tenant_id'],$id]);
  $r=px_live_scope($u,$id,true);
  if((int)$r['teacher_id']!==(int)$u['id']||!in_array($r['join_url']??'',['schoolos:sfu','schoolos:p2p'],true)||!in_array($r['status'],['starting','live'],true)||!g('SELECT user_id FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=? AND last_seen>DATE_SUB(NOW(),INTERVAL 45 SECOND)',[$u['tenant_id'],$id,$u['id'],$key]))throw new RuntimeException('Host broadcast setup expired. Join again.');
  q("UPDATE px_live SET status='live' WHERE tenant_id=? AND id=?",[$u['tenant_id'],$id]);q('UPDATE px_peers SET last_seen=NOW() WHERE tenant_id=? AND lesson_id=? AND user_id=?',[$u['tenant_id'],$id,$u['id']]);
  return ['ready'=>true];
 });
}

function px_live_join(array $u,int $id):array{if(in_array($u['role'],['teacher','school_admin'],true))return px_media_lock(fn()=>px_live_join_impl($u,$id));return px_live_join_impl($u,$id);}

/** Platform-wide media configuration. Secrets stay in the current database's encrypted store. */
function px_media_invalidate():void{unset($GLOBALS['px_platform_media_cache']);}
function px_platform_media_state():array {
 global $pdo;
 $cacheId=spl_object_id($pdo).':'.(string)g('SELECT DATABASE()');
 if(isset($GLOBALS['px_platform_media_cache'][$cacheId]))return $GLOBALS['px_platform_media_cache'][$cacheId];
 $policy=xp_setting('classroom_media_policy','inherit');if(!in_array($policy,['inherit','central','overrides','direct'],true))throw new RuntimeException('Platform classroom policy is invalid. Contact the platform administrator.');
 $secrets=[];
 if(v23ready())foreach(q("SELECT name,cipher FROM v23_secrets WHERE name IN ('classroom_platform_sfu_url','classroom_platform_sfu_key','classroom_platform_sfu_secret','classroom_platform_turn_url','classroom_platform_turn_secret')") as $row){
  $raw=base64_decode($row['cipher'],true);if($raw===false||strlen($raw)<29)throw new RuntimeException('Platform media credential storage is invalid.');
  $plain=openssl_decrypt(substr($raw,28),'aes-256-gcm',v23key(),OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16));if($plain===false)throw new RuntimeException('Restore the matching private encryption key for platform media credentials.');
  $secrets[$row['name']]=$plain;
 }
 $url=$secrets['classroom_platform_sfu_url']??'';$key=$secrets['classroom_platform_sfu_key']??'';$secret=$secrets['classroom_platform_sfu_secret']??'';
 $sfu=null;if($url||$key||$secret){if(!$url||!$key||!$secret)throw new RuntimeException('The central media server configuration is incomplete. Ask the Platform Super Admin to complete it.');$sfu=['url'=>$url,'key'=>$key,'secret'=>$secret,'scope'=>'platform'];}
 $turnUrl=$secrets['classroom_platform_turn_url']??'';$turnSecret=$secrets['classroom_platform_turn_secret']??'';$turn=null;
 if($turnUrl||$turnSecret){if(!$turnUrl||!$turnSecret)throw new RuntimeException('The platform fallback relay configuration is incomplete.');$turn=['url'=>$turnUrl,'secret'=>$turnSecret,'scope'=>'platform'];}
 return $GLOBALS['px_platform_media_cache'][$cacheId]=['policy'=>$policy,'sfu'=>$sfu,'turn'=>$turn];
}
function px_media_school_override(int $tid):bool{return (string)g("SELECT cipher FROM sv_settings WHERE tenant_id=? AND setting_key='classroom_sfu_override'",[$tid])!==''&&(sv_secrets($tid)['classroom_sfu_override']??'')==='1';}
function px_school_sfu_config(int $tid):?array {
 $s=sv_secrets($tid);$url=$s['classroom_sfu_url']??'';$key=$s['classroom_sfu_key']??'';$secret=$s['classroom_sfu_secret']??'';
 if(!$url&&!$key&&!$secret)return null;if(!$url||!$key||!$secret)throw new RuntimeException('Your school media server configuration is incomplete.');
 return ['url'=>$url,'key'=>$key,'secret'=>$secret,'scope'=>'school'];
}
function px_turn_config(int $tid):?array {
 $state=px_platform_media_state();
 if($state['policy']==='overrides'&&op_has('sv_settings')&&px_media_school_override($tid)){$s=sv_secrets($tid);if(!empty($s['classroom_turn_url'])&&!empty($s['classroom_turn_secret']))return ['url'=>$s['classroom_turn_url'],'secret'=>$s['classroom_turn_secret'],'scope'=>'school'];}
 if($state['turn'])return $state['turn'];
 if($state['policy']==='inherit'){$s=sv_secrets($tid);if(!empty($s['classroom_turn_url'])&&!empty($s['classroom_turn_secret']))return ['url'=>$s['classroom_turn_url'],'secret'=>$s['classroom_turn_secret'],'scope'=>'legacy_school'];}
 return null;
}
function px_media_lock(callable $work):mixed {
 $name='schoolos-media-'.substr(hash('sha256',__DIR__.'|'.(string)g('SELECT DATABASE()')),0,30);
 if((int)g('SELECT GET_LOCK(?,5)',[$name])!==1)throw new RuntimeException('Classroom settings are busy. Try again shortly.');
 try{return $work();}finally{q('SELECT RELEASE_LOCK(?)',[$name]);}
}
function px_media_active(int $tid=0):int {
 if(!xp_has('px_live'))return 0;
 return (int)g("SELECT COUNT(*) FROM px_live l WHERE l.provider='schoolos' AND l.ends_at>NOW() AND (l.status='live' OR (l.status='starting' AND EXISTS(SELECT 1 FROM px_peers p WHERE p.tenant_id=l.tenant_id AND p.lesson_id=l.id AND p.last_seen>DATE_SUB(NOW(),INTERVAL 45 SECOND))))".($tid?' AND l.tenant_id=?':''),$tid?[$tid]:[]);
}
function px_media_validate_sfu(array $config):void {
 $parts=parse_url($config['url']);$host=$parts['host']??'';
 if(($parts['scheme']??'')!=='wss'||!preg_match('/^[A-Za-z0-9.-]+$/D',$host)||isset($parts['user'])||isset($parts['pass'])||isset($parts['query'])||isset($parts['fragment'])||!in_array($parts['path']??'',['','/'],true)||!preg_match('/^[A-Za-z0-9_-]{3,150}$/D',$config['key'])||strlen($config['secret'])<24)throw new RuntimeException('Use the LiveKit-compatible WSS server origin, API key and API secret (at least 24 characters). Self-hosted servers are supported; a paid cloud account is not required.');
}
function px_platform_media_save(array $u):string {
 if($u['role']!=='platform_super_admin'||defined('SCHOOLOS_DEMO_MODE'))throw new RuntimeException('Live Platform Super Admin access required.');
 $policy=xp_text('media_policy',20);if(!in_array($policy,['central','overrides','direct'],true))throw new RuntimeException('Choose a valid platform classroom policy.');
 $url=xp_text('sfu_url',500,false);$key=xp_text('sfu_key',150,false);$secret=xp_text('sfu_secret',500,false);$turnUrl=xp_text('turn_url',500,false);$turnSecret=xp_text('turn_secret',500,false);
 return px_media_lock(function()use($u,$policy,$url,$key,$secret,$turnUrl,$turnSecret){
  $active=px_media_active();if($active)throw new RuntimeException('End the '.$active.' active built-in broadcast(s) across all schools before changing shared media settings.');
  $previous=px_platform_media_state();$old=$previous['sfu'];$next=['url'=>$url?:($old['url']??''),'key'=>$key?:($old['key']??''),'secret'=>$secret?:($old['secret']??'')];
  if($url||$key||$secret||$policy!=='direct'){
   if(($url&&$url!==($old['url']??''))||($key&&$key!==($old['key']??'')))if(!$secret)throw new RuntimeException('Re-enter the API secret when changing the server URL or API key.');
   px_media_validate_sfu($next);
  }
  if($turnUrl||$turnSecret)if(!preg_match('~^turns?:[a-zA-Z0-9.-]+:[0-9]{2,5}(\?transport=(udp|tcp))?$~D',$turnUrl)||strlen($turnSecret)<20)throw new RuntimeException('Enter both the fallback TURN URL and its shared secret of at least 20 characters, or leave both blank to keep existing relay settings.');
  xp_tx(function()use($policy,$url,$key,$secret,$next,$turnUrl,$turnSecret){
   if($url||$key||$secret)foreach(['url','key','secret'] as $field)v23save('classroom_platform_sfu_'.$field,$field==='url'?rtrim($next[$field],'/'):$next[$field]);
   if($turnUrl&&$turnSecret){v23save('classroom_platform_turn_url',$turnUrl);v23save('classroom_platform_turn_secret',$turnSecret);}
   q("INSERT INTO xp_config(name,value) VALUES('classroom_media_policy',?) ON DUPLICATE KEY UPDATE value=VALUES(value)",[$policy]);
   q("DELETE FROM xp_config WHERE name='classroom_media_last_test'");
   audit('learning.platform_media.saved','platform',$policy);
  });px_media_invalidate();
  return $policy==='direct'?'Platform classroom policy saved. Full-class media-server mode is disabled; direct fallback and external invitations remain available.':'Central classroom configuration saved. All live schools inherit it automatically unless you explicitly enabled and a school selected an override. No paid media subscription was created.';
 });
}
function px_platform_media_test(array $u):string {
 if($u['role']!=='platform_super_admin'||defined('SCHOOLOS_DEMO_MODE'))throw new RuntimeException('Live Platform Super Admin access required.');
 $state=px_platform_media_state();$config=$state['sfu'];if(!$config)throw new RuntimeException('Save the central media server credentials first.');
 $token=px_sfu_jwt($config,'schoolos-platform-check',['roomList'=>true],time()+60);$url=preg_replace('~^wss:~','https:',$config['url']);
 $curl=curl_init(rtrim($url,'/').'/twirp/livekit.RoomService/ListRooms');$body='';
 curl_setopt_array($curl,[CURLOPT_POST=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>10,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$token,'Content-Type: application/json'],CURLOPT_POSTFIELDS=>'{}',CURLOPT_WRITEFUNCTION=>function($handle,$chunk)use(&$body){if(strlen($body)+strlen($chunk)>262144)return 0;$body.=$chunk;return strlen($chunk);}]);
 $ok=curl_exec($curl);$status=(int)curl_getinfo($curl,CURLINFO_HTTP_CODE);curl_close($curl);$data=json_decode($body,true);
 if($ok===false||$status!==200||!is_array($data)||!is_array($data['rooms']??null))throw new RuntimeException('The central media API test failed. Check the WSS origin, TLS certificate, API key/secret and server access. No classroom was created.');
 q("INSERT INTO xp_config(name,value) VALUES('classroom_media_last_test',?) ON DUPLICATE KEY UPDATE value=VALUES(value)",[date('Y-m-d H:i:s')]);audit('learning.platform_media.tested','platform');
 return 'Central media API connection verified. This read-only test did not create a room. Test real camera/audio on separate networks before inviting schools.';
}
function px_school_media_override(array $u):string {
 if($u['role']!=='school_admin'||defined('SCHOOLOS_DEMO_MODE')||px_platform_media_state()['policy']!=='overrides')throw new RuntimeException('The Platform Super Admin manages the classroom service. School overrides are not enabled.');
 return px_media_lock(function()use($u){if(px_media_active((int)$u['tenant_id']))throw new RuntimeException('End your school broadcasts before changing its media source.');q("DELETE FROM sv_settings WHERE tenant_id=? AND setting_key='classroom_sfu_override'",[$u['tenant_id']]);audit('learning.school_media.inherit');return 'Your school now uses the central platform media server.';});
}
function px_platform_media_view(array $u):void {
 if($u['role']!=='platform_super_admin')return;
 $state=px_platform_media_state();$last=xp_setting('classroom_media_last_test');
 echo '<section class="xp-panel" id="platformLiveClassrooms"><span class="xp-eyebrow">ONE PLATFORM. EVERY SCHOOL.</span><h2>Platform live classrooms</h2><p>Configure one LiveKit-compatible media server for all live schools. Self-hosted LiveKit is free software and uses server capacity/bandwidth you provide. A paid LiveKit Cloud subscription is optional. Schools do not need separate provider accounts or credentials. Each school retains separate lesson rooms and enrollment checks.</p><p>Central server: <strong>'.($state['sfu']?'credentials saved':'not configured').'</strong> · Policy: '.e($state['policy']).'. '.($last?'Last API check: '.e($last).' WAT.':'No saved API check.').'</p>';
 xp_form('platform_media_save','Save platform classroom settings',[
  'media_policy'=>['Media policy',['central'=>'Shared server for every school (recommended)','overrides'=>'Shared server; allow optional school overrides','direct'=>'Disable media-server mode; keep direct/external options'],$state['policy']==='inherit'?'central':$state['policy']],
  'sfu_url'=>['WSS origin, for example wss://live.yourplatform.ng (blank keeps saved)','text','',false],
  'sfu_key'=>['API key (blank keeps saved)','text','',false],
  'sfu_secret'=>['API secret (encrypted; blank keeps saved)','password','',false],
  'turn_url'=>['Optional shared TURN URL for the direct fallback (blank keeps saved)','text','',false],
  'turn_secret'=>['Optional shared TURN secret for the direct fallback','password','',false]
 ]);
 echo '<p>End active built-in broadcasts across all schools before changing the policy or credentials. New classrooms inherit the shared service automatically. Changing an origin/key requires re-entering the secret. The optional direct-fallback TURN relay is separate from the media server’s own relay configuration.</p>';
 xp_form('platform_media_test','Test central media API');
 echo '<details><summary>Free options and shared hosting</summary><p>Self-hosted LiveKit has no software subscription charge. It requires a persistent media server, a trusted TLS certificate and open media ports; an ordinary shared cPanel account generally cannot run that service. A free hosted quota may support a small pilot but has limits. Google Meet invitations are already supported for external free meetings. Read the release research guide before choosing a provider; this update does not purchase infrastructure or promise unlimited free bandwidth.</p></details><p>The isolated public demo does not inherit live-platform credentials. Configure a dedicated demo service separately through the platform operator if needed.</p></section>';
}

/** Lesson-scoped collaboration. Existing tables, no schema changes. */
function px_room_key(array $r):string{return 'live_room_'.(int)$r['tenant_id'].'_'.(int)$r['id'];}
function px_room_state(array $r):array {
 $s=json_decode(xp_setting(px_room_key($r),'{}'),true);
 return (is_array($s)?$s:[])+['epoch'=>'','mode'=>'listen','speaker'=>0,'quiz'=>0,'quiz_closed'=>false];
}
function px_room_save(array $r,array $state):void {q('INSERT INTO xp_config(name,value) VALUES(?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',[px_room_key($r),json_encode($state,JSON_THROW_ON_ERROR)]);}
function px_room_reset(array $r):void {$s=px_room_state($r);$s['epoch']=bin2hex(random_bytes(8));$s['mode']='listen';$s['speaker']=0;px_room_save($r,$s);q('DELETE FROM xp_progress WHERE tenant_id=? AND step=?',[$r['tenant_id'],'hand-'.$r['id']]);}
function px_room_host(array $u,array $r):void{if((int)$u['id']!==(int)$r['teacher_id'])throw new RuntimeException('Only the scheduled teacher can control this classroom.');}
function px_live_lifecycle(array $u,int $id,string $op):array {
 return px_media_lock(fn()=>xp_tx(function()use($u,$id,$op){
 q('SELECT id FROM px_live WHERE tenant_id=? AND id=? FOR UPDATE',[$u['tenant_id'],$id]);$r=px_live_scope($u,$id);
 if($op==='hide'){
  if(!in_array($r['status'],['ended','cancelled','archived'],true)&&strtotime($r['ends_at'])>time())throw new RuntimeException('Only finished lessons can be dismissed.');
  q('INSERT IGNORE INTO xp_progress(tenant_id,user_id,step) VALUES(?,?,?)',[$u['tenant_id'],$u['id'],'hide-live-'.$id]);return ['message'=>'Lesson removed from your current list. Use Show dismissed lessons in Past lessons to find it again.'];
 }
 px_room_host($u,$r);
 if($op==='resume'){
  if(!in_array($r['status'],['ended','paused','scheduled'],true)||strtotime($r['ends_at'])<=time()||strtotime($r['starts_at'])>time()+900)throw new RuntimeException('Resume is available within this lesson’s joining window, before it is permanently closed.');
  px_sfu_close($u,$r);px_room_reset($r);q("UPDATE px_live SET status='scheduled',join_url=IF(provider='schoolos',NULL,join_url) WHERE tenant_id=? AND id=?",[$u['tenant_id'],$id]);
 }elseif(in_array($op,['pause','end','archive'],true)){
  if($r['status']==='archived')throw new RuntimeException('This lesson is permanently closed. Schedule a new lesson to teach again.');
  px_sfu_close($u,$r);px_room_reset($r);$status=match($op){'pause'=>'paused','end'=>'ended',default=>'archived'};
  q('UPDATE px_live SET status=? WHERE tenant_id=? AND id=?',[$status,$u['tenant_id'],$id]);
 }else throw new RuntimeException('Unknown classroom control.');
 q('DELETE FROM px_peers WHERE tenant_id=? AND lesson_id=?',[$u['tenant_id'],$id]);
 q("DELETE FROM px_signals WHERE tenant_id=? AND lesson_id=? AND kind IN ('offer','answer','ice')",[$u['tenant_id'],$id]);
 audit('learning.live.'.$op);return ['message'=>match($op){'pause'=>'Class paused. Resume and rejoin before its scheduled finish.','resume'=>'Lesson reactivated. Start the classroom so students can rejoin.','end'=>'Session ended. You can reactivate it within its scheduled window.','archive'=>'Lesson permanently closed and moved to Past lessons.'}];
 }));
}
function px_sfu_request(array $r,string $method,array $body):array {
 $config=px_sfu_config((int)$r['tenant_id']);if(!$config)throw new RuntimeException('Class media service is unavailable.');
 $grant=['roomAdmin'=>true,'room'=>px_sfu_room((int)$r['tenant_id'],(int)$r['id'])];
 $token=px_sfu_jwt($config,'schoolos-moderator',$grant,time()+60);
 $curl=curl_init(preg_replace('~^wss:~','https:',rtrim($config['url'],'/')).'/twirp/livekit.RoomService/'.$method);
 curl_setopt_array($curl,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>8,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$token,'Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode($body,JSON_THROW_ON_ERROR)]);
 $data=curl_exec($curl);$status=(int)curl_getinfo($curl,CURLINFO_HTTP_CODE);curl_close($curl);
 if($data===false||$status!==200)throw new RuntimeException('The media server did not confirm speaking permissions. Keep the class in listen mode and retry.');
 return json_decode($data,true,512,JSON_THROW_ON_ERROR);
}
function px_room_can_speak(array $s,int $uid):bool{return $s['mode']==='all'||($s['mode']==='speaker'&&(int)$s['speaker']===$uid);}
function px_room_permissions(array $r,array $s):void {
 if(($r['join_url']??'')!=='schoolos:sfu')throw new RuntimeException('Student microphones require the full-class media service. Chat, questions and reactions remain available in direct mode.');
 $room=px_sfu_room((int)$r['tenant_id'],(int)$r['id']);$list=px_sfu_request($r,'ListParticipants',['room'=>$room]);
 // Revoke everyone before granting a new speaker. Failures never grant a second speaker.
 $learners=[];foreach($list['participants']??[] as $p){if(($p['identity']??'')==='user-'.$r['teacher_id'])continue;$learners[]=$p['identity'];px_sfu_request($r,'UpdateParticipant',['room'=>$room,'identity'=>$p['identity'],'permission'=>['canSubscribe'=>true,'canPublish'=>false,'canPublishData'=>false,'canPublishSources'=>[2]]]);}
 foreach($learners as $identity){$id=(int)substr($identity,5);if(px_room_can_speak($s,$id))px_sfu_request($r,'UpdateParticipant',['room'=>$room,'identity'=>$identity,'permission'=>['canSubscribe'=>true,'canPublish'=>true,'canPublishData'=>false,'canPublishSources'=>[2]]]);}
}
function px_room_event(array $u,array $r,string $kind,array $payload,string $nonce=''):int {
 $nonce=$nonce?:bin2hex(random_bytes(16));if(!preg_match('/^[a-f0-9]{32}$/D',$nonce))throw new RuntimeException('Invalid message reference.');
 $found=g('SELECT id FROM px_signals WHERE tenant_id=? AND lesson_id=? AND from_user=? AND to_user=0 AND to_key=?',[$u['tenant_id'],$r['id'],$u['id'],$nonce]);if($found)return (int)$found;
 q('INSERT INTO px_signals(tenant_id,lesson_id,from_user,to_user,from_key,to_key,kind,payload) VALUES(?,?,?,0,?,?,?,?)',[$u['tenant_id'],$r['id'],$u['id'],$_POST['key']??'', $nonce,$kind,json_encode($payload,JSON_THROW_ON_ERROR)]);global $pdo;return (int)$pdo->lastInsertId();
}
function px_live_interact(array $u,int $id):array {
 xp_rate('live-interact-'.$u['id'],90,1);$op=xp_text('op',20);
 return xp_tx(function()use($u,$id,$op){
 q('SELECT id FROM px_live WHERE tenant_id=? AND id=? FOR UPDATE',[$u['tenant_id'],$id]);$r=px_peer($u,$id,xp_text('key',32));$s=px_room_state($r);$host=(int)$u['id']===(int)$r['teacher_id'];
 if(in_array($op,['chat','question'],true)){$body=xp_text('body',1000);px_room_event($u,$r,$op,['body'=>$body],xp_text('nonce',32));}
 elseif($op==='react'){$reaction=xp_text('reaction',12);if(!in_array($reaction,['clap','yes','heart','confused'],true))throw new RuntimeException('Choose a classroom reaction.');px_room_event($u,$r,'react',['reaction'=>$reaction],xp_text('nonce',32));}
 elseif($op==='hand'){if($host)throw new RuntimeException('Learners raise their hands.');$step='hand-'.$id;if(xp_text('raised',1)==='1')q('INSERT IGNORE INTO xp_progress(tenant_id,user_id,step) VALUES(?,?,?)',[$u['tenant_id'],$u['id'],$step]);else q('DELETE FROM xp_progress WHERE tenant_id=? AND user_id=? AND step=?',[$u['tenant_id'],$u['id'],$step]);}
 elseif($op==='floor'){
  px_room_host($u,$r);$mode=xp_text('mode',12);$speaker=(int)xp_text('speaker',20,false);if(!in_array($mode,['listen','all','speaker'],true))throw new RuntimeException('Choose a speaking mode.');
  if($mode==='speaker'&&!g('SELECT user_id FROM px_peers p JOIN users u ON u.id=p.user_id AND u.tenant_id=p.tenant_id AND u.role=\'student\' AND u.active=1 WHERE p.tenant_id=? AND p.lesson_id=? AND p.user_id=? AND p.last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND)',[$u['tenant_id'],$id,$speaker]))throw new RuntimeException('Select a student currently in this lesson.');
  $safe=$s;$safe['mode']='listen';$safe['speaker']=0;px_room_save($r,$safe);
  $next=$safe;$next['mode']=$mode;$next['speaker']=$mode==='speaker'?$speaker:0;
  try{px_room_permissions($r,$next);}catch(Throwable $e){try{px_room_permissions($r,$safe);}catch(Throwable){}return ['saved'=>false,'error'=>$e->getMessage()];}
  px_room_save($r,$next);if($speaker)q('DELETE FROM xp_progress WHERE tenant_id=? AND user_id=? AND step=?',[$u['tenant_id'],$speaker,'hand-'.$id]);
 }elseif($op==='quiz'){
  px_room_host($u,$r);$question=xp_text('question',500);$choices=[];foreach(['a','b','c','d'] as $choice){$v=xp_text('choice_'.$choice,160,$choice==='a'||$choice==='b');if($v!=='')$choices[]=$v;}$correct=(int)xp_text('correct',1);if($correct<0||$correct>=count($choices))throw new RuntimeException('Choose the correct answer.');
  $s['quiz']=px_room_event($u,$r,'quiz',['question'=>$question,'choices'=>$choices,'correct'=>$correct]);$s['quiz_closed']=false;px_room_save($r,$s);
 }elseif($op==='quiz_close'){px_room_host($u,$r);$s['quiz_closed']=true;px_room_save($r,$s);}
 elseif($op==='quiz_answer'){
  if($host||!$s['quiz']||$s['quiz_closed'])throw new RuntimeException('No open learner quiz.');$quiz=(int)xp_text('quiz',20);if($quiz!==(int)$s['quiz'])throw new RuntimeException('This quiz has changed.');
  $p=json_decode((string)g("SELECT payload FROM px_signals WHERE tenant_id=? AND lesson_id=? AND id=? AND kind='quiz'",[$u['tenant_id'],$id,$quiz]),true);$answer=(int)xp_text('answer',1);if(!isset($p['choices'][$answer]))throw new RuntimeException('Choose an available answer.');
  $nonce=substr(hash('sha256','quiz-'.$quiz.'-'.$u['id']),0,32);px_room_event($u,$r,'quiz_answer',['quiz'=>$quiz,'answer'=>$answer],$nonce);
 }else throw new RuntimeException('Unsupported classroom interaction.');
 return ['saved'=>true];
 });
}
function px_room_snapshot(array $u,array $r):array {
 $s=px_room_state($r);$host=(int)$u['id']===(int)$r['teacher_id'];
 $members=q('SELECT p.user_id,u.name,u.role,IF(x.user_id IS NULL,0,1) raised,x.completed_at raised_at FROM px_peers p JOIN users u ON u.id=p.user_id AND u.tenant_id=p.tenant_id AND u.active=1 LEFT JOIN xp_progress x ON x.tenant_id=p.tenant_id AND x.user_id=p.user_id AND x.step=? WHERE p.tenant_id=? AND p.lesson_id=? AND p.last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND) ORDER BY (x.user_id IS NOT NULL) DESC,x.completed_at,p.user_id LIMIT 1000',['hand-'.$r['id'],$u['tenant_id'],$r['id']])->fetchAll();
 $events=q("SELECT e.id,e.kind,e.from_user,u.name,e.payload,e.created_at FROM px_signals e JOIN users u ON u.id=e.from_user AND u.tenant_id=e.tenant_id WHERE e.tenant_id=? AND e.lesson_id=? AND e.to_user=0 AND e.kind IN ('chat','question','react') ORDER BY e.id DESC LIMIT 60",[$u['tenant_id'],$r['id']])->fetchAll();
 foreach($events as &$ev)$ev['payload']=json_decode($ev['payload'],true);unset($ev);
 $quiz=null;if($s['quiz']){
  $quiz=json_decode((string)g("SELECT payload FROM px_signals WHERE tenant_id=? AND lesson_id=? AND id=? AND kind='quiz'",[$u['tenant_id'],$r['id'],$s['quiz']]),true);
  if($quiz){$quiz['id']=(int)$s['quiz'];$quiz['closed']=(bool)$s['quiz_closed'];$quiz['myAnswer']=null;$quiz['counts']=array_fill(0,count($quiz['choices']),0);$quiz['responses']=0;
   $answers=q("SELECT from_user,payload FROM px_signals WHERE tenant_id=? AND lesson_id=? AND kind='quiz_answer' AND id>? ORDER BY id LIMIT 2000",[$u['tenant_id'],$r['id'],$s['quiz']])->fetchAll();foreach($answers as $answer){$a=json_decode($answer['payload'],true);if((int)($a['quiz']??0)!==(int)$s['quiz'])continue;$quiz['responses']++;if(isset($quiz['counts'][$a['answer']]))$quiz['counts'][$a['answer']]++;if((int)$answer['from_user']===(int)$u['id'])$quiz['myAnswer']=(int)$a['answer'];}
   if(!$host&&!$quiz['closed']){unset($quiz['correct'],$quiz['counts']);}
  }
 }
 return ['members'=>$members,'events'=>array_reverse($events),'floor'=>['mode'=>$s['mode'],'speaker'=>(int)$s['speaker'],'canSpeak'=>$host||px_room_can_speak($s,(int)$u['id'])],'quiz'=>$quiz,'endsAt'=>strtotime($r['ends_at'])*1000];
}

/** Waiting students receive no peer key, room token or publisher admission. */
function px_live_host_ready(array $lesson):bool {
 return $lesson['status']==='live'&&(bool)g('SELECT user_id FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND)',[$lesson['tenant_id'],$lesson['id'],$lesson['teacher_id']]);
}
function px_live_waiting(array $lesson):array {
 return ['waiting'=>true,'lesson'=>(int)$lesson['id'],'title'=>$lesson['title'],'endsAt'=>strtotime($lesson['ends_at'])*1000,'startsAt'=>strtotime($lesson['starts_at'])*1000,'hostConnecting'=>$lesson['status']==='starting'];
}
function px_live_wait(array $u,int $id):array {
 if($u['role']!=='student')throw new RuntimeException('Only allocated learners can enter this waiting room.');
 $lesson=px_live_scope($u,$id,true);
 if($lesson['provider']!=='schoolos')throw new RuntimeException('Open the external provider invitation for this lesson.');
 return ['ready'=>px_live_host_ready($lesson)]+px_live_waiting($lesson);
}
