<?php
if(!defined('SCHOOLOS_EXPERIENCE')){http_response_code(404);exit;}
function px_contact_filter(array $u):string {
 $tid=(int)$u['tenant_id'];$uid=(int)$u['id'];$role=$u['role'];$adults="v.role IN ('school_admin','teacher','staff','admissions')";
 $family="EXISTS(SELECT 1 FROM ecosystem_links p JOIN ecosystem_links ch ON ch.tenant_id=p.tenant_id AND ch.student_id=p.student_id AND ch.relation_type='student' WHERE p.tenant_id=$tid AND p.relation_type='parent' AND p.user_id=";
 $teaching=static fn(string $person,string $relation,string $teacher):string=>"EXISTS(SELECT 1 FROM ecosystem_links l JOIN students s ON s.id=l.student_id AND s.tenant_id=l.tenant_id JOIN classes c ON c.id=s.class_id AND c.tenant_id=s.tenant_id JOIN ac_allocations a ON a.tenant_id=s.tenant_id AND a.class_id=s.class_id AND a.session_name=c.session_name WHERE l.tenant_id=$tid AND l.user_id=$person AND l.relation_type='$relation' AND a.teacher_id=$teacher)";
 if(!xp_has('ac_allocations'))$teaching=static fn(string $person,string $relation,string $teacher):string=>'0=1';
 if($role==='student'){
  try{$s=lp_student($u);}catch(Throwable){return '0=1';}$class=(int)$s['class_id'];
  return "((v.role='student' AND (SELECT COUNT(DISTINCT x.student_id) FROM ecosystem_links x WHERE x.tenant_id=$tid AND x.user_id=v.id AND x.relation_type='student')=1 AND EXISTS(SELECT 1 FROM ecosystem_links l JOIN students s ON s.id=l.student_id AND s.tenant_id=l.tenant_id JOIN classes c ON c.id=s.class_id AND c.tenant_id=s.tenant_id WHERE l.tenant_id=$tid AND l.user_id=v.id AND l.relation_type='student' AND s.class_id=$class)) OR (v.role='parent' AND ".$family."v.id AND ch.user_id=$uid)) OR (v.role='teacher' AND ".$teaching((string)$uid,'student','v.id')."))";
 }
 if($role==='parent')return "(v.role='school_admin' OR (v.role='student' AND ".$family."$uid AND ch.user_id=v.id)) OR (v.role='teacher' AND ".$teaching((string)$uid,'parent','v.id')."))";
 if($role==='teacher')return "($adults OR (v.role='student' AND ".$teaching('v.id','student',(string)$uid).") OR (v.role='parent' AND ".$teaching('v.id','parent',(string)$uid)."))";
 if($role==='school_admin')return "($adults OR v.role='parent')";
 if(in_array($role,['staff','admissions'],true))return $adults;
 return '0=1';
}
function px_contacts(array $u,string $search='',?int $page=null):array {
 $search=mb_substr(trim($search),0,80);$limit=$page===null?'':' LIMIT 21 OFFSET '.(max(0,min(100000,$page))*20);$term='%'.str_replace(['=','%','_'],['==','=%','=_'],$search).'%';
 return q('SELECT v.id,v.name,v.role FROM users v WHERE v.tenant_id=? AND v.active=1 AND v.id<>? AND ('.px_contact_filter($u).") AND v.name LIKE ? ESCAPE '=' ORDER BY v.name,v.id".$limit,[$u['tenant_id'],$u['id'],$term])->fetchAll();
}
function px_contact_allowed(array $u,array $v):bool {
 if((int)$u['id']===(int)$v['id']||(int)$u['tenant_id']!==(int)($v['tenant_id']??0))return false;
 return (bool)g('SELECT v.id FROM users v WHERE v.id=? AND v.tenant_id=? AND v.active=1 AND ('.px_contact_filter($u).')',[$v['id'],$u['tenant_id']]);
}
function px_recipients(array $u,mixed $raw):array {
 if(!is_array($raw))$raw=[$raw];if(count($raw)<1||count($raw)>30)throw new RuntimeException('Choose between 1 and 30 people.');$out=[];
 foreach($raw as $id){if(!is_scalar($id)||!ctype_digit((string)$id))throw new RuntimeException('Choose a valid person.');$v=q('SELECT id,tenant_id,name,role FROM users WHERE tenant_id=? AND id=? AND active=1',[$u['tenant_id'],(int)$id])->fetch();if(!$v||!px_contact_allowed($u,$v))throw new RuntimeException('This person is outside your permitted school connections.');$out[(int)$id]=$v;}return $out;
}
function px_group_check(array $members):void {
 if(count($members)<2)throw new RuntimeException('Conversation unavailable.');$tid=(int)reset($members)['tenant_id'];$adults=true;$ids=[];
 foreach($members as $person){if((int)$person['tenant_id']!==$tid||!(int)($person['active']??1))throw new RuntimeException('This conversation no longer meets your school’s chat permissions.');$ids[]=(int)$person['id'];if(!in_array($person['role'],['school_admin','teacher','staff','admissions'],true))$adults=false;}
 if($adults)return; // Every school-colleague pair is allowed by the shared policy.
 $in=implode(',',$ids);foreach($members as $person){$allowed=(int)g('SELECT COUNT(*) FROM users v WHERE v.tenant_id=? AND v.active=1 AND v.id<>? AND v.id IN ('.$in.') AND ('.px_contact_filter($person).')',[$tid,$person['id']]);if($allowed!==count($members)-1)throw new RuntimeException('These people cannot share a conversation under your school’s chat permissions.');}
}
function px_thread(array $u,int $id):array {
 $r=q('SELECT t.* FROM px_threads t JOIN px_members m ON m.thread_id=t.id AND m.tenant_id=t.tenant_id WHERE t.tenant_id=? AND t.id=? AND m.user_id=?',[$u['tenant_id'],$id,$u['id']])->fetch();if(!$r)throw new RuntimeException('Conversation unavailable.');
 $members=q('SELECT u.id,u.tenant_id,u.name,u.role,u.active FROM px_members m JOIN users u ON u.id=m.user_id AND u.tenant_id=m.tenant_id WHERE m.tenant_id=? AND m.thread_id=?',[$u['tenant_id'],$id])->fetchAll();
 px_group_check($members);
 $names=[];foreach($members as $v)if((int)$v['id']!==(int)$u['id'])$names[]=$v['name'];$r['label']=implode(', ',$names)?:'Conversation';return $r;
}
function px_chat_start(array $u):int {
 global $pdo;$recipients=px_recipients($u,$_POST['recipients']??[]);$body=xp_text('body',4000);$members=[$u['id']=>$u]+$recipients;
 px_group_check($members);
 xp_rate('chat-start-'.$u['id'],15,1);$ids=array_keys($members);sort($ids,SORT_NUMERIC);$lock='schoolos-chat-'.substr(hash('sha256',g('SELECT DATABASE()').'|'.$u['tenant_id'].'|'.implode(',',$ids)),0,40);
 if(!(int)g('SELECT GET_LOCK(?,5)',[$lock]))throw new RuntimeException('Chat is busy. Try again.');
 try{return xp_tx(function()use($u,$members,$recipients,$body,$pdo){$id=0;
  if(count($members)===2){$other=(int)array_key_first($recipients);$id=(int)g('SELECT t.id FROM px_threads t JOIN px_members a ON a.thread_id=t.id AND a.tenant_id=t.tenant_id AND a.user_id=? JOIN px_members b ON b.thread_id=t.id AND b.tenant_id=t.tenant_id AND b.user_id=? WHERE t.tenant_id=? AND (SELECT COUNT(*) FROM px_members m WHERE m.tenant_id=t.tenant_id AND m.thread_id=t.id)=2 ORDER BY t.id DESC LIMIT 1',[$u['id'],$other,$u['tenant_id']]);}
  if(!$id){$title=mb_substr(implode(', ',array_column($members,'name')),0,180);q('INSERT INTO px_threads(tenant_id,created_by,title) VALUES(?,?,?)',[$u['tenant_id'],$u['id'],$title]);$id=(int)$pdo->lastInsertId();foreach(array_keys($members) as $uid)q('INSERT INTO px_members(tenant_id,thread_id,user_id) VALUES(?,?,?)',[$u['tenant_id'],$id,$uid]);}
  px_thread($u,$id);q('INSERT INTO px_messages(tenant_id,thread_id,user_id,body,client_key) VALUES(?,?,?,?,?)',[$u['tenant_id'],$id,$u['id'],$body,bin2hex(random_bytes(16))]);audit('chat.created','thread',(string)$id);return $id;
 });}finally{q('SELECT RELEASE_LOCK(?)',[$lock]);}
}
function px_unread_chat(array $u):array {
 $count=0;$latest=0;$rows=q('SELECT m.thread_id,COUNT(msg.id) unread,COALESCE(MAX(msg.id),0) latest FROM px_members m JOIN px_messages msg ON msg.tenant_id=m.tenant_id AND msg.thread_id=m.thread_id AND msg.id>m.last_read AND msg.user_id<>? WHERE m.tenant_id=? AND m.user_id=? GROUP BY m.thread_id',[$u['id'],$u['tenant_id'],$u['id']])->fetchAll();
 foreach($rows as $r){try{px_thread($u,(int)$r['thread_id']);}catch(Throwable){continue;}$count+=(int)$r['unread'];$latest=max($latest,(int)$r['latest']);}return ['count'=>$count,'latest'=>$latest];
}

function px_chat_send(array $u,int $id,string $body,string $key):int{if(mb_strlen(trim($body))<1||mb_strlen($body)>4000||!preg_match('/^[a-f0-9]{32}$/D',$key))throw new RuntimeException('Enter a message of 1–4000 characters.');xp_rate('chat-send-'.$u['id'],30,1);return xp_tx(function()use($u,$id,$body,$key){global $pdo;q('SELECT id FROM px_threads WHERE tenant_id=? AND id=? FOR UPDATE',[$u['tenant_id'],$id]);px_thread($u,$id);q('INSERT INTO px_messages(tenant_id,thread_id,user_id,body,client_key) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)',[$u['tenant_id'],$id,$u['id'],trim($body),$key]);$sent=(int)$pdo->lastInsertId();$row=q('SELECT thread_id,body FROM px_messages WHERE tenant_id=? AND id=? FOR UPDATE',[$u['tenant_id'],$sent])->fetch();if(!$row||(int)$row['thread_id']!==$id||$row['body']!==trim($body))throw new RuntimeException('This message key was already used for different content. Refresh the conversation before sending a new message.');q('DELETE FROM xp_progress WHERE tenant_id=? AND user_id=? AND step=?',[$u['tenant_id'],$u['id'],'chat_typing_'.$id]);return $sent;});}
function px_chat_fetch(array $u,int $id,int $after):array{px_thread($u,$id);$rows=q('SELECT m.id,m.user_id,m.body,m.created_at,u.name FROM px_messages m JOIN users u ON u.id=m.user_id AND u.tenant_id=m.tenant_id WHERE m.tenant_id=? AND m.thread_id=? AND m.id>? ORDER BY m.id LIMIT 100',[$u['tenant_id'],$id,max(0,$after)])->fetchAll();if($rows)q('UPDATE px_members SET last_read=GREATEST(last_read,?) WHERE tenant_id=? AND thread_id=? AND user_id=?',[(int)end($rows)['id'],$u['tenant_id'],$id,$u['id']]);return $rows;}
function px_contact_results(array $u):array{$page=(int)($_POST['page']??0);$rows=px_contacts($u,xp_text('search',80,false),$page);$more=count($rows)>20;return ['contacts'=>array_slice($rows,0,20),'more'=>$more];}
function px_notice_target_results(array $u):array{$rows=px_notice_targets($u,xp_text('notice_kind',12),xp_text('search',80,false),(int)($_POST['page']??0));return ['contacts'=>array_slice($rows,0,20),'more'=>count($rows)>20];}
function px_people_picker(string $id,string $mode='chat'):void{
 echo '<div class="px-people-picker" data-picker="'.e($mode).'" id="'.e($id).'"><div class="px-selected-people" aria-live="polite"></div><label>Search '.($mode==='chat'?'people':'your assigned routes or issued loans').'<input type="search" class="px-people-search" maxlength="80" autocomplete="off" placeholder="'.($mode==='chat'?'Type a name…':'Search by route, learner or book…').'"></label><div class="px-people-results" aria-label="Search results"></div><button type="button" class="px-people-more" hidden>More results</button><p class="px-picker-status" role="status"></p></div>';
}
function px_chat_view(array $u):void {
 echo '<section class="px-social-hero"><span class="px-kicker">YOUR SCHOOL CIRCLE</span><h2>Good conversations start here.</h2><p>Find a familiar name. Share a thought. Stay connected to the people in your school day.</p></section>';
 if(!px_ready()){echo '<p>Your administrator can activate Portal Experience.</p>';return;}$id=(int)($_GET['thread']??0);$thread=$id?px_thread($u,$id):null;
 echo '<div class="px-chat-layout px-social-chat"><aside class="px-thread-list"><div class="px-chat-list-head"><h3>Chats</h3><a href="?s=chat#pxNewChat" class="btn">＋ New chat</a></div><nav aria-label="Your chats">';
 $rows=q('SELECT t.id,MAX(msg.id) latest,SUM(IF(msg.id>m.last_read AND msg.user_id<>m.user_id,1,0)) unread FROM px_threads t JOIN px_members m ON m.tenant_id=t.tenant_id AND m.thread_id=t.id LEFT JOIN px_messages msg ON msg.tenant_id=t.tenant_id AND msg.thread_id=t.id WHERE t.tenant_id=? AND m.user_id=? GROUP BY t.id ORDER BY latest DESC LIMIT 100',[$u['tenant_id'],$u['id']])->fetchAll();$shown=0;
 foreach($rows as $r){try{$t=px_thread($u,(int)$r['id']);}catch(Throwable){continue;}$shown++;echo '<a class="px-chat-person" data-chat-thread="'.(int)$r['id'].'" '.($id===(int)$r['id']?'aria-current="page"':'').' href="?s=chat&amp;thread='.(int)$r['id'].'"><span class="px-person-avatar" aria-hidden="true">'.e(mb_substr($t['label'],0,1)).'</span><span><strong>'.e($t['label']).'</strong><small class="px-thread-preview">Open conversation</small></span>'.($r['unread']?'<b class="px-chat-unread">'.(int)$r['unread'].'</b>':'').'</a>';}
 if(!$shown)echo '<p class="px-empty-copy">Your conversations will appear here.</p>';echo '</nav></aside><section class="px-chat-window">';
 if($thread){echo '<header class="px-conversation-head"><a class="px-mobile-chat-back" href="?s=chat">← Chats</a><span class="px-person-avatar" aria-hidden="true">'.e(mb_substr($thread['label'],0,1)).'</span><div><h3>'.e($thread['label']).'</h3><div class="px-chat-status" role="status" id="pxChatStatus">Connecting…</div><div id="pxTypingStatus" class="px-typing-status" role="status" aria-live="polite" hidden></div></div></header><div id="pxMessages" role="log" aria-live="polite" aria-relevant="additions" data-user="'.(int)$u['id'].'" data-thread="'.$id.'"></div><form id="pxChatSend"><button type="button" id="pxEmojiToggle" class="px-emoji-toggle" aria-label="Choose an emoji" aria-expanded="false" aria-controls="pxComposeEmoji">☺</button><label class="px-visually-hidden" for="pxChatBody">Message</label><textarea id="pxChatBody" maxlength="4000" required rows="2" placeholder="Write a message…"></textarea><button class="btn" id="pxChatSendButton" aria-label="Send message">Send →</button></form><div id="pxTypingDelivery" class="px-typing-delivery" role="status" hidden></div><div id="pxComposeEmoji" class="px-compose-emoji" hidden></div>';
 }else{echo '<div id="pxNewChat" class="px-new-chat"><span class="px-kicker">MAKE A CONNECTION</span><h3>Who’s on your mind?</h3><p>Search your permitted school contacts. Select a person for a private chat, or a few people for a group.</p><form method="post" class="px-form" id="pxChatStart"><input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'"><input type="hidden" name="px_action" value="chat_start">';px_people_picker('pxChatPeople');echo '<label>Your message<textarea name="body" maxlength="4000" rows="3" required placeholder="Say hello…"></textarea></label><button class="btn">Start chatting →</button><noscript>Enable JavaScript to search and select people.</noscript></form><p class="px-chat-boundary">Learner chats stay within their class, linked family and assigned teachers. Colleague chats stay within your school.</p></div>';}
 echo '</section></div>';
 $kinds=[];if(op_can($u,'driver')||op_can($u,'transport_manager'))$kinds['route']='Route update';if(sv_can($u,'librarian'))$kinds['library']='Library return reminder';
 if($kinds){echo '<details class="px-operational-composer"><summary>Send a service notification</summary><p>One-way updates for learners in your assigned service. This does not open a private chat with a student.</p><form method="post" class="px-form" id="pxServiceNotice"><input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'"><input type="hidden" name="px_action" value="operational_notice"><input type="hidden" name="notice_key" value="'.bin2hex(random_bytes(16)).'"><label>Service<select name="notice_kind">';foreach($kinds as $k=>$label)echo '<option value="'.$k.'">'.e($label).'</option>';echo '</select></label>';px_people_picker('pxServicePeople','notice');echo '<label class="px-route-notice-body">Route update<textarea name="notice_body" maxlength="500" rows="2" placeholder="For example: pickup is delayed by 10 minutes."></textarea></label><p class="px-library-notice-help" hidden>We’ll send a return reminder for the selected issued book, including its due date.</p><button class="btn">Send service notification</button></form></details>';}
}

function px_legacy_alerts(array $u):array{$out=[];$tid=(int)($u['tenant_id']??0);if(!$tid)return $out;if(px_ready()){$unread=px_unread_chat($u);if($unread['count'])$out[]=['id'=>'chat','version'=>$unread['latest'],'text'=>$unread['count'].' unread chat messages','url'=>'?s=chat','priority'=>'normal'];}if($u['role']==='parent'&&pp_ready()){foreach(pp_children($u) as $s){if(xp_has('op_notifications'))foreach(q('SELECT id,kind,body FROM op_notifications WHERE tenant_id=? AND student_id=? AND kind NOT IN (\'route_notice\',\'library_return\') AND created_at>=DATE_SUB(NOW(),INTERVAL 3 DAY) ORDER BY id DESC LIMIT 3',[$tid,$s['id']]) as $r)$out[]=['id'=>'transport-'.$r['id'],'text'=>$s['name'].' · '.$r['kind'].': '.mb_substr($r['body'],0,160),'url'=>'?s=family&child='.$s['id'].'&view=transport','priority'=>'important'];foreach(q("SELECT id,kind,status,reply FROM pp_requests WHERE tenant_id=? AND user_id=? AND student_id=? AND (reply IS NOT NULL OR status IN ('approved','rejected')) ORDER BY id DESC LIMIT 3",[$tid,$u['id'],$s['id']]) as $r)$out[]=['id'=>'request-'.$r['id'].'-'.$r['status'],'text'=>$s['name'].' · '.$r['kind'].' request: '.$r['status'],'url'=>'?s=family&child='.$s['id'].'&view='.($r['kind']==='message'?'messages':$r['kind']),'priority'=>'normal'];}}if($u['role']==='teacher'&&pp_ready()){$n=(int)g("SELECT COUNT(*) FROM pp_bookings b JOIN pp_slots s ON s.id=b.slot_id AND s.tenant_id=b.tenant_id WHERE b.tenant_id=? AND s.teacher_user_id=? AND b.status='booked' AND s.starts_at BETWEEN NOW() AND DATE_ADD(NOW(),INTERVAL 2 DAY)",[$tid,$u['id']]);if($n)$out[]=['id'=>'booking-'.$n,'text'=>$n.' parent appointments coming up','url'=>'?s=family','priority'=>'important'];}if($u['role']==='school_admin'&&pp_ready()){$n=(int)g("SELECT COUNT(*) FROM pp_requests WHERE tenant_id=? AND status='pending' AND kind IN ('absence','pickup')",[$tid]);if($n)$out[]=['id'=>'reviews-'.$n,'text'=>$n.' family absence / pickup requests await review','url'=>'?s=family','priority'=>'important'];}if(xp_has('eg_deliveries')&&xp_has('eg_campaigns'))foreach(q("SELECT c.id,c.title FROM eg_deliveries d JOIN eg_campaigns c ON c.id=d.campaign_id AND c.tenant_id=d.tenant_id WHERE d.tenant_id=? AND d.user_id=? AND d.channel='inapp' AND d.status='delivered' AND c.kind='emergency' AND d.updated_at>=DATE_SUB(NOW(),INTERVAL 3 DAY) ORDER BY c.id DESC LIMIT 3",[$tid,$u['id']])->fetchAll() as $r)$out[]=['id'=>'emergency-'.$r['id'],'text'=>'Important school notice: '.$r['title'],'url'=>'?s=announcements','priority'=>'important'];return array_slice($out,0,15);}

/** Read state uses the existing per-account progress table; no migration is required. */
function px_notice_key(array $notice):string{return 'notice_'.substr(hash('sha256',(string)$notice['id'].'|'.(string)($notice['version']??1)),0,32);}
function px_class_alerts(array $u):array {
 if(!px_ready()||!in_array($u['role'],['student','teacher','school_admin'],true))return [];
 $params=[$u['tenant_id']];$where='';
 if($u['role']==='student'){try{$s=lp_student($u);}catch(Throwable){return [];}$where=' AND l.class_id=? AND l.session_name=?';$params[]=$s['class_id'];$params[]=$s['session_name'];}
 elseif($u['role']==='teacher'){$where=' AND l.teacher_id=?';$params[]=$u['id'];}
 $rows=q("SELECT l.*,su.name subject FROM px_live l JOIN classes c ON c.id=l.class_id AND c.tenant_id=l.tenant_id AND c.session_name=l.session_name JOIN subjects su ON su.id=l.subject_id AND su.tenant_id=l.tenant_id WHERE l.tenant_id=?".$where." AND l.status<>'archived' AND l.starts_at<=DATE_ADD(NOW(),INTERVAL 30 DAY) AND l.ends_at>=DATE_SUB(NOW(),INTERVAL 1 DAY) ORDER BY (l.status='live') DESC,l.starts_at LIMIT 40",$params)->fetchAll();$out=[];
 foreach($rows as $r){$stage=$r['status'];$start=strtotime($r['starts_at']);$end=strtotime($r['ends_at']);$active=$stage==='live'&&$end>time();if($stage==='scheduled'&&$start<=time()+900&&$end>time())$stage='soon';elseif($end<=time()&&!in_array($stage,['ended','cancelled'],true))$stage='finished';
  $label=match($stage){'live'=>'Live now','starting'=>'Teacher connecting','soon'=>'Starting soon','ended','finished'=>'Class ended','cancelled'=>'Class cancelled','paused'=>'Class paused',default=>'Class scheduled'};
  $out[]=['id'=>'live-'.$r['id'].'-'.$stage,'version'=>substr(hash('sha256',$r['title'].'|'.$r['starts_at'].'|'.$r['ends_at'].'|'.$r['status']),0,16),'text'=>$label.': '.$r['title'].' · '.$r['subject'].' · '.date('D j M, H:i',$start).' WAT','url'=>'?s=learning&view=live#live-lesson-'.$r['id'],'priority'=>in_array($stage,['live','soon'],true)?'important':'normal','created_at'=>$r['created_at'],'kind'=>'live_class'];
 }
 return $out;
}
function px_school_alerts(array $u):array {
 $out=[];$tid=(int)$u['tenant_id'];
 if(xp_has('cm_posts'))foreach(q('SELECT * FROM cm_posts WHERE tenant_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY) ORDER BY id DESC LIMIT 60',[$tid]) as $p){if(!cmAllowed($p,$u['role'],(int)$u['id'],$tid))continue;$out[]=['id'=>'announcement-'.$p['id'],'version'=>substr(hash('sha256',$p['title'].'|'.$p['body']),0,16),'text'=>'School notice: '.$p['title'],'url'=>'?s=announcements','priority'=>!empty($p['pinned'])?'important':'normal','created_at'=>$p['created_at'],'kind'=>'announcement'];}
 if($u['role']==='student'){
  try{$student=lp_student($u);}catch(Throwable){return $out;}
  if(xp_has('lm_courses')&&xp_has('lm_lessons'))foreach(q("SELECT l.id,l.title,l.due_at,l.created_at FROM lm_lessons l JOIN lm_courses c ON c.id=l.course_id AND c.tenant_id=l.tenant_id LEFT JOIN lm_submissions s ON s.lesson_id=l.id AND s.tenant_id=l.tenant_id AND s.student_id=? WHERE l.tenant_id=? AND c.class_id=? AND c.status='published' AND l.lesson_type IN ('homework','quiz') AND (l.available_at IS NULL OR l.available_at<=NOW()) AND l.due_at BETWEEN NOW() AND DATE_ADD(NOW(),INTERVAL 7 DAY) AND s.id IS NULL ORDER BY l.due_at LIMIT 15",[$student['id'],$tid,$student['class_id']]) as $l)$out[]=['id'=>'homework-'.$l['id'],'version'=>$l['due_at'],'text'=>'Assignment due: '.$l['title'].' · '.date('D j M, H:i',strtotime($l['due_at'])).' WAT','url'=>'?s=learning&view=homework#activity-'.$l['id'],'priority'=>strtotime($l['due_at'])<time()+86400?'important':'normal','created_at'=>$l['created_at'],'kind'=>'assignment'];
  if(xp_has('ac_term_approvals'))foreach(q("SELECT id,session_name,term_name,published_at FROM ac_term_approvals WHERE tenant_id=? AND class_id=? AND session_name=? AND status='published' AND published_at>=DATE_SUB(NOW(),INTERVAL 30 DAY) ORDER BY published_at DESC LIMIT 5",[$tid,$student['class_id'],$student['session_name']]) as $p)$out[]=['id'=>'results-'.$p['id'],'version'=>$p['published_at'],'text'=>'Your '.$p['term_name'].' results are published.','url'=>'?s=learning&view=grades','priority'=>'important','created_at'=>$p['published_at'],'kind'=>'results'];
 }
 return $out;
}
function px_alerts(array $u):array {
 $out=array_merge(px_class_alerts($u),px_school_alerts($u),px_legacy_alerts($u),px_operational_alerts($u),function_exists('hr_query_alerts')?hr_query_alerts($u):[]);$seen=[];$read=[];
 if(xp_has('xp_progress'))foreach(q("SELECT step FROM xp_progress WHERE tenant_id=? AND user_id=? AND step LIKE 'notice_%'",[$u['tenant_id'],$u['id']]) as $r)$read[$r['step']]=true;
 $out=array_values(array_filter($out,function($n)use(&$seen){if(isset($seen[$n['id']]))return false;$seen[$n['id']]=true;return true;}));
 foreach($out as &$n){$n['read']=isset($read[px_notice_key($n)]);$n['created_at']=$n['created_at']??'';$n['kind']=$n['kind']??'school_update';}unset($n);
 usort($out,fn($a,$b)=>(($a['read']?1:0)<=>($b['read']?1:0))?:((($b['priority']??'')==='important')<=>(($a['priority']??'')==='important'))?:strcmp($b['created_at'],$a['created_at']));
 return array_slice($out,0,80);
}
function px_notification_read(array $u):void {
 $id=xp_text('notice_id',100);$version=xp_text('version',100,false);
 if(!xp_has('xp_progress'))throw new RuntimeException('Ask your administrator to activate the account progress tables.');
 foreach(px_alerts($u) as $n)if($n['id']===$id&&(string)($n['version']??1)===($version?:'1')){q('INSERT IGNORE INTO xp_progress(tenant_id,user_id,step) VALUES(?,?,?)',[$u['tenant_id'],$u['id'],px_notice_key($n)]);return;}
 throw new RuntimeException('This notification is unavailable for your current account.');
}
function px_save_feedback():bool {
 $names=['notice','ssNotice','v23notice','acNotice','awNotice','cbNotice','cmNotice','crmNotice','lmNotice','ppNotice','sisNotice','saasNotice','fnNotice','activationFlash'];$messages=[];
 foreach($names as $name)if(isset($GLOBALS[$name])&&is_string($GLOBALS[$name]))$messages[]=$GLOBALS[$name];
 foreach(['px_notice','lp_notice','op_notice','sv_notice','ix_notice','xp_notice'] as $name)if(isset($_SESSION[$name])&&is_string($_SESSION[$name]))$messages[]=$_SESSION[$name];
 foreach($messages as $text)if(!preg_match('/(?:^Error:|\bfailed\b|\bunable\b|\binvalid\b|\bdenied\b|\bexpired\b)/i',$text)&&preg_match('/\b(saved|created|updated|recorded|submitted|sent|completed|approved|rejected|removed|scheduled|linked|activated|confirmed|installed|published|imported|added|cancelled)\b/i',$text))return true;
 return false;
}

/** Operational notices are one-way and scoped to an assigned route or an issued library loan. */
function px_notice_targets(array $u,string $kind,string $search='',int $page=0):array {
 $term='%'.str_replace(['=','%','_'],['==','=%','=_'],mb_substr(trim($search),0,80)).'%';$offset=max(0,min(100000,$page))*20;$tid=(int)$u['tenant_id'];
 if($kind==='route'&&(op_can($u,'driver')||op_can($u,'transport_manager'))){
  $where=op_can($u,'transport_manager')?'':' AND d.user_id='.(int)$u['id'];
  return q("SELECT r.id,r.name,'Assigned route' context FROM tm_routes r JOIN tm_drivers d ON d.id=r.driver_id AND d.tenant_id=r.tenant_id AND d.status='active' WHERE r.tenant_id=? AND r.active=1".$where." AND r.name LIKE ? ESCAPE '=' ORDER BY r.name,r.id LIMIT 21 OFFSET $offset",[$tid,$term])->fetchAll();
 }
 if($kind==='library'&&sv_can($u,'librarian'))return q("SELECT l.id,s.name,CONCAT(b.title,' · due ',COALESCE(l.due_on,'date pending')) context FROM lp_library_loans l JOIN students s ON s.id=l.student_id AND s.tenant_id=l.tenant_id JOIN books b ON b.id=l.book_id AND b.tenant_id=l.tenant_id WHERE l.tenant_id=? AND l.status='issued' AND (s.name LIKE ? ESCAPE '=' OR b.title LIKE ? ESCAPE '=') ORDER BY l.due_on,l.id LIMIT 21 OFFSET $offset",[$tid,$term,$term])->fetchAll();
 throw new RuntimeException('This operational notice is not assigned to your role.');
}
function px_operational_notice(array $u):string {
 $kind=xp_text('notice_kind',12);$id=(int)xp_text('target_id',20);$nonce=xp_text('notice_key',32);if(!preg_match('/^[a-f0-9]{32}$/D',$nonce))throw new RuntimeException('Refresh the notice form.');xp_rate('operational-notice-'.$u['id'],10,1);
 return xp_tx(function()use($u,$kind,$id,$nonce){$tid=(int)$u['tenant_id'];$targets=[];
 if($kind==='route'){
  $route=tm_route($u,$id);if(!$route['active'])throw new RuntimeException('This route is inactive.');$body='Route '.$route['name'].': '.xp_text('notice_body',500);$type='route_notice';
  $targets=q("SELECT DISTINCT student_id FROM tm_assignments WHERE tenant_id=? AND route_id=? AND status='active'",[$tid,$id])->fetchAll(PDO::FETCH_COLUMN);
 }elseif($kind==='library'){
  if(!sv_can($u,'librarian'))throw new RuntimeException('Librarian required.');$loan=q("SELECT l.*,b.title FROM lp_library_loans l JOIN books b ON b.id=l.book_id AND b.tenant_id=l.tenant_id WHERE l.tenant_id=? AND l.id=? AND l.status='issued' FOR UPDATE",[$tid,$id])->fetch();if(!$loan)throw new RuntimeException('Choose a currently issued school library loan.');
  $targets=[(int)$loan['student_id']];$body='Library reminder: please return “'.$loan['title'].'”'.($loan['due_on']?' by '.$loan['due_on']:' to the library').'. Contact the library desk if you need help.';$type='library_return';
 }else throw new RuntimeException('Choose a supported operational notice.');
 if(!$targets)throw new RuntimeException('No learners are assigned to this notice.');$sent=0;
 foreach($targets as $sid){$st=q('INSERT IGNORE INTO op_notifications(tenant_id,student_id,kind,body,event_key) VALUES(?,?,?,?,?)',[$tid,$sid,$type,mb_substr($body,0,1000),'chat-notice-'.$u['id'].'-'.$nonce.'-'.$sid]);$sent+=$st->rowCount();}
 audit('school.operational_notice',$kind,(string)$id);return $sent?'Operational notice delivered to the allocated learners and their linked guardians.':'This notice was already delivered.';
 });
}
function px_operational_alerts(array $u):array {
 if(!in_array($u['role'],['student','parent'],true)||!xp_has('op_notifications'))return [];$ids=array_column(op_children($u),'id');if(!$ids)return [];
 $params=[$u['tenant_id'],...$ids];$rows=q('SELECT n.*,s.name FROM op_notifications n JOIN students s ON s.id=n.student_id AND s.tenant_id=n.tenant_id WHERE n.tenant_id=? AND n.student_id IN ('.implode(',',array_fill(0,count($ids),'?')).") AND n.kind IN ('route_notice','library_return') AND n.created_at>=DATE_SUB(NOW(),INTERVAL 14 DAY) ORDER BY n.id DESC LIMIT 30",$params)->fetchAll();$out=[];
 foreach($rows as $r)$out[]=['id'=>'operational-'.$r['id'],'text'=>($u['role']==='parent'?$r['name'].' · ':'').$r['body'],'url'=>$r['kind']==='library_return'?'?s=services&area=library':($u['role']==='parent'?'?s=family&child='.$r['student_id'].'&view=transport':'?s=school_day&view=transport'),'priority'=>'important','kind'=>'operational','created_at'=>$r['created_at']];return $out;
}

/** Ephemeral typing and message reactions share the existing school-scoped stores. */
function px_chat_typing(array $u,int $id,bool $typing):array {
 px_thread($u,$id);xp_rate('chat-typing-'.$u['id'],120,1);$step='chat_typing_'.$id;
 if($typing)q('INSERT INTO xp_progress(tenant_id,user_id,step,completed_at) VALUES(?,?,?,NOW()) ON DUPLICATE KEY UPDATE completed_at=NOW()',[$u['tenant_id'],$u['id'],$step]);
 else q('DELETE FROM xp_progress WHERE tenant_id=? AND user_id=? AND step=?',[$u['tenant_id'],$u['id'],$step]);
 return ['saved'=>true];
}
function px_chat_react(array $u,int $thread,int $message,string $emoji):array {
 if($emoji!==''&&(strlen($emoji)>128||mb_strlen($emoji)>32||preg_match('/^\X$/u',$emoji)!==1||preg_match('/\p{Extended_Pictographic}|\p{Regional_Indicator}|\x{20E3}/u',$emoji)!==1))throw new RuntimeException('Choose one emoji for your reaction.');
 xp_rate('chat-reaction-'.$u['id'],60,1);
 return xp_tx(function()use($u,$thread,$message,$emoji){
  px_thread($u,$thread);
  if(!g('SELECT id FROM px_messages WHERE tenant_id=? AND thread_id=? AND id=? FOR UPDATE',[$u['tenant_id'],$thread,$message]))throw new RuntimeException('This message is outside the conversation.');
  $key='chat_reactions_'.(int)$u['tenant_id'].'_'.$message;$state=json_decode(xp_setting($key,'{}'),true);if(!is_array($state))$state=[];
  if($emoji==='')unset($state[(string)$u['id']]);else $state[(string)$u['id']]=$emoji;
  if($state)q('INSERT INTO xp_config(name,value) VALUES(?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',[$key,json_encode($state,JSON_THROW_ON_ERROR)]);
  else q('DELETE FROM xp_config WHERE name=?',[$key]);
  return ['saved'=>true];
 });
}
function px_chat_updates(array $u,int $id,int $after):array {
 $messages=px_chat_fetch($u,$id,$after); // Membership and all current contact relationships are checked first.
 $presence=px_chat_presence($u,[$id]);$typing=$presence[(string)$id]??[];
 $raw=$_POST['reaction_ids']??'[]';if(!is_string($raw)||strlen($raw)>3000)throw new RuntimeException('Too many message references.');$ids=json_decode($raw,true);if(!is_array($ids)||count($ids)>100)throw new RuntimeException('Choose up to 100 message references.');
 $ids=array_values(array_unique(array_filter(array_map(static fn($v):int=>is_scalar($v)&&ctype_digit((string)$v)?(int)$v:0,$ids))));
 $ids=array_slice(array_values(array_unique([...$ids,...array_map('intval',array_column($messages,'id'))])),0,200);$reactions=[];
 if($ids){
  $names=[];foreach(q('SELECT u.id,u.name FROM px_members m JOIN users u ON u.id=m.user_id AND u.tenant_id=m.tenant_id AND u.active=1 WHERE m.tenant_id=? AND m.thread_id=?',[$u['tenant_id'],$id]) as $person)$names[(int)$person['id']]=$person['name'];
  $rows=q("SELECT m.id,c.value FROM px_messages m LEFT JOIN xp_config c ON c.name=CONCAT('chat_reactions_',m.tenant_id,'_',m.id) WHERE m.tenant_id=? AND m.thread_id=? AND m.id IN (".implode(',',array_fill(0,count($ids),'?')).')',[$u['tenant_id'],$id,...$ids])->fetchAll();
  foreach($rows as $row){$groups=[];$state=json_decode($row['value']??'{}',true);if(is_array($state))foreach($state as $uid=>$emoji){if(!isset($names[(int)$uid])||!is_string($emoji))continue;if(!isset($groups[$emoji]))$groups[$emoji]=['emoji'=>$emoji,'count'=>0,'mine'=>false,'names'=>[]];$groups[$emoji]['count']++;$groups[$emoji]['mine']=$groups[$emoji]['mine']||(int)$uid===(int)$u['id'];$groups[$emoji]['names'][]=$names[(int)$uid];}$reactions[(string)$row['id']]=array_values($groups);}
 }
 return ['messages'=>$messages,'typing'=>$typing,'reactions'=>(object)$reactions];
}

/** Visible-chat presence. No message read receipts or draft text are changed here. */
function px_chat_presence(array $u,array $ids):array {
 if(count($ids)>50)throw new RuntimeException('Too many conversation references.');
 $ids=array_values(array_unique(array_filter(array_map(static fn($v):int=>is_scalar($v)&&ctype_digit((string)$v)?(int)$v:0,$ids))));$result=[];foreach($ids as $id)$result[(string)$id]=[];if(!$ids)return $result;
 $rows=q("SELECT m.thread_id,u.id,u.name,TIMESTAMPDIFF(SECOND,p.completed_at,NOW()) age_seconds FROM xp_progress p JOIN px_members m ON m.tenant_id=p.tenant_id AND m.user_id=p.user_id AND p.step=CONCAT('chat_typing_',m.thread_id) JOIN px_members mine ON mine.tenant_id=m.tenant_id AND mine.thread_id=m.thread_id AND mine.user_id=? JOIN users u ON u.tenant_id=p.tenant_id AND u.id=p.user_id AND u.active=1 WHERE p.tenant_id=? AND p.user_id<>? AND p.completed_at>DATE_SUB(NOW(),INTERVAL 10 SECOND) AND m.thread_id IN (".implode(',',array_fill(0,count($ids),'?')).')',[$u['id'],$u['tenant_id'],$u['id'],...$ids])->fetchAll();
 $checked=[];foreach($rows as $row){$id=(int)$row['thread_id'];if(!array_key_exists($id,$checked)){try{px_thread($u,$id);$checked[$id]=true;}catch(Throwable){$checked[$id]=false;}}if(!$checked[$id])continue;$result[(string)$id][]=['id'=>(int)$row['id'],'name'=>$row['name'],'expiresInMs'=>max(0,min(10000,10000-(int)$row['age_seconds']*1000))];}
 return $result;
}
function px_chat_presence_request(array $u):array {
 $raw=xp_text('threads',3000,false);$ids=json_decode($raw?:'[]',true);if(!is_array($ids))throw new RuntimeException('Choose valid conversations.');return ['typing'=>(object)px_chat_presence($u,$ids)];
}
