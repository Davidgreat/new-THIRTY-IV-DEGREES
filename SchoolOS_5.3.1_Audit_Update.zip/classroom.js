'use strict';
(() => {
  const csrf = document.querySelector('meta[name="px-csrf"]')?.content;
  const stage = document.querySelector('#pxLiveStage');
  if (!stage) return;
  const video = document.querySelector('#pxLiveVideo');
  const status = document.querySelector('#pxLiveStatus');
  const share = document.querySelector('#pxShareScreen');
  const joinButtons = [...document.querySelectorAll('[data-live-join]')];
  let session = null, stream = null, displayStream = null, timer = null;
  let after = 0, generation = 0, polling = false, joining = false, networkFailure = 0;
  const peers = new Map(), candidates = new Map();
  const message = text => { status.textContent = text; };

  async function api(action, body = {}, query = {}) {
    const url = new URL('index.php', location.href);
    url.searchParams.set('px_api', action);
    Object.entries(query).forEach(([key, value]) => url.searchParams.set(key, String(value)));
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    try {
      const response = await fetch(url, {method: 'POST', credentials: 'same-origin',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({csrf, ...body}), signal: controller.signal});
      if (response.redirected || !(response.headers.get('content-type') || '').includes('application/json')) {
        const error = new Error('Your classroom session is unavailable. Sign in again and rejoin.');
        error.terminal = true; throw error;
      }
      const data = await response.json();
      if (!response.ok || !data.ok) {
        const error = new Error(data.error || 'Classroom connection failed.');
        error.terminal = !!data.terminal || response.status === 401 || response.status === 403;
        throw error;
      }
      return data;
    } finally { clearTimeout(timeout); }
  }
  function signal(current, id, key, kind, payload) {
    return api('live_signal', {id: current.lesson, key: current.key, to: id,
      to_key: key, kind, payload: JSON.stringify(payload)});
  }
  function connection(current, id, key) {
    const old = peers.get(id);
    if (old?.key === key) return old.pc;
    if (old) old.pc.close();
    candidates.delete(id);
    const pc = new RTCPeerConnection({iceServers: current.iceServers});
    peers.set(id, {pc, key});
    pc.onicecandidate = event => {
      if (event.candidate && session === current) {
        signal(current, id, key, 'ice', event.candidate.toJSON()).catch(error => {
          if (session === current) message(error.message);
        });
      }
    };
    pc.ontrack = event => {
      if (session !== current || current.host) return;
      video.srcObject = event.streams[0] || new MediaStream([event.track]);
      video.muted = false;
      video.play().catch(() => message('Press play on the video to hear your teacher.'));
    };
    pc.onconnectionstatechange = () => {
      if (session !== current) return;
      if (pc.connectionState === 'connected') message(current.host ? 'Broadcast connected to your learner.' : 'You are connected to your teacher.');
      if (pc.connectionState === 'failed') message('Media could not connect. Rejoin the lesson; ask your school to test its TURN relay if this continues.');
    };
    if (current.host) {
      const tracks = [...(displayStream || stream).getVideoTracks(), ...stream.getAudioTracks()];
      const outgoing = new MediaStream(tracks);
      tracks.forEach(track => pc.addTrack(track, outgoing));
    }
    return pc;
  }
  async function addCandidates(id, pc) {
    for (const candidate of candidates.get(id) || []) await pc.addIceCandidate(candidate);
    candidates.delete(id);
  }
  async function leave(text = 'You have left the classroom.') {
    generation++;
    clearInterval(timer); timer = null;
    const old = session; session = null;
    for (const {pc} of peers.values()) pc.close();
    peers.clear(); candidates.clear();
    displayStream?.getTracks().forEach(track => track.stop()); displayStream = null;
    stream?.getTracks().forEach(track => track.stop()); stream = null;
    video.pause(); video.srcObject = null; share.hidden = true;
    message(text); stage.hidden = false;
    if (old) { try { await api('live_leave', {id: old.lesson, key: old.key}); } catch {} }
  }
  async function poll() {
    if (!session || polling) return;
    const current = session;
    polling = true;
    try {
      const data = await api('live_poll', {}, {id: current.lesson, key: current.key, after});
      if (session !== current) return;
      networkFailure = 0;
      if (data.status !== 'live') { await leave('The lesson has stopped.'); return; }
      const active = new Map(data.peers.map(peer => [Number(peer.user_id), peer]));
      for (const [id, entry] of peers) {
        if (!active.has(id) || active.get(id).peer_key !== entry.key) {
          entry.pc.close(); peers.delete(id); candidates.delete(id);
          if (!current.host) { video.srcObject = null; message('Waiting for your teacher to reconnect…'); }
        }
      }
      if (!current.host && !active.has(current.hostId)) {
        await leave('Your teacher has disconnected. Rejoin when the broadcast resumes.'); return;
      }
      if (current.host) for (const peer of data.peers) {
        if (session !== current) return;
        const id = Number(peer.user_id);
        if (peers.has(id)) continue;
        const pc = connection(current, id, peer.peer_key);
        try {
          await pc.setLocalDescription(await pc.createOffer());
          if (session !== current) return;
          await signal(current, id, peer.peer_key, 'offer', pc.localDescription.toJSON());
        } catch (error) { pc.close(); peers.delete(id); throw error; }
      }
      for (const item of data.signals) {
        if (session !== current) return;
        const id = Number(item.from_user), sender = active.get(id);
        if (!sender || sender.peer_key !== item.from_key) { after = Math.max(after, Number(item.id)); continue; }
        const pc = connection(current, id, item.from_key), payload = JSON.parse(item.payload);
        if (item.kind === 'offer') {
          await pc.setRemoteDescription(payload); await addCandidates(id, pc);
          await pc.setLocalDescription(await pc.createAnswer());
          if (session !== current) return;
          await signal(current, id, item.from_key, 'answer', pc.localDescription.toJSON());
        } else if (item.kind === 'answer') {
          await pc.setRemoteDescription(payload); await addCandidates(id, pc);
        } else if (item.kind === 'ice') {
          if (pc.remoteDescription) await pc.addIceCandidate(payload);
          else { const list = candidates.get(id) || []; list.push(payload); candidates.set(id, list); }
        }
        after = Math.max(after, Number(item.id));
      }
    } catch (error) {
      if (session !== current) return;
      if (!networkFailure) networkFailure = Date.now();
      if (error.terminal || Date.now() - networkFailure > 20000) await leave(error.message + ' Media stopped; rejoin when available.');
      else message('Connection interrupted. Retrying… ' + error.message);
    } finally { polling = false; }
  }
  joinButtons.forEach(button => button.addEventListener('click', async () => {
    if (joining) return;
    joining = true; joinButtons.forEach(item => { item.disabled = true; });
    try {
      await leave('Connecting to the classroom…');
      const attempt = generation;
      if (!window.isSecureContext || !window.RTCPeerConnection) throw new Error('Use HTTPS and a browser supporting WebRTC.');
      stage.scrollIntoView({behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'center'});
      const joined = await api('live_join', {id: button.dataset.liveJoin});
      if (attempt !== generation) { await api('live_leave', {id: joined.lesson, key: joined.key}); return; }
      session = joined; after = 0; networkFailure = 0;
      if (joined.host) {
        if (document.querySelector('.xp-notice')?.textContent.includes('DEMO SANDBOX') && !confirm('This is a shared demo. Other demo visitors may see your broadcast. Use fictional content only. Continue?')) { await leave(); return; }
        if (!navigator.mediaDevices?.getUserMedia) throw new Error('Camera access is unavailable in this browser.');
        const media = await navigator.mediaDevices.getUserMedia({video: {width: 640, height: 360}, audio: true});
        if (session !== joined) { media.getTracks().forEach(track => track.stop()); return; }
        stream = media; video.srcObject = stream; video.muted = true; video.play().catch(() => {});
      }
      share.hidden = !joined.host;
      message(joined.relayConfigured ? 'Classroom ready. Waiting for participants…' : 'Classroom ready. Cross-network calls need a tested school TURN relay.');
      await poll();
      if (session === joined) timer = setInterval(poll, 2500);
    } catch (error) { await leave(error.message); }
    finally { joining = false; joinButtons.forEach(item => { item.disabled = false; }); }
  }));
  document.querySelector('#pxLiveLeave').addEventListener('click', () => leave());
  share.addEventListener('click', async () => {
    const current = session;
    if (!current?.host || !stream) return;
    try {
      const display = await navigator.mediaDevices.getDisplayMedia({video: true});
      if (session !== current) { display.getTracks().forEach(track => track.stop()); return; }
      displayStream?.getTracks().forEach(track => track.stop()); displayStream = display;
      const track = display.getVideoTracks()[0], camera = stream.getVideoTracks()[0];
      for (const {pc} of peers.values()) {
        const sender = pc.getSenders().find(item => item.track?.kind === 'video');
        if (sender) await sender.replaceTrack(track);
      }
      track.onended = () => {
        if (displayStream !== display || session !== current) return;
        displayStream = null;
        for (const {pc} of peers.values()) pc.getSenders().find(item => item.track?.kind === 'video')?.replaceTrack(camera).catch(() => {});
        video.srcObject = stream;
      };
      video.srcObject = new MediaStream([track, ...stream.getAudioTracks()]);
    } catch (error) { message('Screen sharing was not started: ' + error.message); }
  });
  window.addEventListener('pagehide', () => {
    const old = session;
    // Stop media immediately; the beacon is only best-effort presence cleanup.
    void leave();
    if (old) navigator.sendBeacon('index.php?px_api=live_leave', new URLSearchParams({csrf, id: old.lesson, key: old.key}));
  });
})();
