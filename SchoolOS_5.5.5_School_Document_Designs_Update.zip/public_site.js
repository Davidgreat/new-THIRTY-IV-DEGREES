'use strict';
const root=document.documentElement,reduced=matchMedia('(prefers-reduced-motion: reduce)'),darkPreference=matchMedia('(prefers-color-scheme: dark)');
const storeGet=key=>{try{return localStorage.getItem(key)}catch{return null}},storeSet=(key,value)=>{try{localStorage.setItem(key,value)}catch{}};
const motionPaused=()=>reduced.matches||root.dataset.motion==='paused';
function animateIn(element){element.classList.remove('word-enter');void element.offsetWidth;element.classList.add('word-enter')}
const themeButton=document.querySelector('.web-theme'),motionButton=document.querySelector('.web-motion');
function applyTheme(theme){root.dataset.theme=theme;if(themeButton){themeButton.setAttribute('aria-pressed',String(theme==='dark'));themeButton.setAttribute('aria-label',theme==='dark'?'Switch to light theme':'Switch to dark theme');themeButton.querySelector('span').textContent=theme==='dark'?'Light':'Dark'}document.querySelector('meta[name="theme-color"]')?.setAttribute('content',theme==='dark'?'#101d1a':'#123e35')}
applyTheme(storeGet('schoolos-theme')||(darkPreference.matches?'dark':'light'));
themeButton?.addEventListener('click',()=>{const theme=root.dataset.theme==='dark'?'light':'dark';storeSet('schoolos-theme',theme);applyTheme(theme)});
darkPreference.addEventListener('change',e=>{if(!storeGet('schoolos-theme'))applyTheme(e.matches?'dark':'light')});
function applyMotion(){if(motionButton){const paused=motionPaused();motionButton.setAttribute('aria-pressed',String(paused));motionButton.setAttribute('aria-label',paused?'Resume website motion':'Pause website motion');motionButton.innerHTML=paused?'▷ <span>Resume motion</span>':'Ⅱ <span>Pause motion</span>'}if(motionPaused())document.querySelectorAll('.reveal-ready').forEach(el=>el.classList.add('revealed'))}
root.dataset.motion='playing';applyMotion();motionButton?.addEventListener('click',()=>{root.dataset.motion=root.dataset.motion==='paused'?'playing':'paused';storeSet('schoolos-motion',root.dataset.motion);applyMotion()});reduced.addEventListener('change',applyMotion);
const menu=document.querySelector('.menu'),nav=document.querySelector('#webnav');
menu?.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));nav.classList.toggle('open',open)});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&menu?.getAttribute('aria-expanded')==='true'){menu.click();menu.focus()}});
const facts=['Zero is an even number: it is divisible by two with no remainder.','A triangle’s interior angles add to 180° on a flat plane. On a curved surface, the story changes.','Plants use light energy to turn carbon dioxide and water into sugars during photosynthesis.','The number 2 is the only even prime number. Every other even number has 2 as a factor.','Sound needs a medium to travel through. It cannot travel through a vacuum.','A leap year usually has 366 days. Century years must be divisible by 400 to qualify.'];let fact=0;
document.querySelector('#next-fact')?.addEventListener('click',()=>{fact=(fact+1)%facts.length;document.querySelector('#fun-fact').textContent=facts[fact];if(!motionPaused())animateIn(document.querySelector('#fun-fact'))});
const challenges = [
  {
    "id": 0,
    "topic": "Maths",
    "question": "A class plants 3 rows of 8 seedlings. One quarter grows flowers. How many flower?",
    "options": [
      "4",
      "6",
      "8"
    ],
    "correct": "6",
    "explanation": "3 × 8 = 24 seedlings. One quarter of 24 is 6."
  },
  {
    "id": 1,
    "topic": "Maths",
    "question": "What is 15% of 200?",
    "options": [
      "15",
      "30",
      "45"
    ],
    "correct": "30",
    "explanation": "10% of 200 is 20 and 5% is 10. Add them: 30."
  },
  {
    "id": 2,
    "topic": "Maths",
    "question": "A triangle has two angles of 50° and 60°. What is the third?",
    "options": [
      "60°",
      "70°",
      "80°"
    ],
    "correct": "70°",
    "explanation": "On a flat plane, a triangle’s angles total 180°. Subtract 50° and 60° to get 70°."
  },
  {
    "id": 3,
    "topic": "Maths",
    "question": "What is three quarters of 28?",
    "options": [
      "7",
      "14",
      "21"
    ],
    "correct": "21",
    "explanation": "Divide 28 by 4 to get 7, then multiply by 3 to get 21."
  },
  {
    "id": 4,
    "topic": "Maths",
    "question": "Which of these numbers is prime?",
    "options": [
      "21",
      "29",
      "33"
    ],
    "correct": "29",
    "explanation": "29 has exactly two positive factors: 1 and 29. 21 and 33 are divisible by 3."
  },
  {
    "id": 5,
    "topic": "Maths",
    "question": "A square has a perimeter of 36 cm. What is its area?",
    "options": [
      "36 cm²",
      "81 cm²",
      "144 cm²"
    ],
    "correct": "81 cm²",
    "explanation": "Each side is 36 ÷ 4 = 9 cm. Its area is 9 × 9 = 81 cm²."
  },
  {
    "id": 6,
    "topic": "Science",
    "question": "Which gas do plants take in for photosynthesis?",
    "options": [
      "Oxygen",
      "Carbon dioxide",
      "Helium"
    ],
    "correct": "Carbon dioxide",
    "explanation": "Plants use carbon dioxide and water, with light energy, to make sugars during photosynthesis."
  },
  {
    "id": 7,
    "topic": "Science",
    "question": "Which part of a cell contains most of its DNA in a typical animal cell?",
    "options": [
      "Nucleus",
      "Cell membrane",
      "Cytoplasm"
    ],
    "correct": "Nucleus",
    "explanation": "Most DNA is inside the nucleus. Mitochondria also contain a small amount of DNA."
  },
  {
    "id": 8,
    "topic": "Science",
    "question": "Which travels faster in a vacuum: red light or blue light?",
    "options": [
      "Red light",
      "Blue light",
      "Same speed"
    ],
    "correct": "Same speed",
    "explanation": "All visible light travels at the same speed in a vacuum."
  },
  {
    "id": 9,
    "topic": "Science",
    "question": "What force keeps the planets in orbit around the Sun?",
    "options": [
      "Friction",
      "Gravity",
      "Magnetism"
    ],
    "correct": "Gravity",
    "explanation": "Gravity provides the inward force that bends each planet’s path into an orbit."
  },
  {
    "id": 10,
    "topic": "Science",
    "question": "When liquid water becomes water vapour at its surface, what is the process?",
    "options": [
      "Freezing",
      "Evaporation",
      "Condensation"
    ],
    "correct": "Evaporation",
    "explanation": "Evaporation is the change from liquid to gas at the liquid’s surface."
  },
  {
    "id": 11,
    "topic": "Science",
    "question": "Which organ pumps blood around the human body?",
    "options": [
      "Lungs",
      "Heart",
      "Kidneys"
    ],
    "correct": "Heart",
    "explanation": "The heart pumps blood. Lungs exchange gases and kidneys filter the blood."
  },
  {
    "id": 12,
    "topic": "Logic",
    "question": "What comes next: 2, 4, 8, 16, …?",
    "options": [
      "18",
      "24",
      "32"
    ],
    "correct": "32",
    "explanation": "Each number doubles. 16 × 2 = 32."
  },
  {
    "id": 13,
    "topic": "Logic",
    "question": "All robins are birds. Some birds swim. Must all robins swim?",
    "options": [
      "Yes",
      "No",
      "Only in summer"
    ],
    "correct": "No",
    "explanation": "The statements do not tell us whether robins belong to the group of birds that swim."
  },
  {
    "id": 14,
    "topic": "Logic",
    "question": "I have keys but no locks, and space but no room. What am I?",
    "options": [
      "A keyboard",
      "A suitcase",
      "A library"
    ],
    "correct": "A keyboard",
    "explanation": "A keyboard has letter keys and a space bar, but they are not door keys or a physical room."
  },
  {
    "id": 15,
    "topic": "Logic",
    "question": "Which letter comes next: A, C, E, G, …?",
    "options": [
      "H",
      "I",
      "J"
    ],
    "correct": "I",
    "explanation": "Skip one letter each time: A, C, E, G, I."
  },
  {
    "id": 16,
    "topic": "Logic",
    "question": "If today is Tuesday, what day will it be in 10 days?",
    "options": [
      "Thursday",
      "Friday",
      "Saturday"
    ],
    "correct": "Friday",
    "explanation": "Seven days later is Tuesday. Three more days takes you to Friday."
  },
  {
    "id": 17,
    "topic": "Logic",
    "question": "Three children each shake hands with every other child once. How many handshakes?",
    "options": [
      "3",
      "6",
      "9"
    ],
    "correct": "3",
    "explanation": "Label them A, B and C. The pairs are AB, AC and BC: three handshakes."
  },
  {
    "id": 18,
    "topic": "Words",
    "question": "Which word is a synonym of “curious”?",
    "options": [
      "Inquisitive",
      "Sleepy",
      "Silent"
    ],
    "correct": "Inquisitive",
    "explanation": "Inquisitive means eager to ask questions and learn."
  },
  {
    "id": 19,
    "topic": "Words",
    "question": "Which is the correct plural of “child”?",
    "options": [
      "Childs",
      "Children",
      "Childes"
    ],
    "correct": "Children",
    "explanation": "“Children” is an irregular plural. It does not follow the usual add-s rule."
  },
  {
    "id": 20,
    "topic": "Words",
    "question": "Which sentence uses “their” correctly?",
    "options": [
      "Their going home.",
      "Their books are here.",
      "Put it over their."
    ],
    "correct": "Their books are here.",
    "explanation": "“Their” shows possession. “They’re” means they are, and “there” refers to a place."
  },
  {
    "id": 21,
    "topic": "Words",
    "question": "Which word is an adjective in “The bright moon glows”?",
    "options": [
      "Bright",
      "Moon",
      "Glows"
    ],
    "correct": "Bright",
    "explanation": "“Bright” describes the moon, so it is an adjective. “Moon” is a noun and “glows” is a verb."
  },
  {
    "id": 22,
    "topic": "Words",
    "question": "Which word is a palindrome, reading the same forwards and backwards?",
    "options": [
      "Level",
      "Learn",
      "Light"
    ],
    "correct": "Level",
    "explanation": "L-E-V-E-L reads the same in both directions."
  },
  {
    "id": 23,
    "topic": "Words",
    "question": "Which punctuation mark usually ends a direct question?",
    "options": [
      "Comma",
      "Question mark",
      "Semicolon"
    ],
    "correct": "Question mark",
    "explanation": "A direct question ends with a question mark, for example: What did you discover?"
  },
  {
    "id": 24,
    "topic": "Geography",
    "question": "What is the capital of Nigeria?",
    "options": [
      "Lagos",
      "Abuja",
      "Kano"
    ],
    "correct": "Abuja",
    "explanation": "Abuja became Nigeria’s federal capital in 1991."
  },
  {
    "id": 25,
    "topic": "Geography",
    "question": "Which ocean lies along Nigeria’s southern coastline?",
    "options": [
      "Atlantic Ocean",
      "Indian Ocean",
      "Pacific Ocean"
    ],
    "correct": "Atlantic Ocean",
    "explanation": "Nigeria’s coast meets the Gulf of Guinea, which is part of the Atlantic Ocean."
  },
  {
    "id": 26,
    "topic": "Geography",
    "question": "Which direction is opposite north-east?",
    "options": [
      "North-west",
      "South-east",
      "South-west"
    ],
    "correct": "South-west",
    "explanation": "Opposite compass directions are 180° apart. North-east is opposite south-west."
  },
  {
    "id": 27,
    "topic": "Geography",
    "question": "What does the equator divide Earth into?",
    "options": [
      "Eastern and western halves",
      "Northern and southern hemispheres",
      "Land and water"
    ],
    "correct": "Northern and southern hemispheres",
    "explanation": "The equator is the line of latitude at 0°, halfway between the poles."
  },
  {
    "id": 28,
    "topic": "Geography",
    "question": "Which river joins the Niger at Lokoja?",
    "options": [
      "Benue",
      "Thames",
      "Nile"
    ],
    "correct": "Benue",
    "explanation": "Lokoja is known for the confluence of the Niger and Benue rivers."
  },
  {
    "id": 29,
    "topic": "Geography",
    "question": "On a map, 1 cm represents 5 km. How far does 4 cm represent?",
    "options": [
      "9 km",
      "15 km",
      "20 km"
    ],
    "correct": "20 km",
    "explanation": "Multiply the map distance by the scale: 4 × 5 = 20 km."
  },
  {
    "id": 30,
    "topic": "Digital skills",
    "question": "Which password habit is safest?",
    "options": [
      "Reuse one password",
      "Use a unique long password",
      "Share it with friends"
    ],
    "correct": "Use a unique long password",
    "explanation": "Unique long passwords reduce the harm if another service is compromised. A password manager can help."
  },
  {
    "id": 31,
    "topic": "Digital skills",
    "question": "An unexpected message asks for your login code. What should you do?",
    "options": [
      "Send it immediately",
      "Verify through a trusted channel",
      "Post the code publicly"
    ],
    "correct": "Verify through a trusted channel",
    "explanation": "Do not share login codes. Contact the organization independently through a known trusted route."
  },
  {
    "id": 32,
    "topic": "Digital skills",
    "question": "What does a browser’s HTTPS indicator establish?",
    "options": [
      "The website is always honest",
      "The connection is encrypted",
      "Every claim is correct"
    ],
    "correct": "The connection is encrypted",
    "explanation": "HTTPS protects the connection. It does not prove that a website’s content or operator is trustworthy."
  },
  {
    "id": 33,
    "topic": "Digital skills",
    "question": "An offline attendance entry has not synchronized yet. Where might the newest record still be?",
    "options": [
      "Only on the device",
      "On every school account",
      "Nowhere"
    ],
    "correct": "Only on the device",
    "explanation": "Local capture is not proof of a server update. Reconnect, synchronize and review any conflicts."
  },
  {
    "id": 34,
    "topic": "Digital skills",
    "question": "Which file extension commonly identifies a spreadsheet workbook?",
    "options": [
      ".xlsx",
      ".mp3",
      ".jpg"
    ],
    "correct": ".xlsx",
    "explanation": "XLSX is a spreadsheet workbook format. MP3 is audio and JPG is an image format."
  },
  {
    "id": 35,
    "topic": "Digital skills",
    "question": "You see an AI answer that seems wrong. What is the best next step?",
    "options": [
      "Copy it without checking",
      "Check reliable sources and ask a teacher",
      "Assume it is always correct"
    ],
    "correct": "Check reliable sources and ask a teacher",
    "explanation": "AI can make mistakes. Verify claims and calculations with trustworthy sources and a responsible human."
  }
];
Object.freeze(challenges);window.SchoolOSChallenges=challenges;
const topicSelect=document.querySelector('#quiz-topic'),question=document.querySelector('#quiz-question'),answers=document.querySelector('.quiz-answers'),result=document.querySelector('#quiz-result');
let deck=[],active=null,solved=new Set();
function shuffle(list){for(let i=list.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[list[i],list[j]]=[list[j],list[i]]}return list}
function fillDeck(first=false){const topic=topicSelect?.value||'all';deck=challenges.filter(c=>topic==='all'||c.topic===topic).map(c=>c.id);if(first&&topic==='all'){deck=shuffle(deck.slice(1));deck.unshift(0)}else{shuffle(deck);if(deck.length>1&&deck[0]===active?.id)[deck[0],deck[1]]=[deck[1],deck[0]]}}
function showChallenge(){if(!question)return;if(!deck.length)fillDeck();active=challenges[deck.shift()];question.textContent=active.question;document.querySelector('#quiz-topic-label').textContent=active.topic;document.querySelector('#quiz-count').textContent=(topicSelect.value==='all'?36:6)+' discoveries';answers.replaceChildren();active.options.forEach(option=>{const button=document.createElement('button');button.type='button';button.dataset.answer=option;button.textContent=option;button.addEventListener('click',()=>{if(option===active.correct){solved.add(active.id);button.classList.add('correct');answers.querySelectorAll('button').forEach(b=>b.disabled=true);result.textContent='Exactly! '+active.explanation;document.querySelector('#quiz-score').textContent=solved.size+' '+(solved.size===1?'discovery':'discoveries')+' solved';}else{button.classList.add('incorrect');result.textContent='Not quite. Try again! '+(active.id===0?'Start with 3 × 8, then divide by 4.':'Think it through, or try another option.')}});answers.append(button)});result.textContent='Take a guess. A little thinking is always a good thing.';if(!reduced.matches&&!motionPaused())animateIn(question)}
if(question){fillDeck(true);showChallenge();document.querySelector('#next-challenge').addEventListener('click',()=>{showChallenge();question.setAttribute('tabindex','-1');question.focus({preventScroll:true})});topicSelect.addEventListener('change',()=>{fillDeck();showChallenge()})}
const previews={owner:['website-owner.png?v=539','School owner overview · Fictional demonstration data.'],onboarding:['website-onboarding.png?v=539','School setup checklist · Fictional demonstration data.'],parent:['website-parent.png?v=539','Parent mobile dashboard · Fictional demonstration data.']};
document.querySelectorAll('[data-preview]').forEach(b=>b.addEventListener('click',()=>{const data=previews[b.dataset.preview],img=document.querySelector('#dashboard-preview');document.querySelectorAll('[data-preview]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));img.src=data[0];img.alt=data[1];img.classList.toggle('mobile-shot',b.dataset.preview==='parent');document.querySelector('#preview-caption').textContent=data[1]}));

const heroWord=document.querySelector('#hero-word'),words=['flourish.','connect.','shine.','inspire.'];let word=0;
if(heroWord)setInterval(()=>{if(document.hidden||motionPaused())return;word=(word+1)%words.length;heroWord.textContent=words[word];animateIn(heroWord)},4200);
if('IntersectionObserver' in window&&!motionPaused()){const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('revealed');observer.unobserve(entry.target)}}),{threshold:.08});document.querySelectorAll('.cards article,.section-heading,.story>div,.curiosity>div,.steps>h2,.cta').forEach((el,i)=>{el.style.setProperty('--reveal-delay',`${i%3*70}ms`);el.classList.add('reveal-ready');observer.observe(el)})}
if(matchMedia('(hover: hover) and (pointer: fine)').matches){document.querySelectorAll('.cards article').forEach(card=>card.addEventListener('pointermove',event=>{const rect=card.getBoundingClientRect();card.style.setProperty('--spot-x',`${event.clientX-rect.left}px`);card.style.setProperty('--spot-y',`${event.clientY-rect.top}px`)}))}
// A shorter phone homepage: swipeable highlights, optional discovery and a reachable next step.
if(document.body.dataset.webPage==='home'){
 const phone=matchMedia('(max-width:780px)'),curiosity=document.querySelector('.curiosity');
 if(curiosity){const fold=document.createElement('details');fold.className='web-mobile-discovery';const summary=document.createElement('summary');summary.textContent='A quick discovery break';curiosity.before(fold);fold.append(summary,curiosity);const layout=()=>{fold.open=!phone.matches;};phone.addEventListener('change',layout);layout();}
 for(const grid of document.querySelectorAll('.feature-grid,.steps .cards')){grid.tabIndex=0;grid.setAttribute('aria-label',grid.classList.contains('feature-grid')?'Explore school features':'Three steps to start');const hint=document.createElement('p');hint.className='web-swipe-hint';hint.textContent='Swipe to explore →';grid.before(hint);}
 const dock=document.createElement('nav');dock.className='web-mobile-dock';dock.setAttribute('aria-label','Get started');const demo=document.createElement('a'),start=document.createElement('a');demo.href='?login=1';demo.textContent='Explore the demo';start.href='?page=pricing';start.textContent='Find your plan →';dock.append(demo,start);document.body.append(dock);
}

// Moving background bubbles: bounded, elastic collisions; no interaction with data panels.
(()=>{
 const scene=document.querySelector('.sos-glass-scene');if(!scene)return;if(scene.dataset.engineBound==='1')return;scene.dataset.engineBound='1';
 try{
 const nodes=Array.from(scene.children).filter(el=>el.tagName==='SPAN');if(nodes.length<2)return;
 const motion=matchMedia('(prefers-reduced-motion: reduce)'),transparency=matchMedia('(prefers-reduced-transparency: reduce)'),contrast=matchMedia('(forced-colors: active)'),printing=matchMedia('print');
 let arena,bubbles=[],frame=0,timer=0,last=0,resizeTimer=0,collisions=0,watchdog=0,timerMode=false,advanced=false,lastPaint=performance.now();
 function reason(){if(document.hidden)return'hidden';if(printing.matches)return'print';if(transparency.matches||contrast.matches)return'hidden-by-preference';if(motion.matches&&document.documentElement.clientWidth<=850)return'reduced-motion';return''}
 function updateState(){scene.dataset.motionState=reason()||(!advanced?'starting':'running');scene.dataset.motionDriver=timerMode&&!arena?.mobile?'timer':'raf'}
 const watch=(q,fn)=>q.addEventListener?q.addEventListener('change',fn):q.addListener(fn);

 const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
 function layout(){
  const w=document.documentElement.clientWidth,h=innerHeight,side=document.querySelector('.side'),left=w>850&&side?Math.max(0,side.getBoundingClientRect().right):0,top=document.querySelector('.top')?.getBoundingClientRect().height||70;
  const mobile=w<=850,viewW=Math.max(140,w-left-24),viewH=Math.max(140,h-top-24),padX=mobile?0:viewW*.30,padY=mobile?0:viewH*.42;
  arena={x:left+12-padX,y:top+12-padY,w:viewW+2*padX,h:viewH+2*padY,mobile};
  // The mobile size, speed and seed are identical to 5.3.31. Desktop gets a wider world.
  const size=mobile?Math.min(340,Math.max(90,Math.min(arena.w*.36,arena.h*.42))):Math.min(650,Math.max(430,viewW*.52)),speed=mobile?Math.min(56,Math.max(30,arena.w*.05)):Math.min(130,Math.max(82,viewW*.105));
  const seed=mobile?[{x:.25,y:.32,vx:.95,vy:.33,s:1},{x:.75,y:.34,vx:-.9,vy:.25,s:.88},{x:.52,y:.76,vx:-.42,vy:-.84,s:.76}]:[{x:.16,y:.32,vx:.95,vy:.33,s:1},{x:.76,y:.46,vx:-.9,vy:.25,s:.88},{x:.48,y:.96,vx:.55,vy:-.84,s:.76}];
  bubbles=nodes.map((el,i)=>{const p=seed[i%seed.length],r=Math.min(size*p.s/2,arena.w/2-2,arena.h/2-2),b={el,r,m:r*r,x:clamp(padX+viewW*p.x,r,arena.w-r),y:clamp(padY+viewH*p.y,r,arena.h-r),vx:speed*p.vx,vy:speed*p.vy};Object.assign(el.style,{inset:'auto',left:'0px',top:'0px',width:2*r+'px',height:2*r+'px'});return b});
  scene.dataset.bubbleMode=mobile?'elastic':'desktop-wide';paint();last=0;
 }
 function paint(){lastPaint=performance.now();for(const b of bubbles){const position=`translate3d(${(arena.x+b.x-b.r).toFixed(2)}px,${(arena.y+b.y-b.r).toFixed(2)}px,0)`;b.el.style.transform=position;if(motion.matches||!arena.mobile)b.el.style.setProperty('--sos-static-position',position)}}
 function collide(){for(let i=0;i<bubbles.length;i++)for(let j=i+1;j<bubbles.length;j++){
  const a=bubbles[i],b=bubbles[j],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy),sum=a.r+b.r;if(d>=sum)continue;
  const nx=d>0?dx/d:1,ny=d>0?dy/d:0,overlap=sum-d+.2,total=a.m+b.m;
  a.x-=nx*overlap*b.m/total;a.y-=ny*overlap*b.m/total;b.x+=nx*overlap*a.m/total;b.y+=ny*overlap*a.m/total;
  const closing=(b.vx-a.vx)*nx+(b.vy-a.vy)*ny;if(closing<0){const impulse=-2*closing/(1/a.m+1/b.m);a.vx-=impulse*nx/a.m;a.vy-=impulse*ny/a.m;b.vx+=impulse*nx/b.m;b.vy+=impulse*ny/b.m;scene.dataset.bubbleCollisions=String(++collisions);scene.dataset.bubblePair=i+':'+j;}
 }}
 function wall(b){if(b.x<b.r){b.x=b.r;b.vx=Math.abs(b.vx)}else if(b.x>arena.w-b.r){b.x=arena.w-b.r;b.vx=-Math.abs(b.vx)}if(b.y<b.r){b.y=b.r;b.vy=Math.abs(b.vy)}else if(b.y>arena.h-b.r){b.y=arena.h-b.r;b.vy=-Math.abs(b.vy)}}
 function allowed(){return !reason()}
 function stop(){if(frame)cancelAnimationFrame(frame);if(timer)clearTimeout(timer);frame=timer=0}
 function schedule(){if(timerMode&&!arena.mobile)timer=setTimeout(()=>{timer=0;tick(performance.now())},33);else frame=requestAnimationFrame(tick)}
 function tick(t){frame=0;if(!allowed())return;if(!last)last=t;const elapsed=t-last;if(elapsed>=32){const dt=Math.min(elapsed/1000,arena.mobile ? .05 : .12),steps=arena.mobile?1:Math.ceil(dt/.025),step=dt/steps;last=t;for(let n=0;n<steps;n++){for(const b of bubbles){b.x+=b.vx*step;b.y+=b.vy*step;wall(b)}collide();for(const b of bubbles)wall(b)}advanced=true;paint();if(scene.dataset.motionState!=='running')updateState()}schedule()}
 function sync(){document.body.classList.toggle('sos-motion-paused',!!reason());document.body.classList.toggle('sos-background-animate',document.documentElement.clientWidth>850);if(motion.matches)for(const b of bubbles)b.el.style.setProperty('--sos-static-position',b.el.style.transform);stop();last=0;lastPaint=performance.now();advanced=false;updateState();if(allowed())schedule();if(arena.mobile&&watchdog){clearInterval(watchdog);watchdog=0}else if(!arena.mobile&&!watchdog)watchdog=setInterval(()=>{if(allowed()&&performance.now()-lastPaint>1500&&!timerMode){timerMode=true;stop();last=0;advanced=false;updateState();schedule()}},500)}
 layout();sync();document.addEventListener('visibilitychange',sync);for(const preference of [motion,transparency,contrast,printing])watch(preference,sync);addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{layout();sync()},120)});
 }catch(error){scene.dataset.motionState='error';console.warn('SchoolOS background animation could not start.',error)}
})();

// Local partner-demo simulation deliberately has no network or persistence.
document.querySelectorAll('[data-af-demo]').forEach(root=>{const button=root.querySelector('[data-af-demo-request]'),amount=root.querySelector('[data-af-demo-amount]'),status=root.querySelector('[data-af-demo-status]'),balance=root.querySelector('[data-af-demo-balance]');button?.addEventListener('click',()=>{const value=Number(amount.value);if(![5000,10000,20000].includes(value))return;balance.textContent=new Intl.NumberFormat('en-NG',{style:'currency',currency:'NGN'}).format(45000-value);status.textContent='Preview: ₦'+value.toLocaleString('en-NG')+' reserved for platform review. No request was saved and no money was sent. Reload to reset this example.';button.disabled=true;amount.disabled=true;button.textContent='Preview request shown';});});

// Revalidate authenticated public/partner pages restored from browser history.
window.addEventListener('pageshow',event=>{if(event.persisted&&document.body.dataset.webAuth==='1')window.location.reload()});

// The server, not a copied browser tariff, calculates every ROI estimate.
(()=>{
 const form=document.querySelector('#roi-form'),results=document.querySelector('#roi-results'),status=document.querySelector('#roi-status');if(!form||!results)return;
 let timer,controller,version=0,lastKey='';
 const mobileSummary=document.querySelector('.roi-mobile-summary strong');function syncSummary(){if(mobileSummary)mobileSummary.textContent=results.classList.contains('roi-stale')?'Update needed':(results.querySelector('[data-roi-net]')?.textContent||'A current quote is needed');}syncSummary();
 function markStale(message,error=false){results.classList.add('roi-stale');status.textContent=message;status.classList.toggle('roi-status-error',error);syncSummary()}
 async function calculate(force=false){
  if(!form.checkValidity()){markStale('Complete the highlighted fields to update your estimate.',true);return;}
  const params=new URLSearchParams(new FormData(form));params.set('roi_quote','1');const key=params.toString();if(!force&&key===lastKey)return;
  const request=++version;controller?.abort();controller=new AbortController();results.setAttribute('aria-busy','true');markStale('Checking current pricing and updating your estimate…');
  const url=new URL(form.action||location.href);url.search=params.toString();url.hash='';const timeout=setTimeout(()=>controller?.abort(),15000);
  try{const response=await fetch(url,{signal:controller.signal,cache:'no-store',headers:{Accept:'application/json'}});const data=await response.json();if(request!==version)return;if(!response.ok||!data.ok)throw Error(data.error||'Unable to check current pricing.');results.innerHTML=data.html;results.classList.remove('roi-stale');lastKey=key;syncSummary();status.classList.remove('roi-status-error');status.textContent='Updated using current published prices. Your assumptions remain unchanged.';}
  catch(error){if(request===version)markStale(error.name==='AbortError'?'Pricing check timed out. Press Calculate to retry.':error.message||'Unable to update. Please try again.',true);}
  finally{clearTimeout(timeout);if(request===version)results.removeAttribute('aria-busy');}
 }
 function queue(){version++;controller?.abort();results.removeAttribute('aria-busy');clearTimeout(timer);markStale('Your inputs changed. Updating the estimate…');timer=setTimeout(()=>calculate(true),500);}
 form.addEventListener('input',queue);form.addEventListener('change',queue);
 form.addEventListener('submit',e=>{e.preventDefault();clearTimeout(timer);if(form.reportValidity())calculate(true).then(()=>{if(innerWidth<=760&&!results.classList.contains('roi-stale'))results.scrollIntoView({behavior:reduced.matches?'auto':'smooth',block:'start'})})});
 form.querySelector('.roi-reset')?.addEventListener('click',()=>{for(const [k,v]of Object.entries({pupils:300,fees:100000,terms:3,unpaid:10,recovery:1,savings:150000,extras:0,plan:'auto',cycle:'annual'}))form.elements.namedItem(k).value=v;calculate(true)});
 // Refresh cached/background tabs and long-open sessions after package edits.
 let lastRefresh=Date.now();function refresh(){if(document.visibilityState==='visible'&&Date.now()-lastRefresh>60000){lastRefresh=Date.now();calculate(true)}}
 document.addEventListener('visibilitychange',refresh);window.addEventListener('focus',refresh);setInterval(refresh,60000);
 results.addEventListener('click',e=>{if(!e.target.closest('.roi-print'))return;if(results.classList.contains('roi-stale'))return;window.print();});
})();
(()=>{if(!document.querySelector('#roi-results'))return;let detail,opened=false,printing=false;window.addEventListener('beforeprint',()=>{if(printing)return;printing=true;detail=document.querySelector('.roi-breakdown');if(detail){opened=detail.open;detail.open=true}});window.addEventListener('afterprint',()=>{if(!printing)return;if(detail)detail.open=opened;printing=false})})();
