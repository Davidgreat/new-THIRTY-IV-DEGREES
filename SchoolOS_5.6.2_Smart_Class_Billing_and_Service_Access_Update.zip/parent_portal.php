<?php
/** SchoolOS Family Space. Loaded before output; uses the existing login and PDO connection. */
if(!defined('SCHOOLOS_PARENT_LIBRARY')){header('Location: index.php?s=family',true,302);exit;}
function pp_tables(): array {return [
"CREATE TABLE IF NOT EXISTS pp_posts(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,tenant_id BIGINT UNSIGNED NOT NULL,kind VARCHAR(20) NOT NULL,title VARCHAR(200) NOT NULL,body TEXT NOT NULL,class_id BIGINT UNSIGNED NULL,student_id BIGINT UNSIGNED NULL,starts_at DATETIME NULL,ends_at DATETIME NULL,options_json TEXT NULL,active TINYINT NOT NULL DEFAULT 1,created_by BIGINT UNSIGNED NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(tenant_id,kind,active)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS pp_documents(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,tenant_id BIGINT UNSIGNED NOT NULL,post_id BIGINT UNSIGNED NOT NULL,filename VARCHAR(180) NOT NULL,mime VARCHAR(100) NOT NULL,content MEDIUMBLOB NOT NULL,UNIQUE KEY post_doc(tenant_id,post_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS pp_responses(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,tenant_id BIGINT UNSIGNED NOT NULL,post_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,student_id BIGINT UNSIGNED NOT NULL,answer TEXT NOT NULL,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,UNIQUE KEY one_response(tenant_id,post_id,user_id,student_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS pp_requests(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,tenant_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,student_id BIGINT UNSIGNED NOT NULL,kind VARCHAR(20) NOT NULL,subject VARCHAR(200) NOT NULL,body TEXT NOT NULL,starts_on DATE NULL,ends_on DATE NULL,recipient_id BIGINT UNSIGNED NULL,status VARCHAR(20) NOT NULL DEFAULT 'pending',reply TEXT NULL,reviewed_by BIGINT UNSIGNED NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(tenant_id,user_id,student_id),INDEX(tenant_id,recipient_id,status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS pp_slots(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,tenant_id BIGINT UNSIGNED NOT NULL,teacher_user_id BIGINT UNSIGNED NOT NULL,starts_at DATETIME NOT NULL,ends_at DATETIME NOT NULL,active TINYINT NOT NULL DEFAULT 1,UNIQUE KEY teacher_start(tenant_id,teacher_user_id,starts_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS pp_bookings(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,tenant_id BIGINT UNSIGNED NOT NULL,slot_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,student_id BIGINT UNSIGNED NOT NULL,status VARCHAR(20) NOT NULL DEFAULT 'booked',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(tenant_id,slot_id,status),INDEX(tenant_id,user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
];}
function pp_install(): void {global $pdo;foreach(pp_tables() as $s)$pdo->exec($s);}
function pp_ready(): bool {try{foreach(['pp_posts','pp_documents','pp_responses','pp_requests','pp_slots','pp_bookings','ecosystem_links','ecosystem_support'] as $t)if(!g('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?',[$t]))return false;return true;}catch(Throwable $e){return false;}}
function pp_has(string $table): bool {return (bool)g('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?',[$table]);}
function pp_actor(): array {
 $u=me();if(!$u||(int)($u['tenant_id']??0)<1||!in_array($u['role'],['parent','school_admin','teacher'],true))throw new RuntimeException('School parent, teacher or administrator access required.');
 // Recheck current account state instead of trusting a stale login snapshot.
 $active=q('SELECT id FROM users WHERE id=? AND tenant_id=? AND role=? AND active=1',[$u['id'],$u['tenant_id'],$u['role']])->fetch();
 if(!$active)throw new RuntimeException('Account is no longer active.');return $u;
}
function pp_children(array $u): array {
 return q("SELECT DISTINCT s.*,c.name class_name FROM ecosystem_links l JOIN students s ON s.id=l.student_id AND s.tenant_id=l.tenant_id LEFT JOIN classes c ON c.id=s.class_id AND c.tenant_id=s.tenant_id WHERE l.tenant_id=? AND l.user_id=? AND l.relation_type='parent' ORDER BY s.name,s.id",[$u['tenant_id'],$u['id']])->fetchAll();
}
function pp_child(array $u,int $sid): array {
 foreach(pp_children($u) as $s)if((int)$s['id']===$sid)return $s;
 throw new RuntimeException('Child is not linked to your account.');
}
function pp_text(string $key,int $max=2000): string {
 $v=$_POST[$key]??'';if(!is_string($v))throw new RuntimeException('Invalid input.');$v=trim($v);
 if(mb_strlen($v)>$max)throw new RuntimeException('Input too long: '.$key);return $v;
}
function pp_date(string $v): string {$d=DateTimeImmutable::createFromFormat('!Y-m-d',$v);if(!$d||$d->format('Y-m-d')!==$v)throw new RuntimeException('Invalid date.');return $v;}
function pp_datetime(string $v): string {$d=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',$v);if(!$d||$d->format('Y-m-d\TH:i')!==$v)throw new RuntimeException('Invalid appointment time.');return $d->format('Y-m-d H:i:s');}
function pp_visible(array $p,array $s): bool {return (!(int)($p['student_id']??0)||(int)$p['student_id']===(int)$s['id'])&&(!(int)($p['class_id']??0)||(int)$p['class_id']===(int)$s['class_id']);}
function pp_post(array $u,array $s,int $id,bool $lock=false): array {
 $p=q('SELECT * FROM pp_posts WHERE tenant_id=? AND id=? AND active=1'.($lock?' FOR UPDATE':''),[$u['tenant_id'],$id])->fetch();
 if(!$p||!pp_visible($p,$s)||(function_exists('px_post_visible')&&!px_post_visible($p,$u)))throw new RuntimeException('Item is unavailable.');return $p;
}
function pp_invoice(array $u,int $id): array {
 $i=q('SELECT * FROM fn_invoices WHERE tenant_id=? AND id=?',[$u['tenant_id'],$id])->fetch();
 if(!$i)throw new RuntimeException('Invoice not found.');pp_child($u,(int)$i['student_id']);return $i;
}
function pp_payment(array $u,string $action,?callable $transport=null): string {
 $api=$transport??'fn45Api';
 global $pdo;$tid=(int)$u['tenant_id'];$uid=(int)$u['id'];
 if(!pp_has('fn45_gateway')||!function_exists('fnConfirmPayment'))throw new RuntimeException('Ask the school to activate Finance and Paystack integration.');
 if($action==='pay'){
  $i=pp_invoice($u,(int)($_POST['invoice_id']??0));sbf_pay_guard((int)$u['tenant_id'],(int)$i['id']);$balance=(int)$i['amount_kobo']-(int)$i['discount_kobo']+(int)$i['penalty_kobo']-(int)$i['paid_kobo'];
  if(in_array($i['status'],['void','cancelled'],true))throw new RuntimeException('This invoice has been cancelled.');if($balance<=0)throw new RuntimeException('Invoice is already settled.');
  if(!filter_var($u['email'],FILTER_VALIDATE_EMAIL))throw new RuntimeException('Valid account email required.');
  $ref='SOS-'.$tid.'-'.$i['id'].'-'.bin2hex(random_bytes(10));
  $resp=$api('POST','/transaction/initialize',fn45Secret($tid),['email'=>$u['email'],'amount'=>$balance,'reference'=>$ref,'currency'=>'NGN','metadata'=>['tenant_id'=>$tid,'invoice_id'=>(int)$i['id']]]);
  $url=(string)($resp['data']['authorization_url']??'');if(!preg_match('~^https://checkout\.paystack\.com/~',$url))throw new RuntimeException('Unexpected checkout URL.');
  q('INSERT INTO fn45_gateway(tenant_id,invoice_id,reference,amount_kobo,authorization_url) VALUES(?,?,?,?,?)',[$tid,$i['id'],$ref,$balance,$url]);
  return 'Checkout created. Open the secure Paystack link below, then select Verify payment.';
 }
 $gw=q('SELECT * FROM fn45_gateway WHERE tenant_id=? AND id=?',[$tid,(int)($_POST['gateway_id']??0)])->fetch();
 if(!$gw)throw new RuntimeException('Transaction not found.');pp_invoice($u,(int)$gw['invoice_id']);
 if($gw['status']==='confirmed')return 'Payment already verified.';
 // Network verification outside SQL transaction; lock and recheck before posting once.
 $resp=$api('GET','/transaction/verify/'.rawurlencode($gw['reference']),fn45Secret($tid));$data=$resp['data']??[];
 if(($data['status']??'')!=='success'||($data['reference']??'')!==$gw['reference']||!isset($data['amount'])||(string)$data['amount']!==(string)$gw['amount_kobo']||($data['currency']??'')!=='NGN')throw new RuntimeException('Provider has not confirmed the expected payment.');
 $pdo->beginTransaction();try{
  $locked=q('SELECT * FROM fn45_gateway WHERE tenant_id=? AND id=? FOR UPDATE',[$tid,$gw['id']])->fetch();
  pp_invoice($u,(int)$locked['invoice_id']);
  if($locked['status']!=='confirmed'){
   q("INSERT INTO fn_payments(tenant_id,invoice_id,reference,amount_kobo,channel,status,notes) VALUES(?,?,?,?,?,'pending',?)",[$tid,$gw['invoice_id'],$gw['reference'],$gw['amount_kobo'],'paystack','Parent portal: verified server-to-server']);
   fnConfirmPayment($tid,(int)$pdo->lastInsertId(),$uid);
   q("UPDATE fn45_gateway SET status='confirmed',verified_at=NOW() WHERE tenant_id=? AND id=?",[$tid,$gw['id']]);
   audit('family.payment.verified','invoice',(string)$gw['invoice_id']);
  }$pdo->commit();return 'Payment verified and posted to Finance.';
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function pp_action(array $u): string {
 global $pdo;$tid=(int)$u['tenant_id'];$uid=(int)$u['id'];
 if(!hash_equals((string)($_SESSION['csrf']??''),(string)($_POST['csrf']??'')))throw new RuntimeException('Security token expired.');
 $a=pp_text('pp_action',30);$admin=$u['role']==='school_admin';
 if($a==='activate'){if(!$admin)throw new RuntimeException('School administrator required.');if(!pp_has('ecosystem_links')||!pp_has('ecosystem_support'))throw new RuntimeException('Activate the ecosystem first.');pp_install();return 'Family Space activated. Existing records preserved.';}
 if(!pp_ready())throw new RuntimeException('Family Space needs activation by the school administrator.');
 if($u['role']==='parent'){
  if(in_array($a,['pay','verify'],true))return pp_payment($u,$a);
  $s=pp_child($u,(int)($_POST['child']??0));$sid=(int)$s['id'];
  if(in_array($a,['absence','pickup','pickup_regular','message','ticket'],true)){
   $subject=pp_text('subject',200);$body=pp_text('body',2000);if(!$subject||!$body)throw new RuntimeException('Subject and details required.');
   if($a==='ticket'){q("INSERT INTO ecosystem_support(tenant_id,created_by,subject,message,status) VALUES(?,?,?,?,'open')",[$tid,$uid,$subject,'Student #'.$sid.': '.$body]);return 'Support ticket opened in Support Desk.';}
   $start=null;$end=null;$recipient=null;
   if(in_array($a,['absence','pickup','pickup_regular'],true)){$start=pp_date(pp_text('starts_on',10));$end=in_array($a,['absence','pickup_regular'],true)?pp_date(pp_text('ends_on',10)):$start;if($end<$start)throw new RuntimeException('End date must follow start date.');}
   if(in_array($a,['pickup','pickup_regular'],true)){if($start<date('Y-m-d')||($a==='pickup_regular'&&($end<date('Y-m-d')||strtotime($end)>strtotime($start.' +1 year'))))throw new RuntimeException('Choose today or a future date; regular approval can cover up to one year.'); $phone=pp_text('collector_phone',30);if(!preg_match('/^\+?[0-9][0-9 ()-]{6,24}$/D',$phone)||strlen(preg_replace('/\D/','',$phone))>15)throw new RuntimeException('Provide a valid phone number for the authorized collector.');$body='Collector phone: '.$phone."\n".$body;}
   if($a==='message'&&function_exists('px_recipients')){$recipients=px_recipients($u,$_POST['recipient_ids']??($_POST['recipient_id']??[]));foreach($recipients as $r){if(!in_array($r['role'],['teacher','school_admin'],true))throw new RuntimeException('Choose assigned teachers or your school administrator.');if($r['role']==='teacher'&&!g('SELECT a.teacher_id FROM ac_allocations a JOIN classes c ON c.id=a.class_id AND c.tenant_id=a.tenant_id AND CONVERT(c.session_name USING utf8mb4) COLLATE utf8mb4_unicode_ci=CONVERT(a.session_name USING utf8mb4) COLLATE utf8mb4_unicode_ci WHERE a.tenant_id=? AND a.teacher_id=? AND a.class_id=? LIMIT 1',[$tid,$r['id'],$s['class_id']]))throw new RuntimeException('Choose a teacher allocated to the selected child.');}return xp_tx(function()use($tid,$uid,$sid,$subject,$body,$recipients){foreach($recipients as $r)q("INSERT INTO pp_requests(tenant_id,user_id,student_id,kind,subject,body,recipient_id) VALUES(?,?,?,'message',?,?,?)",[$tid,$uid,$sid,$subject,$body,$r['id']]);audit('family.message.multiple','student',(string)$sid);return 'Message delivered to '.count($recipients).' school recipients.';});}
   if($a==='message'){$recipient=(int)($_POST['recipient_id']??0);if(!g("SELECT id FROM users WHERE tenant_id=? AND id=? AND role IN ('teacher','school_admin') AND active=1",[$tid,$recipient]))throw new RuntimeException('Choose a school teacher or administrator.');}
   q('INSERT INTO pp_requests(tenant_id,user_id,student_id,kind,subject,body,starts_on,ends_on,recipient_id) VALUES(?,?,?,?,?,?,?,?,?)',[$tid,$uid,$sid,$a,$subject,$body,$start,$end,$recipient]);audit('family.request',$a,(string)$pdo->lastInsertId());return 'Request submitted for school review.';
  }
  if($a==='respond'){
   $pdo->beginTransaction();try{
    $p=pp_post($u,$s,(int)($_POST['post_id']??0),true);
    if(!in_array($p['kind'],['consent','survey','meals'],true))throw new RuntimeException('This item does not accept responses.');
    if(($p['ends_at']&&$p['ends_at']<date('Y-m-d H:i:s'))||($p['starts_at']&&$p['starts_at']>date('Y-m-d H:i:s')))throw new RuntimeException('Response window is closed.');
    $answer=pp_text('answer',2000);if($p['kind']==='meals')sbe_require($tid,$sid,'meals',substr($p['ends_at']?:($p['starts_at']?:date('Y-m-d')),0,10));$opts=json_decode($p['options_json']?:'[]',true);
    if(!$answer||($p['kind']==='consent'&&!in_array($answer,['yes','no'],true))||($p['kind']!=='consent'&&$opts&&!in_array($answer,$opts,true)))throw new RuntimeException('Choose a valid response.');
    q('INSERT INTO pp_responses(tenant_id,post_id,user_id,student_id,answer) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE answer=VALUES(answer)',[$tid,$p['id'],$uid,$sid,$answer]);audit('family.response',$p['kind'],(string)$p['id']);$pdo->commit();return 'Response saved for '.$s['name'].'.';
   }catch(Throwable $e){$pdo->rollBack();throw $e;}
  }
  if($a==='book'||$a==='cancel_booking'){
   $pdo->beginTransaction();try{
    $slot=q('SELECT * FROM pp_slots WHERE tenant_id=? AND id=? FOR UPDATE',[$tid,(int)($_POST['slot_id']??0)])->fetch();
    if(!$slot||!$slot['active']||$slot['starts_at']<=date('Y-m-d H:i:s'))throw new RuntimeException('Appointment is unavailable.');
    if($a==='cancel_booking'){if(q("UPDATE pp_bookings SET status='cancelled' WHERE tenant_id=? AND slot_id=? AND user_id=? AND student_id=? AND status='booked'",[$tid,$slot['id'],$uid,$sid])->rowCount()!==1)throw new RuntimeException('No matching booking is available to cancel.');}
    else{
     if(g("SELECT id FROM pp_bookings WHERE tenant_id=? AND slot_id=? AND status='booked'",[$tid,$slot['id']]))throw new RuntimeException('This slot is already booked.');
     q('INSERT INTO pp_bookings(tenant_id,slot_id,user_id,student_id) VALUES(?,?,?,?)',[$tid,$slot['id'],$uid,$sid]);
    }$pdo->commit();return $a==='book'?'Appointment booked.':'Appointment cancelled.';
   }catch(Throwable $e){$pdo->rollBack();throw $e;}
  }
  if($a==='revoke_pickup'){
   if(q("UPDATE pp_requests SET status='revoked' WHERE tenant_id=? AND id=? AND user_id=? AND student_id=? AND kind IN ('pickup','pickup_regular') AND status IN ('pending','approved')",[$tid,(int)($_POST['request_id']??0),$uid,$sid])->rowCount()!==1)throw new RuntimeException('Pickup request is unavailable or already revoked.');audit('family.pickup.revoked','request',(string)($_POST['request_id']??0));return 'Pickup authorization revoked.';
  }
  throw new RuntimeException('Unsupported parent action.');
 }
 if($a==='slot'){
  $teacher=$admin?(int)($_POST['teacher_user_id']??0):$uid;
  if(!g("SELECT id FROM users WHERE tenant_id=? AND id=? AND role='teacher' AND active=1",[$tid,$teacher]))throw new RuntimeException('Choose a teacher.');
  $start=pp_datetime(pp_text('starts_at',16));$end=pp_datetime(pp_text('ends_at',16));if($end<=$start||$start<=date('Y-m-d H:i:s'))throw new RuntimeException('Choose a future appointment and valid end time.');
  // Serialize slot creation on the teacher account, preventing overlapping appointments.
  $pdo->beginTransaction();try{
   q('SELECT id FROM users WHERE id=? AND tenant_id=? FOR UPDATE',[$teacher,$tid]);
   if(g('SELECT id FROM pp_slots WHERE tenant_id=? AND teacher_user_id=? AND active=1 AND starts_at<? AND ends_at>?',[$tid,$teacher,$end,$start]))throw new RuntimeException('Teacher already has an overlapping slot.');
   q('INSERT INTO pp_slots(tenant_id,teacher_user_id,starts_at,ends_at) VALUES(?,?,?,?)',[$tid,$teacher,$start,$end]);$pdo->commit();return 'Appointment slot published.';
  }catch(Throwable $e){$pdo->rollBack();throw $e;}
 }
 if($a==='revoke_regular'){if(!$admin)throw new RuntimeException('School administrator required.');if(q("UPDATE pp_requests SET status='revoked',reviewed_by=? WHERE tenant_id=? AND id=? AND kind='pickup_regular' AND status IN ('pending','approved')",[$uid,$tid,(int)($_POST['request_id']??0)])->rowCount()!==1)throw new RuntimeException('Regular collector approval is no longer active.');audit('family.collector.revoked','request',(string)($_POST['request_id']??0));return 'Regular collector approval revoked immediately.';}
 if($a==='review'){
  $id=(int)($_POST['request_id']??0);$r=q('SELECT * FROM pp_requests WHERE tenant_id=? AND id=?',[$tid,$id])->fetch();
  if(!$r||(!$admin&&($r['kind']!=='message'||(int)$r['recipient_id']!==$uid)))throw new RuntimeException('Request is unavailable.');
  $status=pp_text('status',20);$allowed=$r['kind']==='message'?['replied','closed']:['approved','rejected'];
  if(!in_array($status,$allowed,true)||in_array($r['status'],['revoked','collected'],true))throw new RuntimeException('Invalid review status.');
  if($r['kind']==='pickup_regular'&&$status==='approved'&&!pp_collector_linked($r))throw new RuntimeException('An active linked parent must sponsor this regular collector.');
  $reply=pp_text('reply',2000);if(!$reply)throw new RuntimeException('Provide a reply or review note.');
  $st=q('UPDATE pp_requests SET status=?,reply=?,reviewed_by=? WHERE tenant_id=? AND id=? AND status=?',[$status,$reply,$uid,$tid,$id,$r['status']]);if($st->rowCount()!==1)throw new RuntimeException('Request changed. Refresh and review again.');
  audit('family.review',$r['kind'],(string)$id);return 'Review saved. Absence approval does not rewrite attendance; pickup still requires identity checks.';
 }
 if(!$admin)throw new RuntimeException('School administrator required.');
 if($a==='publish'){
  $kind=pp_text('kind',20);if(!in_array($kind,['calendar','consent','transport','meals','document','survey'],true))throw new RuntimeException('Invalid item type.');
  $title=pp_text('title',200);$body=pp_text('body',4000);if(!$title||!$body)throw new RuntimeException('Title and details required.');
  $class=(int)($_POST['class_id']??0);$student=(int)($_POST['student_id']??0);
  if($class&&!g('SELECT id FROM classes WHERE tenant_id=? AND id=?',[$tid,$class]))throw new RuntimeException('Invalid class.');
  if($student&&!g('SELECT id FROM students WHERE tenant_id=? AND id=?',[$tid,$student]))throw new RuntimeException('Invalid student.');
  $start=pp_text('starts_at',16);$end=pp_text('ends_at',16);$start=$start?pp_datetime($start):null;$end=$end?pp_datetime($end):null;
  if($start&&$end&&$end<=$start)throw new RuntimeException('Invalid date range.');
  $options=array_values(array_filter(array_map('trim',explode("\n",pp_text('options',2000))),fn($s)=>$s!==''));if(count($options)>30)throw new RuntimeException('Too many options.');
  if($kind==='calendar'&&(!$start||!$end))throw new RuntimeException('Set the calendar event’s start and end date/time.');if($kind==='meals'&&(!$options||!$start||!$end||strtotime($end)-strtotime($start)>31*86400))throw new RuntimeException('Enter meal choices and a menu start/end date covering no more than 31 days.');
  $doc=null;if($kind==='document'){
   $f=$_FILES['document']??null;if(!$f||$f['error']!==UPLOAD_ERR_OK||$f['size']<1||$f['size']>2097152)throw new RuntimeException('Document must be 1 byte to 2 MB.');
   $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);if(!in_array($mime,['application/pdf','image/jpeg','image/png','image/webp'],true))throw new RuntimeException('Only PDF and images allowed.');
   $doc=['filename'=>mb_substr(basename($f['name']),0,180),'mime'=>$mime,'content'=>file_get_contents($f['tmp_name'])];
  }
  $pdo->beginTransaction();try{
   q('INSERT INTO pp_posts(tenant_id,kind,title,body,class_id,student_id,starts_at,ends_at,options_json,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)',[$tid,$kind,$title,$body,$class?:null,$student?:null,$start,$end,json_encode($options,JSON_THROW_ON_ERROR),$uid]);$pid=(int)$pdo->lastInsertId();
   if($doc)q('INSERT INTO pp_documents(tenant_id,post_id,filename,mime,content) VALUES(?,?,?,?,?)',[$tid,$pid,$doc['filename'],$doc['mime'],$doc['content']]);
   if(function_exists('px_publish_meta'))px_publish_meta($u,$pid,$kind);audit('family.publish',$kind,(string)$pid);$pdo->commit();return 'Published to the selected families.';
  }catch(Throwable $e){$pdo->rollBack();throw $e;}
 }
 if($a==='close_post'){q('UPDATE pp_posts SET active=0 WHERE tenant_id=? AND id=?',[$tid,(int)($_POST['post_id']??0)]);return 'Item closed. Responses retained.';}
 throw new RuntimeException('Unsupported staff action.');
}
function pp_parent_document(array $u,int $sid,int $id):array {
 $s=pp_child($u,$sid);$d=q("SELECT d.*,p.kind,p.class_id,p.student_id,p.active FROM pp_documents d JOIN pp_posts p ON p.id=d.post_id AND p.tenant_id=d.tenant_id WHERE d.tenant_id=? AND d.id=? AND p.kind='document'",[$u['tenant_id'],$id])->fetch();$post=$d?:[];if($d)$post['id']=$d['post_id'];if(!$d||!$d['active']||!pp_visible($d,$s)||(function_exists('px_post_visible')&&!px_post_visible($post,$u)))throw new RuntimeException('Document not found.');return $d;
}
function pp_download(array $u): void {
 try{$d=pp_parent_document($u,(int)($_GET['child']??0),(int)$_GET['pp_document']);}catch(RuntimeException){http_response_code(404);exit('Document not found.');}
 header('Content-Type: '.$d['mime']);header('Content-Disposition: attachment; filename="'.preg_replace('/[^A-Za-z0-9._-]/','_',$d['filename']).'"');header('Cache-Control: private, no-store');header('X-Content-Type-Options: nosniff');echo $d['content'];exit;
}
function pp_form(string $action,int $sid=0): void {echo '<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'"><input type="hidden" name="pp_action" value="'.e($action).'"><input type="hidden" name="child" value="'.$sid.'">';}
function pp_field(string $name,string $label,string $type='text',bool $required=true): void {echo '<label>'.e($label).($type==='textarea'?'<textarea rows="3" name="'.e($name).'" maxlength="2000"'.($required?' required':'').'></textarea>':'<input name="'.e($name).'" type="'.e($type).'"'.($required?' required':'').'>').'</label>';}
function pp_end(string $label): void {echo '<button class="btn">'.e($label).'</button></form>';}
function pp_table(array $rows,array $labels): void {
 echo '<div class="pp-scroll"><table class="table"><tr>';foreach($labels as $l)echo '<th>'.e($l).'</th>';echo '</tr>';
 foreach($rows as $r){echo '<tr>';foreach($r as $v)echo '<td>'.e($v).'</td>';echo '</tr>';}
 echo '</table></div>';if(!$rows)echo '<p class="muted">No records available.</p>';
}
function pp_render(array $u): void {
 $tid=(int)$u['tenant_id'];$uid=(int)$u['id'];$admin=$u['role']==='school_admin';
 echo '<div class="pf-portal">';echo '<style>.pp-nav{display:flex;flex-wrap:wrap;gap:8px;margin:18px 0}.pp-nav a{padding:9px 12px;border:1px solid #cbd5e1;border-radius:9px;color:inherit;text-decoration:none}.pp-nav a[aria-current=page]{background:#075e56;color:white}.pp-card{background:var(--card,#fff);border:1px solid #d7e3e6;border-radius:16px;padding:22px;margin:14px 0}.pp-card label{display:block;margin:12px 0}.pp-card input,.pp-card textarea,.pp-card select{display:block;max-width:100%;box-sizing:border-box;width:100%;padding:10px;border:1px solid #aabdc8;border-radius:7px;font:inherit}.pp-scroll{overflow:auto}.pp-card p{white-space:pre-wrap}.pp-hero{background:linear-gradient(110deg,#13394c,#08796e);color:white;border-radius:18px;padding:24px}.pp-card form{margin:16px 0}.pp-card button{margin:8px 0}</style><div class="pp-hero"><h2>'.($u['role']==='parent'?'Parent & Guardian Portal':($u['role']==='teacher'?'Family appointments & replies':'Family engagement desk')).'</h2><p>'.($u['role']==='parent'?'Your family’s school day, in one place.':'Coordinate appointments and respond to the families connected to your work.').'</p></div>';
 if(!pp_ready()){
  echo '<div class="pp-card"><h3>Activate Family Space</h3><p>Back up the database first. Activation adds six tables without altering existing records. Activate Ecosystem Hub first.</p>';
  if($admin){pp_form('activate');pp_end('Activate Family Space');}else echo '<p>Ask your school administrator to activate Family Space.</p>';echo '</div></div>';return;
 }
 if($u['role']!=='parent'){pp_staff($u);echo '</div>';return;}
 $children=pp_children($u);if(!$children){echo '<div class="pp-card">No children are linked yet. Ask your school to link your parent account under Account Links. Matching names or emails never grants access.</div></div>';return;}
 $sid=(int)($_GET['child']??0);if($sid===0)$sid=(int)$children[0]['id'];$s=pp_child($u,$sid);
 $tabs=['children'=>'Family overview','results'=>'Results & report cards','attendance'=>'Attendance log','fees'=>'Bills & payments','services'=>'Optional school services','benefits'=>'Service access & events','receipts'=>'Receipts','homework'=>'Homework & learning','messages'=>'Family & school chat','calendar'=>'School calendar','bookings'=>'Parent–teacher bookings','absence'=>'Absence requests','consent'=>'Consent forms','pickup'=>'Collectors & pickup','transport'=>'School bus & journeys','boarding'=>'Boarding & welfare','meals'=>'School meals','documents'=>'School documents','support'=>'Support tickets','surveys'=>'Parent feedback','timetable'=>'Class timetable','library'=>'My children’s books','shop'=>'School shop','preferences'=>'Contact & message preferences'];
 $tab=(string)($_GET['view']??'children');if(!isset($tabs[$tab]))$tab='children';
 echo '<nav class="pp-nav" aria-label="Children">';foreach($children as $child)echo '<a href="?s=family&amp;child='.(int)$child['id'].'&amp;view='.e($tab).'" '.((int)$child['id']===$sid?'aria-current="page"':'').'>'.e($child['name']).'</a>';echo '</nav>';px_feature_navigation($tabs,$tab,'family','&amp;child='.$sid);echo '<div class="pp-card"><h2>'.e($tabs[$tab]).' · '.e($s['name']).'</h2>';

 if($tab==='children'){pp_parent_home($u,$children,$s);}
 elseif($tab==='results'){pp_parent_results($u,$s);}
 elseif($tab==='messages'){pp_parent_contacts($u,$children,$s);}
 elseif($tab==='timetable'){pp_parent_timetable($u,$s);}
 elseif($tab==='library'){pp_parent_library($u,$s);}
 elseif($tab==='shop'){pp_parent_shop($u,$s);}
 elseif($tab==='preferences'){pp_parent_preferences($u,$s);}
 elseif($tab==='attendance'){pp_parent_attendance($u,$s);
  if(pp_has('aw_period_attendance')){echo '<details class="px-composer"><summary>Recent lesson-by-lesson attendance</summary>';pp_table(q('SELECT attendance_date,period_name,status,reason FROM aw_period_attendance WHERE tenant_id=? AND student_id=? ORDER BY attendance_date DESC LIMIT 100',[$tid,$sid])->fetchAll(),['Date','Period','Status','Reason']);echo '</details>';}
 }
 elseif($tab==='homework'){pp_parent_homework($u,$s);
  if(pp_has('ac_lessons'))pp_table(q("SELECT l.lesson_date,sub.name,c.topic,l.homework FROM ac_lessons l JOIN ac_curriculum c ON c.id=l.curriculum_id AND c.tenant_id=l.tenant_id JOIN subjects sub ON sub.id=c.subject_id AND sub.tenant_id=c.tenant_id WHERE l.tenant_id=? AND c.class_id=? AND CONVERT(c.session_name USING utf8mb4) COLLATE utf8mb4_unicode_ci=CONVERT((SELECT session_name FROM classes WHERE tenant_id=l.tenant_id AND id=c.class_id) USING utf8mb4) COLLATE utf8mb4_unicode_ci AND l.status='delivered' AND l.homework IS NOT NULL AND l.homework<>'' ORDER BY l.lesson_date DESC LIMIT 100",[$tid,$s['class_id']])->fetchAll(),['Lesson date','Subject','Topic','Homework']);else echo '<p>No published academic homework yet.</p>';
 }
 elseif($tab==='benefits'){sbe_entitlement_view($u,$s);}
 elseif($tab==='services'){sbf_family($u,$s);}
 elseif($tab==='fees'||$tab==='receipts'){pp_finance_view($u,$s,$tab);}
 elseif($tab==='boarding'){bd_render($u);}
 elseif($tab==='bookings'){
  $slots=q("SELECT sl.*,u.name teacher FROM pp_slots sl JOIN users u ON u.id=sl.teacher_user_id AND u.tenant_id=sl.tenant_id AND u.active=1 WHERE sl.tenant_id=? AND sl.active=1 AND sl.starts_at>? ORDER BY sl.starts_at LIMIT 100",[$tid,date('Y-m-d H:i:s')])->fetchAll();
  foreach($slots as $slot){$book=q("SELECT * FROM pp_bookings WHERE tenant_id=? AND slot_id=? AND status='booked'",[$tid,$slot['id']])->fetch();echo '<h3>'.e($slot['teacher']).'</h3><p>'.e($slot['starts_at']).' – '.e($slot['ends_at']).' (Africa/Lagos)</p>';
   if(!$book||((int)$book['user_id']===$uid&&(int)$book['student_id']===$sid)){pp_form($book?'cancel_booking':'book',$sid);echo '<input type="hidden" name="slot_id" value="'.(int)$slot['id'].'">';pp_end($book?'Cancel my booking':'Book appointment');}else echo '<p>Unavailable</p>';
  }if(!$slots)echo '<p>No appointment slots have been published.</p>';
 }
 elseif($tab==='pickup'){pp_collectors_view($u,$s);}
 elseif(in_array($tab,['absence','messages','support'],true)){
  $a=['absence'=>'absence','pickup'=>'pickup','messages'=>'message','support'=>'ticket'][$tab];pp_form($a,$sid);pp_field('subject',$a==='pickup'?'Authorized adult’s full name':'Subject');
  pp_field('body',$a==='pickup'?'Relationship, phone, pickup window and identity-check instructions':'Details','textarea');
  if($a==='absence'){pp_field('starts_on','First absence date','date');pp_field('ends_on','Last absence date','date');}
  if($a==='pickup'){pp_field('collector_phone','Authorized adult’s phone number','tel');pp_field('starts_on','Pickup date','date');}
  if($a==='message'){echo '<p><a class="btn" href="?s=chat">Open live school conversations →</a></p><label>Recipients (choose one or more)<select name="recipient_ids[]" multiple size="5" required>';foreach(px_contacts($u) as $r)if(in_array($r['role'],['teacher','school_admin'],true))echo '<option value="'.(int)$r['id'].'">'.e($r['name'].' · '.$r['role']).'</option>';echo '</select></label>';}
  pp_end($a==='pickup'?'Request pickup authorization':'Submit');if($a==='pickup')px_pickup_tokens($u,$s);
  if($a==='ticket')pp_table(q('SELECT id,subject,message,status,created_at FROM ecosystem_support WHERE tenant_id=? AND created_by=? ORDER BY id DESC LIMIT 100',[$tid,$uid])->fetchAll(),['Ticket','Subject','Message','Status','Created']);
  else{
   $rows=q('SELECT id,subject,body,starts_on,ends_on,status,reply FROM pp_requests WHERE tenant_id=? AND user_id=? AND student_id=? AND kind=? ORDER BY id DESC LIMIT 100',[$tid,$uid,$sid,$a])->fetchAll();pp_table($rows,['ID','Subject','Details','From','To','Status','School reply']);
   if($a==='pickup'){echo '<p>School approval and physical identity checks are required. This portal does not prove the collector’s identity.</p>';foreach($rows as $r)if(in_array($r['status'],['pending','approved'],true)){pp_form('revoke_pickup',$sid);echo '<input type="hidden" name="request_id" value="'.(int)$r['id'].'">';pp_end('Revoke authorization #'.$r['id']);}}
  }
 }
 else{
  if($tab==='transport'){echo '<p><a class="btn" href="?s=family&amp;view=services&amp;child='.$sid.'">Choose or review this child’s bus service →</a></p>';px_transport_view($u,$s);}
  $kind=['surveys'=>'survey','documents'=>'document'][$tab]??$tab;
  $posts=q('SELECT * FROM pp_posts WHERE tenant_id=? AND kind=? AND active=1 ORDER BY COALESCE(starts_at,created_at) DESC LIMIT 200',[$tid,$kind])->fetchAll();$shown=in_array($tab,['calendar','surveys'],true)?eg_portal_cards($u,$s,$tab==='calendar'?'calendar':'survey'):0;
  foreach($posts as $p){if(!pp_visible($p,$s)||!px_post_visible($p,$u))continue;$shown++;if($kind==='calendar'){px_event($p);continue;}if($kind==='meals'&&px_ready()){px_meal_view($u,$s,$p);continue;}echo '<article class="pp-card"><h3>'.e($p['title']).'</h3><p>'.e($p['body']).'</p><small>'.e($p['starts_at']).' '.e($p['ends_at']).'</small>';
   if($kind==='document'){$doc=g('SELECT id FROM pp_documents WHERE tenant_id=? AND post_id=?',[$tid,$p['id']]);echo '<p><a href="?s=family&amp;child='.$sid.'&amp;pp_document='.(int)$doc.'">Download document</a></p>';}
   if(in_array($kind,['consent','survey','meals'],true)){
    $answer=g('SELECT answer FROM pp_responses WHERE tenant_id=? AND post_id=? AND user_id=? AND student_id=?',[$tid,$p['id'],$uid,$sid]);if($answer)echo '<p>Your saved response: '.e($answer).'</p>';
    pp_form('respond',$sid);echo '<input type="hidden" name="post_id" value="'.(int)$p['id'].'">';$opts=$kind==='consent'?['yes','no']:json_decode($p['options_json']?:'[]',true);
    if($opts){echo '<label>Your choice<select name="answer" required>';foreach($opts as $o)echo '<option '.($answer===$o?'selected ':'').'value="'.e($o).'">'.e($o).'</option>';echo '</select></label>';}else pp_field('answer','Your response','textarea');pp_end('Save response');
   }echo '</article>';
  }if(!$shown)echo '<p>No items have been published for this child.</p>';
 }
 echo '</div></div>';
}
function pp_finance_view(array $u,array $s,string $tab): void {
 $tid=(int)$u['tenant_id'];$sid=(int)$s['id'];if($tab==='fees')echo '<p><a class="btn" href="?s=family&amp;view=services&amp;child='.$sid.'">Optional services & this child’s requests →</a></p><p>Compulsory fees and approved optional services appear below as separate bills. Existing paid charges are not changed when you choose another service.</p>';
 if(!pp_has('fn_invoices')){echo '<p>Finance workspace has not been activated.</p>';return;}
 if($tab==='fees'){
  $online=false;if(pp_has('fn45_gateway'))try{fn45Secret($tid);$online=true;}catch(Throwable $e){}if(!$online)echo '<p>Online checkout is not available for this school yet. Contact school accounts for approved payment options. Offline receipts must be verified before your balance changes.</p>';
  $rows=q('SELECT * FROM fn_invoices WHERE tenant_id=? AND student_id=? AND status NOT IN (\'cancelled\',\'void\') ORDER BY id DESC LIMIT 100',[$tid,$sid])->fetchAll();
  foreach($rows as $i){$balance=(int)$i['amount_kobo']-(int)$i['discount_kobo']+(int)$i['penalty_kobo']-(int)$i['paid_kobo'];echo '<h3>'.e($i['reference']).' · '.e($i['description']).'</h3><p>Balance: '.e(fnFmt($balance)).' · Due: '.e($i['due_date']).' · '.e($i['status']).'</p>';if($balance>0&&$online){$canPay=true;try{sbf_pay_guard($tid,(int)$i['id']);}catch(RuntimeException $ex){$canPay=false;echo '<p>'.e($ex->getMessage()).'</p>';}if($canPay){pp_form('pay',$sid);echo '<input type="hidden" name="invoice_id" value="'.(int)$i['id'].'">';pp_end('Pay securely with Paystack');}}}
  if(!$rows)echo '<p>No Finance invoices for this child.</p>';
  if(pp_has('fn45_gateway'))foreach(q('SELECT gw.* FROM fn45_gateway gw JOIN fn_invoices i ON i.id=gw.invoice_id AND i.tenant_id=gw.tenant_id WHERE gw.tenant_id=? AND i.student_id=? ORDER BY gw.id DESC LIMIT 30',[$tid,$sid])->fetchAll() as $gw){echo '<p>'.e($gw['reference']).' · '.e($gw['status']).'</p>';if($gw['status']!=='confirmed'){
   if(preg_match('~^https://checkout\.paystack\.com/~',(string)$gw['authorization_url']))echo '<a href="'.e($gw['authorization_url']).'" target="_blank" rel="noopener noreferrer">Open secure Paystack checkout ↗</a>';
   pp_form('verify',$sid);echo '<input type="hidden" name="gateway_id" value="'.(int)$gw['id'].'">';pp_end('Verify payment');}}
  $legacy=q('SELECT reference,amount,paid,status,due_date FROM invoices WHERE tenant_id=? AND student_id=? ORDER BY id DESC LIMIT 100',[$tid,$sid])->fetchAll();if($legacy){echo '<h3>Legacy invoices (contact school to pay)</h3>';pp_table($legacy,['Reference','Amount NGN','Paid NGN','Status','Due']);}
 }else{
  $rows=q("SELECT p.id,p.reference,p.amount_kobo,p.confirmed_at FROM fn_payments p JOIN fn_invoices i ON i.id=p.invoice_id AND i.tenant_id=p.tenant_id WHERE p.tenant_id=? AND i.student_id=? AND p.status='confirmed' ORDER BY p.id DESC LIMIT 100",[$tid,$sid])->fetchAll();
  foreach($rows as $r)echo '<p><a href="?fn_receipt='.(int)$r['id'].'">'.e($r['reference']).' · '.e(fnFmt($r['amount_kobo'])).' · Print receipt</a></p>';if(!$rows)echo '<p>No confirmed payments. Receipts appear after payment verification.</p>';
 }
}
function pp_staff(array $u): void {
 $tid=(int)$u['tenant_id'];$uid=(int)$u['id'];$admin=$u['role']==='school_admin';
 echo '<div class="pp-card"><h2>Family Space · school workspace</h2><p>Use Portal Accounts and Account Links to connect parents to their children. Published documents are explicitly shared with families; private SIS documents remain private.</p>';
 if($admin){pp_collectors_desk($u);
  pp_form('publish');echo '<label>Type<select name="kind">';foreach(['calendar','consent','transport','meals','document','survey'] as $k)echo '<option>'.e($k).'</option>';echo '</select></label>';pp_field('title','Title');echo '<label>Event audience<select name="event_audience"><option value="families">All families</option><option value="students">Students (guardians can view details)</option><option value="parents">Parents / guardians</option><option value="all">Whole school community</option><option value="staff">Staff only</option></select></label>';pp_field('event_location','Event location (optional)','text',false);pp_field('body','Details','textarea');
  echo '<label>Class audience<select name="class_id"><option value="0">All classes</option>';foreach(q('SELECT id,name FROM classes WHERE tenant_id=? ORDER BY name',[$tid])->fetchAll() as $c)echo '<option value="'.(int)$c['id'].'">'.e($c['name']).'</option>';echo '</select></label>';
  pp_field('student_id','Student ID (optional, narrows audience)','number',false);pp_field('starts_at','Start / response window opens (Africa/Lagos)','datetime-local',false);pp_field('ends_at','End / response deadline (Africa/Lagos)','datetime-local',false);pp_field('options','Meal or survey choices, one per line','textarea',false);
  echo '<label>Document (PDF/image, up to 2 MB)<input type="file" name="document" accept="application/pdf,image/jpeg,image/png,image/webp"></label>';pp_end('Publish to families');
  foreach(q('SELECT id,title,kind,active FROM pp_posts WHERE tenant_id=? ORDER BY id DESC LIMIT 60',[$tid])->fetchAll() as $p){echo '<h3>'.e($p['title']).' · '.e($p['kind']).'</h3>';pp_table(q('SELECT s.name child,u.name parent,r.answer,r.updated_at FROM pp_responses r JOIN users u ON u.id=r.user_id AND u.tenant_id=r.tenant_id JOIN students s ON s.id=r.student_id AND s.tenant_id=r.tenant_id WHERE r.tenant_id=? AND r.post_id=? ORDER BY r.id DESC LIMIT 200',[$tid,$p['id']])->fetchAll(),['Child','Parent','Response','Updated']);if($p['active']){pp_form('close_post');echo '<input type="hidden" name="post_id" value="'.(int)$p['id'].'">';pp_end('Close item #'.$p['id']);}}
 }
 echo '</div><div class="pp-card"><h3>Publish a parent–teacher appointment</h3>';pp_form('slot');
 if($admin){echo '<label>Teacher<select name="teacher_user_id">';foreach(q("SELECT id,name FROM users WHERE tenant_id=? AND role='teacher' AND active=1 ORDER BY name",[$tid])->fetchAll() as $r)echo '<option value="'.(int)$r['id'].'">'.e($r['name']).'</option>';echo '</select></label>';}
 pp_field('starts_at','Start (Africa/Lagos)','datetime-local');pp_field('ends_at','End','datetime-local');pp_end('Publish appointment');
 pp_table(q("SELECT sl.starts_at,sl.ends_at,tu.name teacher,pa.name parent,s.name child,b.status FROM pp_bookings b JOIN pp_slots sl ON sl.id=b.slot_id AND sl.tenant_id=b.tenant_id JOIN users tu ON tu.id=sl.teacher_user_id AND tu.tenant_id=sl.tenant_id JOIN users pa ON pa.id=b.user_id AND pa.tenant_id=b.tenant_id JOIN students s ON s.id=b.student_id AND s.tenant_id=b.tenant_id WHERE b.tenant_id=?".($admin?'':' AND sl.teacher_user_id=?').' ORDER BY sl.starts_at DESC LIMIT 100',$admin?[$tid]:[$tid,$uid])->fetchAll(),['Start','End','Teacher','Parent','Child','Status']);echo '</div><div class="pp-card"><h3>Requests and messages</h3>';
 $rows=q('SELECT r.*,u.name parent,s.name child FROM pp_requests r JOIN users u ON u.id=r.user_id AND u.tenant_id=r.tenant_id JOIN students s ON s.id=r.student_id AND s.tenant_id=r.tenant_id WHERE r.tenant_id=?'.($admin?'':" AND r.kind='message' AND r.recipient_id=?").' ORDER BY r.id DESC LIMIT 100',$admin?[$tid]:[$tid,$uid])->fetchAll();
 foreach($rows as $r){echo '<article class="pp-card"><h3>'.e($r['kind'].' #'.$r['id'].' · '.$r['subject']).'</h3><p>'.e($r['parent'].' / '.$r['child']).' · '.e($r['starts_on']).' – '.e($r['ends_on']).'</p><p>'.e($r['body']).'</p><p>Status: '.e($r['status']).' · '.e($r['reply']).'</p>';if(!in_array($r['status'],['revoked','collected'],true)){
  pp_form('review');echo '<input type="hidden" name="request_id" value="'.(int)$r['id'].'"><label>Decision<select name="status">';foreach($r['kind']==='message'?['replied','closed']:['approved','rejected'] as $st)echo '<option>'.e($st).'</option>';echo '</select></label>';pp_field('reply','School reply / identity verification note','textarea');pp_end('Save review');}echo '</article>';
 }echo '</div>';
}

// Regular collector approvals remain reusable; daily passenger rows are the handover history.
function pp_collector_linked(array $r):bool {
 return (bool)g("SELECT u.id FROM users u JOIN ecosystem_links l ON l.user_id=u.id AND l.tenant_id=u.tenant_id WHERE u.tenant_id=? AND u.id=? AND u.role='parent' AND u.active=1 AND l.student_id=? AND l.relation_type='parent' LIMIT 1",[$r['tenant_id'],$r['user_id'],$r['student_id']]);
}
function pp_collector_valid(array $r,string $day):bool {
 if($r['status']!=='approved'||!pp_collector_linked($r))return false;
 if($r['kind']==='pickup')return $r['starts_on']===$day;
 return $r['kind']==='pickup_regular'&&$r['starts_on']&&$r['ends_on']&&$r['starts_on']<=$day&&$r['ends_on']>=$day;
}
function pp_today_collector_change(int $tid,int $sid,string $day):bool {
 return (bool)g("SELECT id FROM pp_requests WHERE tenant_id=? AND student_id=? AND kind='pickup' AND starts_on=? AND status IN ('pending','approved','collected') LIMIT 1",[$tid,$sid,$day]);
}
function pp_bus_collector_map(int $tid,array $ids,string $day):array {
 $ids=array_values(array_unique(array_filter(array_map('intval',$ids),fn($id)=>$id>0)));if(!$ids)return [];$in=implode(',',array_fill(0,count($ids),'?'));$changes=[];$out=[];
 foreach(q("SELECT DISTINCT student_id FROM pp_requests WHERE tenant_id=? AND student_id IN ($in) AND kind='pickup' AND starts_on=? AND status IN ('pending','approved','collected')",[$tid,...$ids,$day]) as $r)$changes[$r['student_id']]=true;
 $rows=q("SELECT r.* FROM pp_requests r WHERE r.tenant_id=? AND r.student_id IN ($in) AND r.status='approved' AND ((r.kind='pickup' AND r.starts_on=?) OR (r.kind='pickup_regular' AND r.starts_on<=? AND r.ends_on>=?)) AND EXISTS(SELECT 1 FROM users u JOIN ecosystem_links l ON l.user_id=u.id AND l.tenant_id=u.tenant_id WHERE u.tenant_id=r.tenant_id AND u.id=r.user_id AND u.role='parent' AND u.active=1 AND l.student_id=r.student_id AND l.relation_type='parent') ORDER BY r.id DESC",[$tid,...$ids,$day,$day,$day])->fetchAll();
 foreach($rows as $r)if($r['kind']!=='pickup_regular'||!isset($changes[$r['student_id']]))$out[$r['student_id']][]=$r;
 return $out;
}
function pp_bus_collectors(int $tid,int $sid,string $day):array{return pp_bus_collector_map($tid,[$sid],$day)[$sid]??[];}
function pp_collector_label(array $r):string{return ($r['kind']==='pickup_regular'?'Regular · ':'Today only · ').$r['subject'];}
function pp_collector_check(array $r,string $day):void {
 if(!pp_collector_valid($r,$day)||($r['kind']==='pickup_regular'&&pp_today_collector_change((int)$r['tenant_id'],(int)$r['student_id'],$day)))throw new RuntimeException('Collector approval expired, changed or revoked. Refresh and use the current approved collector.');
}
function pp_collectors_view(array $u,array $s):void {
 $sid=(int)$s['id'];$tid=(int)$u['tenant_id'];
 echo '<section class="px-composer"><h3>People trusted to receive '.e($s['name']).'</h3><p>Register regular collectors once for school approval. The driver checks their identity at every drop-off. A different collector needs a one-day approval.</p><p>Use a one-day request to change today’s arrangement. While that change is awaiting review, regular collector drop-off is paused. Cancelling the change restores eligible regular collectors.</p></section>';
 foreach(['pickup_regular'=>'Register a regular collector','pickup'=>'Someone different for one day'] as $kind=>$title){echo '<details class="px-composer"><summary>'.e($title).'</summary>';pp_form($kind,$sid);pp_field('subject','Collector’s full name');pp_field('collector_phone','Collector’s phone number','tel');pp_field('body','Relationship to child and how staff should verify identity','textarea');pp_field('starts_on',$kind==='pickup_regular'?'Valid from':'Collection date','date');if($kind==='pickup_regular')pp_field('ends_on','Valid until · up to one year','date');pp_end($kind==='pickup_regular'?'Send regular collector for approval':'Request one-day change');echo '</details>';}
 $rows=q("SELECT r.*,u.name guardian FROM pp_requests r JOIN users u ON u.tenant_id=r.tenant_id AND u.id=r.user_id WHERE r.tenant_id=? AND r.student_id=? AND r.kind IN ('pickup','pickup_regular') ORDER BY r.id DESC LIMIT 100",[$tid,$sid])->fetchAll();
 echo '<h3>Collector approvals & requests</h3>';if(!$rows)echo '<p>No collectors registered yet.</p>';
 foreach($rows as $r){$status=$r['status'];if($status==='approved'&&$r['ends_on']<date('Y-m-d'))$status='expired';elseif($status==='approved'&&!pp_collector_linked($r))$status='inactive · guardian account link unavailable';echo '<article class="px-composer"><h4>'.e(pp_collector_label($r)).'</h4><p>'.e($status).' · '.e($r['starts_on']).' to '.e($r['ends_on']).'</p><p>'.nl2br(e($r['body'])).'</p><p>Requested by '.e($r['guardian']).'. School: '.e($r['reply']?:'Awaiting review').'</p>';if((int)$r['user_id']===(int)$u['id']&&in_array($r['status'],['pending','approved'],true)){pp_form('revoke_pickup',$sid);echo '<input type="hidden" name="request_id" value="'.(int)$r['id'].'">';pp_end($r['kind']==='pickup_regular'?'Remove this regular collector':'Cancel this one-day request');}echo '</article>';}
 px_pickup_tokens($u,$s);
 echo '<p>Regular approval does not replace the identity check or any one-time pickup code required by your school.</p>';
}
function pp_collectors_desk(array $u):void {
 $rows=q("SELECT r.*,s.name child,u.name guardian FROM pp_requests r JOIN students s ON s.tenant_id=r.tenant_id AND s.id=r.student_id JOIN users u ON u.tenant_id=r.tenant_id AND u.id=r.user_id WHERE r.tenant_id=? AND r.kind IN ('pickup','pickup_regular') AND r.status IN ('pending','approved') AND r.ends_on>=? ORDER BY r.status='pending' DESC,r.id DESC LIMIT 100",[$u['tenant_id'],date('Y-m-d')])->fetchAll();
 echo '<section class="px-composer"><h2>Collector approval desk</h2><p>Verify each adult’s identity and relationship before approving. Regular collectors can receive the child throughout their approved dates; drivers still confirm identity at every handover.</p>';if(!$rows)echo '<p>No current collector requests to review.</p>';
 foreach($rows as $r){echo '<details class="px-composer"><summary>'.e($r['child'].' · '.pp_collector_label($r).' · '.$r['status']).'</summary><p>Parent: '.e($r['guardian']).' · '.e($r['starts_on']).' to '.e($r['ends_on']).'</p><p>'.nl2br(e($r['body'])).'</p>';pp_form('review');echo '<input type="hidden" name="request_id" value="'.(int)$r['id'].'"><label>Decision<select name="status"><option value="approved">Approve collector</option><option value="rejected">Reject / withdraw approval</option></select></label>';pp_field('reply','Identity verification and decision note','textarea');pp_end('Save collector decision');if($r['kind']==='pickup_regular'){pp_form('revoke_regular');echo '<input type="hidden" name="request_id" value="'.(int)$r['id'].'">';pp_end('Revoke regular approval now');}echo '</details>';}
 echo '</section>';
}

function pp_family_link(int $sid,string $view):string{return '?s=family&amp;child='.$sid.'&amp;view='.rawurlencode($view);}
function pp_child_accounts(array $u,int $sid):array {
 pp_child($u,$sid);return q("SELECT DISTINCT v.id,v.tenant_id,v.name,v.role FROM ecosystem_links l JOIN users v ON v.tenant_id=l.tenant_id AND v.id=l.user_id WHERE l.tenant_id=? AND l.student_id=? AND l.relation_type='student' AND v.active=1 AND v.role='student' AND (SELECT COUNT(DISTINCT x.student_id) FROM ecosystem_links x WHERE x.tenant_id=v.tenant_id AND x.user_id=v.id AND x.relation_type='student')=1 ORDER BY v.name",[$u['tenant_id'],$sid])->fetchAll();
}
function pp_parent_chat_child(array $u,int $sid):void {
 $accounts=pp_child_accounts($u,$sid);if(!$accounts){echo '<small class="pf-note">Student login not linked yet. Ask the school to connect this child’s account.</small>';return;}
 foreach($accounts as $v)if(px_contact_allowed($u,$v))echo '<a class="pf-link" href="?s=chat&amp;with='.(int)$v['id'].'">Chat with '.e($v['name']).' →</a>';
}
function pp_parent_stats(array $u,array $s):array {
 pp_child($u,(int)$s['id']);$tid=(int)$u['tenant_id'];$sid=(int)$s['id'];$attendance=q('SELECT status,COUNT(*) n FROM attendance WHERE tenant_id=? AND student_id=? AND attendance_date BETWEEN ? AND ? GROUP BY status',[$tid,$sid,date('Y-m-d',strtotime('-29 days')),date('Y-m-d')])->fetchAll();$counts=[];foreach($attendance as $r)$counts[$r['status']]=(int)$r['n'];
 $fees=['billed'=>0,'paid'=>0];if(pp_has('fn_invoices'))$fees=q("SELECT COALESCE(SUM(GREATEST(0,amount_kobo-discount_kobo+penalty_kobo)),0) billed,COALESCE(SUM(LEAST(GREATEST(0,paid_kobo),GREATEST(0,amount_kobo-discount_kobo+penalty_kobo))),0) paid FROM fn_invoices WHERE tenant_id=? AND student_id=? AND status NOT IN ('cancelled','void')",[$tid,$sid])->fetch();return ['attendance'=>$counts,'fees'=>$fees];
}
function pp_parent_home(array $u,array $children,array $s):void {
 $sid=(int)$s['id'];$stats=pp_parent_stats($u,$s);$counts=$stats['attendance'];$recorded=array_sum($counts);$present=($counts['present']??0)+($counts['late']??0);$absent=$counts['absent']??0;$other=$recorded-$present-$absent;$billed=(int)$stats['fees']['billed'];$paid=(int)$stats['fees']['paid'];
 echo '<section class="pf-intro"><span class="pf-eyebrow">YOUR FAMILY, CONNECTED</span><h2>A little closer to their school day.</h2><p>Learning, care and conversations for every child linked to your account.</p><span class="pf-chip">'.count($children).' linked '.(count($children)===1?'child':'children').' · WAT</span></section><div class="pf-children">';
 foreach($children as $child){echo '<article class="pf-glass"><span class="pf-eyebrow">'.e($child['class_name']?:'Class not assigned').'</span><h3>'.e($child['name']).'</h3><p>'.e($child['student_no']).'</p><div class="pf-actions"><a href="'.pp_family_link((int)$child['id'],'results').'">Results & report card</a><a href="'.pp_family_link((int)$child['id'],'children').'">View school day</a>';pp_parent_chat_child($u,(int)$child['id']);echo '</div></article>';}
 echo '</div><h3 class="pf-section-title">A closer look · '.e($s['name']).'</h3><div class="pf-grid"><article class="pf-glass"><span class="pf-eyebrow">LAST 30 CALENDAR DAYS</span><h3>Attendance at a glance</h3>';pp_parent_donut($present,$absent,$other,['Present / late','Absent','Other recorded states']);echo '<p class="pf-note">'.$recorded.' recorded school days. Unmarked days are not counted as absence.</p><a class="pf-link" href="'.pp_family_link($sid,'attendance').'">Explore the daily log →</a></article><article class="pf-glass"><span class="pf-eyebrow">SCHOOL FEE ACCOUNT</span><h3>'.e(fnFmt(max(0,$billed-$paid))).'</h3><p>Outstanding on current finance invoices</p>';pp_parent_donut($paid,max(0,$billed-$paid),0,['Allocated','Outstanding',''],true);echo '<p class="pf-note">Allocations include confirmed payments and credits. Older invoices remain visible in Fees.</p><a class="pf-link" href="'.pp_family_link($sid,'fees').'">View fees & payment options →</a></article></div>';
 $features=[['results','Learning in focus','Published results, assessment detail and printable school reports'],['timetable','Their learning week','Subjects, lesson times and assigned teachers'],['homework','Learning at home','Class homework shared by teachers'],['messages','Keep talking','Chat with children, assigned teachers and your school team'],['calendar','Dates to remember','School events and parent–teacher appointments'],['pickup','A safe journey home','Approved collectors, one-day changes and bus updates'],['consent','Your permission matters','Read and respond to school consent requests'],['library','My children’s books','Borrowed books, return dates and borrowing history']];echo '<div class="pf-feature-grid">';foreach($features as [$view,$title,$description])echo '<a class="pf-glass pf-feature" href="'.pp_family_link($sid,$view).'"><h3>'.e($title).'</h3><p>'.e($description).'</p><span>Open →</span></a>';echo '</div>';
 echo '<section class="pf-glass"><h3>Coming up for '.e($s['name']).'</h3>';$shown=0;foreach(q("SELECT * FROM pp_posts WHERE tenant_id=? AND kind='calendar' AND active=1 AND COALESCE(ends_at,starts_at)>=? ORDER BY starts_at LIMIT 100",[$u['tenant_id'],date('Y-m-d H:i:s')]) as $p){if(!pp_visible($p,$s)||!px_post_visible($p,$u))continue;echo '<p><strong>'.e($p['title']).'</strong><br>'.e($p['starts_at']).' WAT</p>';if(++$shown===3)break;}if(!$shown)echo '<p>No upcoming events have been shared for this child.</p>';echo '<a class="pf-link" href="'.pp_family_link($sid,'calendar').'">School calendar →</a> · <a class="pf-link" href="'.pp_family_link($sid,'bookings').'">Meet a teacher →</a></section>';
}
function pp_parent_donut(int $a,int $b,int $c,array $labels,bool $money=false):void {
 $total=$a+$b+$c;$p=$total?round($a/$total*100,2):0;$end=$total?round(($a+$b)/$total*100,2):0;echo '<div class="pf-chart"><div class="pf-donut" style="--pf-a:'.$p.'%;--pf-b:'.$end.'%;'.(!$total?'background:#8796a633;':'').'" role="img" aria-label="'.e($total?$labels[0].' '.round($p).'% of recorded total':'No records available').'"><span><strong>'.($total?round($p).'%':'—').'</strong><small>'.e($total?$labels[0]:'No records').'</small></span></div><ul class="pf-legend">';foreach([[$a,$labels[0]],[$b,$labels[1]],[$c,$labels[2]]] as $i=>[$n,$label])if($label!=='')echo '<li><i class="pf-dot pf-dot-'.$i.'"></i>'.e($label).'<strong>'.e($money?fnFmt($n):(string)$n).'</strong></li>';echo '</ul></div>';
}
function pp_parent_contacts(array $u,array $children,array $s):void {
 echo '<p>Private school conversations stay on the platform. Choose a child or one of your permitted school contacts.</p><div class="pf-children">';foreach($children as $child){echo '<article class="pf-glass"><h3>'.e($child['name']).'</h3><p>'.e($child['class_name']).'</p>';pp_parent_chat_child($u,(int)$child['id']);echo '</article>';}echo '</div><h3>Your school connections</h3><p><a class="btn" href="?s=chat">Open conversations & search contacts</a></p><div class="pf-children">';foreach(px_contacts($u) as $v){if($v['role']==='student')continue;echo '<article class="pf-glass"><h4>'.e($v['name']).'</h4><p>'.e($v['context']?:['teacher'=>'Assigned teacher','school_admin'=>'School office','staff'=>'School communications office'][$v['role']]??'School contact').'</p><a class="pf-link" href="?s=chat&amp;with='.(int)$v['id'].'">Start chat →</a></article>';}echo '</div>';
}
function pp_parent_timetable(array $u,array $s):void {
 pp_child($u,(int)$s['id']);$rows=q('SELECT t.weekday,t.start_time,t.end_time,su.name subject,u.name teacher,t.room FROM ac_timetable t JOIN classes c ON c.id=t.class_id AND c.tenant_id=t.tenant_id AND CONVERT(c.session_name USING utf8mb4) COLLATE utf8mb4_unicode_ci=CONVERT(t.session_name USING utf8mb4) COLLATE utf8mb4_unicode_ci JOIN subjects su ON su.id=t.subject_id AND su.tenant_id=t.tenant_id JOIN users u ON u.id=t.teacher_id AND u.tenant_id=t.tenant_id WHERE t.tenant_id=? AND t.class_id=? ORDER BY t.weekday,t.start_time',[$u['tenant_id'],$s['class_id']])->fetchAll();if(!$rows){echo '<p>The school has not shared a timetable for this class yet.</p>';return;}$days=[1=>'Monday',2=>'Tuesday',3=>'Wednesday',4=>'Thursday',5=>'Friday',6=>'Saturday',7=>'Sunday'];foreach($rows as &$r){$r['weekday']=$days[$r['weekday']]??'Day';$r['start_time']=substr($r['start_time'],0,5);$r['end_time']=substr($r['end_time'],0,5);}unset($r);pp_table($rows,['Day','Starts · WAT','Ends · WAT','Subject','Teacher','Room']);
}
function pp_parent_library(array $u,array $s):void {
 pp_child($u,(int)$s['id']);if(!pp_has('lp_library_loans')){echo '<p>The school has not activated book records yet.</p>';return;}$rows=q('SELECT l.id,b.title,l.status,l.due_on,l.returned_at FROM lp_library_loans l JOIN books b ON b.id=l.book_id AND b.tenant_id=l.tenant_id WHERE l.tenant_id=? AND l.student_id=? ORDER BY l.id DESC LIMIT 100',[$u['tenant_id'],$s['id']])->fetchAll();
 echo '<p>Keep track of '.e($s['name']).'’s school books and help them return each one on time. The librarian manages borrowing, returns and any charges.</p>';if(!$rows)echo '<p>No borrowing records for this child yet.</p>';$current=array_values(array_filter($rows,fn($r)=>in_array($r['status'],['requested','issued','lost'],true)));$past=array_values(array_filter($rows,fn($r)=>!in_array($r['status'],['requested','issued','lost'],true)));
 echo '<h3>Books to keep track of</h3>';if(!$current)echo '<p>No current book loans or requests.</p>';pp_parent_book_cards($current);if($past){echo '<details class="px-composer"><summary>Previous borrowing · '.count($past).' '.(count($past)===1?'record':'records').'</summary>';pp_parent_book_cards($past);echo '</details>';}
 if(pp_has('lib_charges')&&pp_has('fn_invoices')){$charges=q('SELECT b.title,c.kind,c.amount_kobo,i.amount_kobo invoice_amount,i.discount_kobo,i.penalty_kobo,i.paid_kobo,i.status FROM lib_charges c JOIN lp_library_loans l ON l.id=c.loan_id AND l.tenant_id=c.tenant_id JOIN books b ON b.id=l.book_id AND b.tenant_id=l.tenant_id JOIN fn_invoices i ON i.id=c.invoice_id AND i.tenant_id=c.tenant_id AND i.student_id=l.student_id WHERE l.tenant_id=? AND l.student_id=? ORDER BY c.id DESC LIMIT 100',[$u['tenant_id'],$s['id']])->fetchAll();echo '<h3>School-issued book charges</h3>';if(!$charges)echo '<p>No book charges recorded for this child.</p>';foreach($charges as $c){$balance=max(0,(int)$c['invoice_amount']-(int)$c['discount_kobo']+(int)$c['penalty_kobo']-(int)$c['paid_kobo']);echo '<article class="pf-glass"><h4>'.e($c['title']).'</h4><p>'.e($c['kind']==='loss'?'Lost book charge':'Overdue book charge').' · '.e(fnFmt((int)$c['amount_kobo'])).'</p><p>'.e(in_array($c['status'],['void','cancelled'],true)?'Cancelled by school':($balance?'Outstanding: '.fnFmt($balance):'Settled')).'</p></article>';}}
 if(pp_has('lib_reservations')){$reservations=q('SELECT b.title,r.status,r.created_at FROM lib_reservations r JOIN books b ON b.id=r.book_id AND b.tenant_id=r.tenant_id WHERE r.tenant_id=? AND r.student_id=? ORDER BY r.id DESC LIMIT 50',[$u['tenant_id'],$s['id']])->fetchAll();if($reservations){echo '<details class="px-composer"><summary>Book reservations already on record</summary>';foreach($reservations as $r)echo '<p><strong>'.e($r['title']).'</strong><br>'.e(['waiting'=>'Waiting for an available copy','cancelled'=>'Cancelled','fulfilled'=>'Completed'][$r['status']]??'School reviewing').' · '.e($r['created_at']).' WAT</p>';echo '</details>';}}
 echo '<p><a class="pf-link" href="'.pp_family_link((int)$s['id'],'fees').'">View school invoices & payments →</a></p><p><a class="pf-link" href="'.pp_family_link((int)$s['id'],'support').'">Ask the school about a book record →</a></p><p class="pf-note">Most recent 100 loans. Reminders use recorded due dates; no fine is added automatically by this page. Learning resources shared with families remain under School documents and Homework & learning.</p>';
}
function pp_parent_book_cards(array $rows):void {
 echo '<div class="pf-children">';foreach($rows as $r){$overdue=$r['status']==='issued'&&$r['due_on']&&$r['due_on']<date('Y-m-d');$label=$overdue?'Return overdue':(['requested'=>'Awaiting librarian','issued'=>'Borrowed','returned'=>'Returned','lost'=>'Reported lost','rejected'=>'Request declined'][$r['status']]??'School record');echo '<article class="pf-glass"><span class="pf-chip">'.e($label).'</span><h4>'.e($r['title']).'</h4>';if($r['due_on'])echo '<p>Return by: '.e($r['due_on']).'</p>';if($r['returned_at'])echo '<p>Returned: '.e($r['returned_at']).' WAT</p>';echo '</article>';}echo '</div>';
}
function pp_parent_attendance(array $u,array $s):void {
 pp_child($u,(int)$s['id']);$from=is_string($_GET['from']??null)?$_GET['from']:date('Y-m-d',strtotime('-29 days'));$to=is_string($_GET['to']??null)?$_GET['to']:date('Y-m-d');try{$from=pp_date($from);$to=pp_date($to);if($to<$from||strtotime($to)-strtotime($from)>366*86400)throw new RuntimeException('Choose up to one year, with the end date after the start.');}catch(RuntimeException $e){echo '<p>'.e($e->getMessage()).'</p>';return;}
 echo '<form method="get" class="pf-filters"><input type="hidden" name="s" value="family"><input type="hidden" name="view" value="attendance"><input type="hidden" name="child" value="'.(int)$s['id'].'"><label>From<input type="date" name="from" value="'.e($from).'" required></label><label>To<input type="date" name="to" value="'.e($to).'" required></label><button class="btn">Show attendance</button></form>';$rows=q('SELECT attendance_date,status,reason FROM attendance WHERE tenant_id=? AND student_id=? AND attendance_date BETWEEN ? AND ? ORDER BY attendance_date DESC',[$u['tenant_id'],$s['id'],$from,$to])->fetchAll();$counts=['present'=>0,'absent'=>0,'other'=>0];foreach($rows as $r){$key=in_array($r['status'],['present','late'],true)?'present':($r['status']==='absent'?'absent':'other');$counts[$key]++;}pp_parent_donut($counts['present'],$counts['absent'],$counts['other'],['Present / late','Absent','Other']);pp_table($rows,['Date','Status','School note']);echo '<p class="pf-note">Only school-recorded days are shown. An empty day does not mean your child was absent.</p>';
}
function pp_parent_results(array $u,array $s):void {
 pp_child($u,(int)$s['id']);$tid=(int)$u['tenant_id'];$sid=(int)$s['id'];$terms=pp_has('ac_term_approvals')?q("SELECT session_name,term_name FROM ac_term_approvals WHERE tenant_id=? AND class_id=? AND status='published' ORDER BY session_name DESC,published_at DESC,id DESC",[$tid,$s['class_id']])->fetchAll():[];
 if(!$terms){echo '<p>The school has not published a term report for this class yet.</p>';pp_parent_legacy_results($u,$s);return;}
 $selected=is_scalar($_GET['report_term']??null)?(string)$_GET['report_term']:'';$current=$terms[0];foreach($terms as $term)if($selected===$term['session_name'].'|'.$term['term_name'])$current=$term;
 echo '<form method="get" class="pf-filters"><input type="hidden" name="s" value="family"><input type="hidden" name="view" value="results"><input type="hidden" name="child" value="'.$sid.'"><label>Published term<select name="report_term">';foreach($terms as $term){$v=$term['session_name'].'|'.$term['term_name'];echo '<option value="'.e($v).'"'.($term===$current?' selected':'').'>'.e($term['session_name'].' · '.$term['term_name']).'</option>';}echo '</select></label><button class="btn">View term report</button></form>';
 $session=$current['session_name'];$term=$current['term_name'];$policy=pp_has('at_class_policies')?q("SELECT d.* FROM at_class_policies p JOIN at_designs d ON d.id=p.design_id AND d.tenant_id=p.tenant_id WHERE p.tenant_id=? AND p.class_id=? AND d.status='approved'",[$tid,$s['class_id']])->fetch():false;$report=null;
 if($policy){try{$report=at_report_data($u,$sid,(int)$policy['id'],$session,$term);$url='?ix_report_card=1&amp;student_id='.$sid.'&amp;design_id='.(int)$policy['id'].'&amp;session_name='.rawurlencode($session).'&amp;term_name='.rawurlencode($term);echo '<a class="pf-report-link" href="'.$url.'" target="_blank" rel="noopener">Open school report card · Print / PDF ↗</a><p class="pf-note">'.e($policy['name']).' · Your school’s approved layout, colours and branding.</p>';}catch(RuntimeException $ex){echo '<p class="pf-note">Printable report: '.e($ex->getMessage()).'</p>';}}
 else echo '<p class="pf-note">The school has not assigned an approved report format to this class yet. Published marks remain available below. Ask the school to configure its class report format under Academic tools.</p>';
 $rows=q("SELECT su.name subject,SUM(CASE WHEN a.category='ca' THEN sc.score/a.max_score*a.weight ELSE 0 END) ca,SUM(CASE WHEN a.category='exam' THEN sc.score/a.max_score*a.weight ELSE 0 END) exam,SUM(sc.score/a.max_score*a.weight) total,SUM(a.weight) possible FROM ac_scores sc JOIN ac_assessments a ON a.id=sc.assessment_id AND a.tenant_id=sc.tenant_id JOIN subjects su ON su.id=a.subject_id AND su.tenant_id=a.tenant_id WHERE sc.tenant_id=? AND sc.student_id=? AND sc.status='approved' AND a.class_id=? AND a.session_name=? AND a.term_name=? AND a.max_score>0 GROUP BY a.subject_id,su.name ORDER BY su.name",[$tid,$sid,$s['class_id'],$session,$term])->fetchAll();
 if($rows){echo '<h3>Subject performance · '.e($session.' / '.$term).'</h3><p class="pf-note">CA and exam values are weighted contributions. Missing components are not treated as zero or assigned a grade.</p><div class="pf-bars">';$out=[];$grades=[];foreach($report['subjects']??[] as $r)$grades[$r['subject']]=$r['grade'];foreach($rows as $r){$pct=$r['possible']>0?min(100,max(0,100*$r['total']/$r['possible'])):0;echo '<div class="pf-bar"><div><span>'.e($r['subject']).'</span><strong>'.number_format($r['total'],2).' / '.number_format($r['possible'],2).'</strong></div><i style="--score:'.$pct.'%"><b></b></i></div>';$out[]=[$r['subject'],number_format($r['ca'],2),number_format($r['exam'],2),number_format($r['total'],2).' / '.number_format($r['possible'],2),$grades[$r['subject']]??'Awaiting complete school report'];}echo '</div>';pp_table($out,['Subject','CA contribution','Exam contribution','Recorded total','School grade']);}
 if($report&&!empty($report['notes'])){echo '<section class="pf-glass"><h3>Your school’s feedback</h3>';foreach(['teacher_comment'=>'Class teacher','head_comment'=>'Head of school'] as $key=>$label)if(!empty($report['notes'][$key]))echo '<p><strong>'.e($label).'</strong><br>'.nl2br(e($report['notes'][$key])).'</p>';if(!empty($report['notes']['resumes_on']))echo '<p>Next term resumes: '.e($report['notes']['resumes_on']).'</p>';echo '</section>';}
 if($report&&$report['skills']){echo '<h3>Skills & teacher observations</h3>';pp_table($report['skills'],['Skill','Rating /5','Approved school comment']);}
 echo '<details class="px-composer"><summary>View individual assessment marks</summary>';pp_table(q("SELECT su.name,a.title,a.category,sc.score,a.max_score,a.weight FROM ac_scores sc JOIN ac_assessments a ON a.id=sc.assessment_id AND a.tenant_id=sc.tenant_id JOIN subjects su ON su.id=a.subject_id AND su.tenant_id=a.tenant_id WHERE sc.tenant_id=? AND sc.student_id=? AND sc.status='approved' AND a.class_id=? AND a.session_name=? AND a.term_name=? ORDER BY su.name,a.id",[$tid,$sid,$s['class_id'],$session,$term])->fetchAll(),['Subject','Assessment','Type','Mark','Maximum','Weight']);echo '</details>';pp_parent_legacy_results($u,$s);
}
function pp_parent_legacy_results(array $u,array $s):void {
 $rows=q("SELECT su.name,r.score,r.max_score,r.grade,r.remark FROM results r JOIN subjects su ON su.id=r.subject_id AND su.tenant_id=r.tenant_id WHERE r.tenant_id=? AND r.student_id=? AND r.status='published' ORDER BY r.id DESC LIMIT 100",[$u['tenant_id'],$s['id']])->fetchAll();if($rows){echo '<details class="px-composer"><summary>Older published results</summary><p class="pf-note">Legacy records are kept separate from the selected term report.</p>';pp_table($rows,['Subject','Score','Maximum','Grade','School remark']);echo '</details>';}
}
function pp_parent_homework(array $u,array $s):void {
 pp_child($u,(int)$s['id']);if(!pp_has('lm_courses')||!pp_has('lm_submissions'))return;$rows=q("SELECT l.title,l.content,l.due_at,l.points,c.title course,su.name subject,ss.submitted_at,ss.graded_at,ss.score,ss.feedback FROM lm_lessons l JOIN lm_courses c ON c.id=l.course_id AND c.tenant_id=l.tenant_id JOIN subjects su ON su.id=c.subject_id AND su.tenant_id=c.tenant_id LEFT JOIN lm_submissions ss ON ss.tenant_id=l.tenant_id AND ss.lesson_id=l.id AND ss.student_id=? WHERE l.tenant_id=? AND c.class_id=? AND c.status='published' AND l.lesson_type IN ('homework','quiz') AND (l.available_at IS NULL OR l.available_at<=?) ORDER BY l.due_at IS NULL,l.due_at DESC,l.id DESC LIMIT 100",[$s['id'],$u['tenant_id'],$s['class_id'],date('Y-m-d H:i:s')])->fetchAll();echo '<h3>Assignments & teacher feedback</h3><p class="pf-note">Follow your child’s work here. Your child submits work from their own learning account.</p>';if(!$rows)echo '<p>No published online assignments available for this child yet.</p>';foreach($rows as $r){echo '<article class="pf-glass"><span class="pf-eyebrow">'.e($r['subject'].' · '.$r['course']).'</span><h4>'.e($r['title']).'</h4><p>'.nl2br(e($r['content'])).'</p><p>Due: '.e($r['due_at']?:'No deadline set').' WAT</p><p><strong>'.($r['submitted_at']?'Submitted '.e($r['submitted_at']):($r['due_at']&&$r['due_at']<date('Y-m-d H:i:s')?'Past due · no submission recorded':'Not submitted yet')).'</strong></p>';if($r['graded_at'])echo '<p>Teacher mark: '.e($r['score']).' / '.e($r['points']).'<br>'.nl2br(e($r['feedback'])).'</p>';echo '</article>';}
}

function pp_parent_service_target(array $query):?array {
 $area=is_scalar($query['area']??null)?(string)$query['area']:'library';$view=is_scalar($query['view']??null)?(string)$query['view']:'';
 if(!in_array($area,['library','inventory','engagement'],true))return null;
 if($area==='engagement'&&!in_array($view,['consent','messages'],true))return ['s'=>'announcements'];
 $dest=['s'=>'family','view'=>$area==='library'?'library':($area==='inventory'?'shop':($view==='messages'?'messages':'preferences'))];if(is_scalar($query['child']??null)&&ctype_digit((string)$query['child']))$dest['child']=(int)$query['child'];return $dest;
}
function pp_parent_action_return(array $u,array $post):array {
 $a=is_scalar($post['sv_action']??null)?(string)$post['sv_action']:'';if(in_array($a,['eg_vote','eg_acknowledge'],true)){$children=pp_children($u);$sid=(int)($post['child']??0);if(in_array($sid,array_map('intval',array_column($children,'id')),true))return ['s'=>'family','view'=>'surveys','child'=>$sid];return ['s'=>'announcements'];}$view=str_starts_with($a,'iv_store_')?'shop':(in_array($a,['eg_contact','eg_consent'],true)?'preferences':($a==='eg_message'?'messages':'library'));$children=pp_children($u);$ids=array_map('intval',array_column($children,'id'));$sid=(int)($post['child']??$post['student_id']??0);if(!in_array($sid,$ids,true))$sid=$ids[0]??0;return ['s'=>'family','view'=>$view,'child'=>$sid];
}
function pp_parent_service_action(array $u,string $a):string {
 if(!in_array($a,['iv_store_request','iv_store_cancel','eg_contact','eg_consent','eg_vote','eg_acknowledge','eg_message'],true))throw new RuntimeException('This action is for school staff. Use My children’s books, School shop or Contact & message preferences in Family Space.');
 if(!sv_ready())throw new RuntimeException('The school has not activated this family service yet.');
 if($a==='iv_store_cancel'){$o=q('SELECT * FROM iv_store_orders WHERE tenant_id=? AND id=? AND requested_by=?',[$u['tenant_id'],op_id('order_id'),$u['id']])->fetch();if(!$o)throw new RuntimeException('Order unavailable.');pp_child($u,(int)$o['student_id']);}
 if(str_starts_with($a,'iv_'))return iv_action($u,substr($a,3));return eg_action($u,substr($a,3));
}
function pp_parent_service_form(string $a,int $sid):void {echo '<form method="post" class="pf-filters"><input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'"><input type="hidden" name="sv_action" value="'.e($a).'"><input type="hidden" name="child" value="'.$sid.'">';}
function pp_parent_shop(array $u,array $s):void {
 pp_child($u,(int)$s['id']);$tid=(int)$u['tenant_id'];$sid=(int)$s['id'];if(!pp_has('iv_items')||!pp_has('iv_store_orders')){echo '<p>The school has not opened its shop yet.</p>';return;}
 echo '<p>Request school-listed items for '.e($s['name']).'. Staff confirm availability and create an invoice before payment. This page does not manage school stock or procurement.</p>';
 $search=is_string($_GET['shop_search']??null)?mb_substr(trim($_GET['shop_search']),0,100):'';echo '<form method="get" class="pf-filters"><input type="hidden" name="s" value="family"><input type="hidden" name="view" value="shop"><input type="hidden" name="child" value="'.$sid.'"><label>Find a school-shop item<input name="shop_search" value="'.e($search).'" placeholder="For example: uniform size 10"></label><button class="btn">Find items</button></form>';$like='%'.str_replace(['=','%','_'],['==','=%','=_'],$search).'%';$groups=iv_shop_catalogue($u,$search);echo '<p class="pf-note">Up to 20 matching products are shown. Choose the size, colour or pack you need.</p>';if(!$groups)echo '<p>No school-shop items are available to request right now.</p>';else iv_shop_cards($u,$groups,[],$sid);

 echo '<h3>Orders for this child</h3>';$orders=q('SELECT o.*,i.name item FROM iv_store_orders o JOIN inventory i ON i.id=o.item_id AND i.tenant_id=o.tenant_id WHERE o.tenant_id=? AND o.student_id=? ORDER BY o.id DESC LIMIT 100',[$tid,$sid])->fetchAll();if(!$orders)echo '<p>No school-shop orders recorded for this child yet.</p>';foreach($orders as $o){$label=['requested'=>'Awaiting school approval','awaiting_payment'=>'Invoice ready for payment','fulfilled'=>'Collected','returned'=>'Returned · Finance review','returned_damaged'=>'Returned damaged · Finance review','cancelled'=>'Cancelled'][$o['status']]??'School reviewing';echo '<article class="pf-glass"><h4>'.e($o['item']).'</h4><p>'.(int)$o['quantity'].' × '.e(fnFmt((int)$o['unit_kobo'])).' · '.e($label).'</p>';if($o['status']==='requested'&&(int)$o['requested_by']===(int)$u['id']){pp_parent_service_form('iv_store_cancel',$sid);echo '<input type="hidden" name="order_id" value="'.(int)$o['id'].'">';op_end('Cancel this request');}elseif($o['invoice_id'])echo '<a class="pf-link" href="'.pp_family_link($sid,'fees').'">View invoice & payments →</a>';echo '</article>';}
 echo '<p class="pf-note">Only school-listed items and this child’s orders are shown. You can cancel requests made from your own account before school approval. Changes to approved orders or refunds need school review.</p>';
}
function pp_parent_preferences(array $u,array $s):void {
 pp_child($u,(int)$s['id']);if(!pp_has('eg_consents')||!pp_has('eg_contacts')){echo '<p>Contact and message preferences have not been activated by the school.</p>';return;}$sid=(int)$s['id'];$tid=(int)$u['tenant_id'];$uid=(int)$u['id'];
 echo '<h3>Your contact details</h3><p>Update your contact address for school review. A change resets school verification.</p>';pp_table(q('SELECT channel,address,verified FROM eg_contacts WHERE tenant_id=? AND user_id=? ORDER BY channel',[$tid,$uid])->fetchAll(),['Channel','Your address','Verified by school']);pp_parent_service_form('eg_contact',$sid);op_select('channel','Contact channel',['email'=>'Email','sms'=>'SMS','whatsapp'=>'WhatsApp']);op_field('address','Your email or phone number in international format');op_end('Submit contact update');
 $targets=[$uid=>'My parent account'];foreach(pp_child_accounts($u,$sid) as $v)$targets[(int)$v['id']]=$s['name'].' · student account';echo '<h3>External message choices</h3><p>Choose whether the school may contact your account or this child’s linked student account through each channel. In-platform school notices remain available.</p>';pp_parent_service_form('eg_consent',$sid);op_select('user_id','Account',$targets);op_select('channel','Channel',['email'=>'Email','sms'=>'SMS','whatsapp'=>'WhatsApp','push'=>'Push notifications']);op_select('purpose','Message type',['operational'=>'School service updates','marketing'=>'Newsletters & marketing']);op_select('status','Your choice',['revoked'=>'Do not send / withdraw consent','granted'=>'I consent to these messages']);op_end('Save message choice');
 $ids=array_keys($targets);$in=implode(',',array_fill(0,count($ids),'?'));$rows=q("SELECT user_id,channel,purpose,status,updated_at FROM eg_consents WHERE tenant_id=? AND user_id IN ($in) ORDER BY updated_at DESC",[$tid,...$ids])->fetchAll();foreach($rows as &$r){$r['user_id']=$targets[(int)$r['user_id']];$r['purpose']=$r['purpose']==='operational'?'School service updates':'Newsletters & marketing';$r['status']=$r['status']==='granted'?'Allowed':'Not allowed';}unset($r);pp_table($rows,['Account','Channel','Message type','Choice','Updated']);
}
