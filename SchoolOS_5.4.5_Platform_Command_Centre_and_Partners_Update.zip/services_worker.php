<?php
/** cPanel cron: php /absolute/public_html/services_worker.php --tenant=1 --limit=30 */
if(PHP_SAPI!=='cli'){http_response_code(403);exit('CLI only.');}
$options=getopt('',['tenant:','limit:','hr-attendance','all-schools','family-onboarding']);$familyOnboarding=array_key_exists('family-onboarding',$options);$hrAttendance=array_key_exists('hr-attendance',$options);$hrAllSchools=array_key_exists('all-schools',$options);$tenant=(string)($options['tenant']??'');$limit=(string)($options['limit']??'30');if(($familyOnboarding&&$hrAttendance)||($hrAllSchools&&!$hrAttendance)||(!$hrAllSchools&&!preg_match('/^[1-9]\d{0,9}$/D',$tenant))||!preg_match('/^\d{1,3}$/D',$limit)||(int)$limit<1||(int)$limit>100){fwrite(STDERR,"Use --tenant=ID --limit=1..100, or --hr-attendance --all-schools\n");exit(2);}
define('SCHOOLOS_SERVICES_WORKER',true);$_SERVER['REQUEST_METHOD']='GET';$_GET=[];$_POST=[];require __DIR__.'/index.php';
