<?php
if(!defined('SCHOOLOS_EXPERIENCE')){http_response_code(404);exit;}
function px_live_scope(array $u,int $id,bool $join=false):array{$r=q('SELECT l.*,s.name subject,c.name class_name FROM px_live l JOIN classes c ON c.id=l.class_id AND c.tenant_id=l.tenant_id AND c.session_name=l.session_name JOIN subjects s ON s.id=l.subject_id AND s.tenant_id=l.tenant_id WHERE l.tenant_id=? AND l.id=?',[$u['tenant_id'],$id])->fetch();if(!$r)throw new RuntimeException('Live lesson unavailable.');if($u['role']==='student'){$s=lp_student($u);if((int)$s['class_id']!==(int)$r['class_id']||$s['session_name']!==$r['session_name'])throw new RuntimeException('This lesson is outside your class and current session.');}elseif($u['role']==='teacher'){if((int)$r['teacher_id']!==(int)$u['id'])throw new RuntimeException('Only your own live lessons are available.');lp_scope($u,(int)$r['class_id'],(int)$r['subject_id'],$r['session_name']);}elseif($u['role']!=='school_admin')throw new RuntimeException('Teacher or learner access required.');if($join&&(in_array($r['status'],['ended','cancelled'],true)||strtotime($r['ends_at'])<=time()||strtotime($r['starts_at'])>time()+900))throw new RuntimeException('This lesson is outside its joining window.');return $r;}
function px_live_create(array $u):string{if(!in_array($u['role'],['teacher','school_admin'],true))throw new RuntimeException('Teacher required.');$class=(int)xp_text('class_id',20);$subject=(int)xp_text('subject_id',20);$a=lp_scope($u,$class,$subject);$start=lp_datetime(xp_text('starts_at',16));$end=lp_datetime(xp_text('ends_at',16));if(!$start||!$end||$end<=$start||strtotime($end)<=time()||strtotime($end)-strtotime($start)>14400)throw new RuntimeException('Choose a valid lesson window of up to four hours.');$provider=xp_text('provider',20);if(!in_array($provider,['schoolos','zoom','meet'],true))throw new RuntimeException('Choose a supported classroom provider.');$url=xp_text('join_url',1000,false);if($provider!=='schoolos'){$parts=parse_url($url);$host=strtolower($parts['host']??'');if(($parts['scheme']??'')!=='https'||isset($parts['user'])||isset($parts['pass'])||isset($parts['port'])||($provider==='meet'?$host!=='meet.google.com':!preg_match('/(^|\.)zoom\.us$/D',$host)))throw new RuntimeException('Use an HTTPS invitation URL from the selected Zoom or Google Meet provider.');}else $url=null;q('INSERT INTO px_live(tenant_id,teacher_id,class_id,subject_id,session_name,title,provider,join_url,starts_at,ends_at) VALUES(?,?,?,?,?,?,?,?,?,?)',[$u['tenant_id'],$u['id'],$class,$subject,$a['session_name'],xp_text('title',180),$provider,$url,$start,$end]);audit('learning.live.created');return 'Live lesson scheduled for the allocated class.';}
function px_live_join_impl(array $u,int $id):array{xp_rate('live-join-'.$u['id'],10,5);return xp_tx(function()use($u,$id){q('SELECT id FROM px_live WHERE tenant_id=? AND id=? FOR UPDATE',[$u['tenant_id'],$id]);$r=px_live_scope($u,$id,true);if($r['provider']!=='schoolos')throw new RuntimeException('Open the lesson provider invitation instead.');q('DELETE FROM px_signals WHERE tenant_id=? AND created_at<DATE_SUB(NOW(),INTERVAL 15 MINUTE) LIMIT 500',[$u['tenant_id']]);$host=(int)$r['teacher_id']===(int)$u['id'];if(!$host&&$u['role']!=='student')throw new RuntimeException('Only the scheduled host or allocated learners may join.');if(!$host&&($r['status']!=='live'||!g('SELECT user_id FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND)',[$u['tenant_id'],$id,$r['teacher_id']])))throw new RuntimeException('Your teacher has not started the live lesson yet.');$count=(int)g('SELECT COUNT(*) FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id<>? AND last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND)',[$u['tenant_id'],$id,$u['id']]);$transport=$r['join_url']??'';if($host&&$r['status']==='scheduled'&&$count===0)$transport='';if(!in_array($transport,['schoolos:sfu','schoolos:p2p'],true)){$transport=px_sfu_config((int)$u['tenant_id'])?'schoolos:sfu':'schoolos:p2p';if($host){q('UPDATE px_live SET join_url=? WHERE tenant_id=? AND id=?',[$transport,$u['tenant_id'],$id]);$r['join_url']=$transport;}}if($transport==='schoolos:p2p'&&$count>=8)throw new RuntimeException('This fallback broadcast supports eight participants. Ask the Platform Super Admin to connect the full-class media server for all schools.');if($host)q('UPDATE px_live SET status=? WHERE tenant_id=? AND id=?',[$transport==='schoolos:sfu'?'starting':'live',$u['tenant_id'],$id]);$key=bin2hex(random_bytes(16));q('INSERT INTO px_peers(tenant_id,lesson_id,user_id,peer_key,last_seen) VALUES(?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE peer_key=VALUES(peer_key),last_seen=NOW()',[$u['tenant_id'],$id,$u['id'],$key]);$ice=[];$relay=px_turn_config((int)$u['tenant_id']);$url=$relay['url']??'';$secret=$relay['secret']??'';if($url&&$secret){$username=(time()+3600).':schoolos-'.$u['tenant_id'].'-'.$u['id'];$ice[]=['urls'=>$url,'username'=>$username,'credential'=>base64_encode(hash_hmac('sha1',$username,$secret,true))];}return ['key'=>$key,'host'=>$host,'hostId'=>(int)$r['teacher_id'],'iceServers'=>$ice,'relayConfigured'=>(bool)$ice,'lesson'=>$id]+($transport==='schoolos:sfu'?px_sfu_join($u,$r,$host):['transport'=>'p2p']);});}
function px_peer(array $u,int $id,string $key):array{$r=px_live_scope($u,$id,true);if($r['status']!=='live')throw new RuntimeException('The broadcast has stopped. Join again when your teacher restarts it.');$p=q('SELECT * FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=? AND last_seen>DATE_SUB(NOW(),INTERVAL 45 SECOND)',[$u['tenant_id'],$id,$u['id'],$key])->fetch();if(!$p)throw new RuntimeException('Classroom session expired. Please join again.');q('UPDATE px_peers SET last_seen=NOW() WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=?',[$u['tenant_id'],$id,$u['id'],$key]);return $r;}
function px_live_poll(array $u,int $id,string $key,int $after):array{$r=px_peer($u,$id,$key);if(($r['join_url']??'')==='schoolos:sfu'){if((int)$u['id']!==(int)$r['teacher_id']&&!g('SELECT user_id FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND)',[$u['tenant_id'],$id,$r['teacher_id']]))throw new RuntimeException('Your teacher has disconnected. Rejoin when the broadcast resumes.');return ['peers'=>[],'signals'=>[],'status'=>$r['status'],'hostId'=>(int)$r['teacher_id']];}$peers=q('SELECT p.user_id,p.peer_key,u.name FROM px_peers p JOIN users u ON u.id=p.user_id AND u.tenant_id=p.tenant_id AND u.active=1 WHERE p.tenant_id=? AND p.lesson_id=? AND p.last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND) AND p.user_id<>?',[$u['tenant_id'],$id,$u['id']])->fetchAll();$signals=q('SELECT id,from_user,from_key,kind,payload FROM px_signals WHERE tenant_id=? AND lesson_id=? AND to_user=? AND to_key=? AND id>? AND created_at>DATE_SUB(NOW(),INTERVAL 2 MINUTE) ORDER BY id LIMIT 100',[$u['tenant_id'],$id,$u['id'],$key,max(0,$after)])->fetchAll();return ['peers'=>$peers,'signals'=>$signals,'status'=>$r['status'],'hostId'=>(int)$r['teacher_id']];}
function px_live_signal(array $u,int $id):void{$r=px_peer($u,$id,xp_text('key',32));if(($r['join_url']??'')==='schoolos:sfu')throw new RuntimeException('This classroom uses the media server for signalling.');$to=(int)xp_text('to',20);$target=q('SELECT * FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=? AND last_seen>DATE_SUB(NOW(),INTERVAL 35 SECOND)',[$u['tenant_id'],$id,$to,xp_text('to_key',32)])->fetch();if(!$target||$to===(int)$u['id']||((int)$u['id']!==(int)$r['teacher_id']&&$to!==(int)$r['teacher_id']))throw new RuntimeException('Signal recipient is outside this classroom relationship.');$kind=xp_text('kind',12);if(!in_array($kind,['offer','answer','ice'],true)||($kind==='offer'&&(int)$u['id']!==(int)$r['teacher_id'])||($kind==='answer'&&(int)$u['id']===(int)$r['teacher_id']))throw new RuntimeException('Unsupported classroom signal.');$payload=xp_text('payload',120000);$decoded=json_decode($payload,true);if(!is_array($decoded)||($kind!=='ice'&&(($decoded['type']??'')!==$kind||!is_string($decoded['sdp']??null)))||($kind==='ice'&&!is_string($decoded['candidate']??null)))throw new RuntimeException('Invalid classroom signal.');xp_rate('classroom-signal-'.$u['id'],180,1);q('INSERT INTO px_signals(tenant_id,lesson_id,from_user,to_user,from_key,to_key,kind,payload) VALUES(?,?,?,?,?,?,?,?)',[$u['tenant_id'],$id,$u['id'],$to,xp_text('key',32),$target['peer_key'],$kind,$payload]);}
function px_live_view(array $u):void{echo '<section class="px-live"><span class="px-kicker">MEET. LEARN. CONNECT.</span><h2>Your live classroom.</h2><p>Join your allocated class online. SchoolOS Live supports the full enrolled class when the Platform Super Admin connects the shared media server. Zoom and Google Meet invitations are also supported.</p>';if(!px_ready()){echo '<p>Ask your school administrator to activate Portal Experience.</p></section>';return;}$host=in_array($u['role'],['teacher','school_admin'],true);if($host){echo '<details class="px-composer"><summary>Schedule a live lesson</summary><form method="post" class="lp-form"><input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'"><input type="hidden" name="px_action" value="live_create">';lp_class_fields($u);lp_input('title','Lesson title');lp_select('provider','Classroom',['schoolos'=>'SchoolOS Live · full class with media server','meet'=>'Google Meet invitation link','zoom'=>'Zoom invitation link']);lp_input('join_url','Zoom / Meet HTTPS invitation (leave empty for SchoolOS)','url','',false);lp_input('starts_at','Starts at · WAT','datetime-local');lp_input('ends_at','Ends at · WAT','datetime-local');lp_end('Schedule lesson');echo '<p><a href="https://meet.google.com/new" target="_blank" rel="noopener noreferrer">Create a Google Meet invitation ↗</a> · <a href="https://zoom.us/meeting/schedule" target="_blank" rel="noopener noreferrer">Schedule in your Zoom account ↗</a></p><p>No provider account is created or charged by SchoolOS. Paste the invitation from your own provider account.</p></details>';}
$rows=q('SELECT id FROM px_live WHERE tenant_id=? AND ends_at>=DATE_SUB(NOW(),INTERVAL 1 DAY) ORDER BY starts_at LIMIT 100',[$u['tenant_id']])->fetchAll();echo '<div class="px-live-grid">';foreach($rows as $row){try{$r=px_live_scope($u,(int)$row['id']);}catch(Throwable){continue;}echo '<article id="live-lesson-'.(int)$r['id'].'" class="px-live-card"><span class="px-badge">'.e(px_live_label($u,$r)).' · '.e($r['status']).'</span><h3>'.e($r['title']).'</h3><p>'.e($r['class_name'].' · '.$r['subject']).'</p><time>'.e(date('D, j M · H:i',strtotime($r['starts_at']))).' – '.e(date('H:i',strtotime($r['ends_at']))).' WAT</time>';if($r['provider']==='schoolos'){try{px_live_scope($u,(int)$r['id'],true);echo '<button type="button" class="btn" data-live-join="'.(int)$r['id'].'">'.($host?'Start / resume broadcast':'Join live lesson').'</button>';}catch(Throwable){echo '<p>This lesson is outside its joining window or has ended.</p>';}}else{try{px_live_scope($u,(int)$r['id'],true);echo '<a class="btn" href="'.e($r['join_url']).'" target="_blank" rel="noopener noreferrer">Join provider classroom ↗</a>';}catch(Throwable){echo '<p>Joining opens 15 minutes before the lesson.</p>';}}if($host&&$r['teacher_id']==$u['id']&&!in_array($r['status'],['ended','cancelled'],true))px_form('live_end','End this lesson',['lesson_id'=>$r['id']]);echo '</article>';}echo '</div><section class="px-video-stage" id="pxLiveStage" hidden><h3 id="pxLiveTitle">SchoolOS classroom</h3><div id="pxLiveStatus" role="status"></div><video id="pxLiveVideo" controls autoplay playsinline></video><div><button type="button" class="btn" id="pxShareScreen">Share screen</button><button type="button" class="btn" id="pxLiveLeave">Leave classroom</button></div><p>Learners receive the teacher’s stream; learner cameras and microphones are not requested. No recording is performed. Use school chat for questions.</p><a href="?s=chat">Open school conversations →</a></section><p class="px-connection-note">SchoolOS Live uses a media server for full-class broadcasts with no eight-person application cap; actual capacity depends on your media server plan and bandwidth. Until configured, the existing eight-person direct broadcast remains available. Camera/screen sharing needs HTTPS and browser permission. Without a relay, direct connectivity is limited to compatible networks; a school-controlled TURN service is required for reliable connections across different networks. The shared demo has its own optional relay configuration and never receives your live school’s relay secrets.</p>';
if($u['role']==='school_admin'&&px_platform_media_state()['policy']==='overrides'){echo '<details><summary>Optional school fallback relay override</summary><form method="post" class="lp-form"><input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'"><input type="hidden" name="px_action" value="live_settings">';lp_input('turn_url','TURN URL','text','',false);lp_input('turn_secret','Shared secret','password','',false);lp_end('Save school fallback relay');echo '</details>';}px_sfu_settings_view($u);echo '</section><script src="classroom.js?v=533" defer></script>';}

/** A stale tab cannot remove the replacement session for the same user. */
function px_live_leave(array $u,int $id,string $key):void {
 xp_tx(function()use($u,$id,$key){
  $r=q('SELECT * FROM px_live WHERE tenant_id=? AND id=? FOR UPDATE',[$u['tenant_id'],$id])->fetch();
  if(!$r)return;
  $p=q('SELECT user_id FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=?',[$u['tenant_id'],$id,$u['id'],$key])->fetch();
  if(!$p)return;
  if((int)$r['teacher_id']===(int)$u['id']){
   if($r['status']==='starting'){try{px_sfu_close($u,$r);}catch(Throwable $e){error_log('SchoolOS unstarted media-room cleanup failed; no learners admitted.');}}else px_sfu_close($u,$r);
   q("UPDATE px_live SET status='scheduled' WHERE tenant_id=? AND id=? AND status IN ('live','starting')",[$u['tenant_id'],$id]);
   q('DELETE FROM px_peers WHERE tenant_id=? AND lesson_id=?',[$u['tenant_id'],$id]);
   q('DELETE FROM px_signals WHERE tenant_id=? AND lesson_id=?',[$u['tenant_id'],$id]);
  }else q('DELETE FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=?',[$u['tenant_id'],$id,$u['id'],$key]);
 });
}

function px_sfu_config(int $tid):?array {
 $state=px_platform_media_state();
 if($state['policy']==='direct')return null;
 if($state['policy']==='overrides'&&op_has('sv_settings')&&px_media_school_override($tid))return px_school_sfu_config($tid);
 if($state['sfu'])return $state['sfu'];
 // Preserve pre-update school configuration until a platform policy is first saved.
 return $state['policy']==='inherit'?px_school_sfu_config($tid):null;
}
function px_sfu_room(int $tid,int $lesson):string{return 'schoolos-'.substr(hash_hmac('sha256',__DIR__.'|'.(string)g('SELECT DATABASE()').'|'.$tid.'|'.$lesson,v23key()),0,32);}
function px_sfu_jwt(array $config,string $identity,array $grant,int $expires):string {
 $b64=static fn(string $s):string=>rtrim(strtr(base64_encode($s),'+/','-_'),'=');
 $head=$b64(json_encode(['alg'=>'HS256','typ'=>'JWT'],JSON_THROW_ON_ERROR));
 $body=$b64(json_encode(['iss'=>$config['key'],'sub'=>$identity,'nbf'=>time()-5,'exp'=>$expires,'video'=>$grant],JSON_THROW_ON_ERROR));
 return $head.'.'.$body.'.'.$b64(hash_hmac('sha256',$head.'.'.$body,$config['secret'],true));
}
function px_sfu_join(array $u,array $lesson,bool $host):array {
 $config=px_sfu_config((int)$u['tenant_id']);if(!$config)throw new RuntimeException('The scheduled media server is not configured. Ask your school administrator.');
 $room=px_sfu_room((int)$u['tenant_id'],(int)$lesson['id']);
 $grant=['roomJoin'=>true,'room'=>$room,'canSubscribe'=>true,'canPublish'=>$host,'canPublishData'=>false];
 if($host)$grant['canPublishSources']=['camera','microphone','screen_share','screen_share_audio'];
 return ['transport'=>'sfu','serverUrl'=>$config['url'],'token'=>px_sfu_jwt($config,'user-'.$u['id'],$grant,time()+120),'room'=>$room];
}
function px_sfu_close(array $u,array $lesson):void {
 if(($lesson['join_url']??'')!=='schoolos:sfu')return;
 $config=px_sfu_config((int)$u['tenant_id']);if(!$config)throw new RuntimeException('Restore your media server configuration before ending this broadcast.');
 $room=px_sfu_room((int)$u['tenant_id'],(int)$lesson['id']);$token=px_sfu_jwt($config,'schoolos-control',['roomAdmin'=>true,'roomCreate'=>true,'room'=>$room],time()+60);
 $url=preg_replace('~^wss:~','https:',$config['url']);
 $curl=curl_init(rtrim($url,'/').'/twirp/livekit.RoomService/DeleteRoom');
 curl_setopt_array($curl,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>10,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$token,'Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode(['room'=>$room],JSON_THROW_ON_ERROR)]);
 $data=curl_exec($curl);$status=(int)curl_getinfo($curl,CURLINFO_HTTP_CODE);curl_close($curl);
 if($data===false||($status!==200&&!($status===404&&(json_decode($data,true)['code']??'')==='not_found')))throw new RuntimeException('Media server did not confirm classroom shutdown. Check its connection and try End lesson again.');
}
function px_sfu_save_impl(array $u):string {
 if($u['role']!=='school_admin'||defined('SCHOOLOS_DEMO_MODE')||px_platform_media_state()['policy']!=='overrides')throw new RuntimeException('The Platform Super Admin manages the classroom service. School overrides are not enabled.');
 if(g("SELECT l.id FROM px_live l WHERE l.tenant_id=? AND l.provider='schoolos' AND l.ends_at>NOW() AND (l.status='live' OR (l.status='starting' AND EXISTS(SELECT 1 FROM px_peers p WHERE p.tenant_id=l.tenant_id AND p.lesson_id=l.id AND p.last_seen>DATE_SUB(NOW(),INTERVAL 45 SECOND)))) LIMIT 1",[$u['tenant_id']]))throw new RuntimeException('End active built-in broadcasts before changing the school media server.');
 $url=xp_text('sfu_url',500,false);$key=xp_text('sfu_key',150,false);$secret=xp_text('sfu_secret',500,false);
 if(!$url&&!$key&&!$secret)return 'Existing media server settings retained.';
 $parts=parse_url($url);$host=$parts['host']??'';
 if(($parts['scheme']??'')!=='wss'||!preg_match('/^[A-Za-z0-9.-]+$/D',$host)||isset($parts['user'])||isset($parts['pass'])||isset($parts['query'])||isset($parts['fragment'])||!in_array($parts['path']??'',['','/'],true)||!preg_match('/^[A-Za-z0-9_-]{3,150}$/D',$key)||strlen($secret)<24)throw new RuntimeException('Use your LiveKit WSS server URL, API key and API secret (at least 24 characters).');
 sv_save_secret((int)$u['tenant_id'],'classroom_sfu_url',rtrim($url,'/'));sv_save_secret((int)$u['tenant_id'],'classroom_sfu_key',$key);sv_save_secret((int)$u['tenant_id'],'classroom_sfu_secret',$secret);
 sv_save_secret((int)$u['tenant_id'],'classroom_sfu_override','1');px_media_invalidate();audit('learning.media_server.configured');return 'Full-class media server settings saved securely. Test a new lesson before inviting the class.';
}

function px_sfu_settings_view(array $u):void {
 if($u['role']!=='school_admin')return;
 $state=px_platform_media_state();$config=px_sfu_config((int)$u['tenant_id']);
 echo '<section class="px-media-config"><h3>Your classroom service</h3><p>'.($config&&$config['scope']==='platform'?'Managed centrally by the Platform Super Admin. Your school automatically uses the shared service; no separate provider account is required.':($config?'Existing school media server is available.':'Full-class service is not configured. Ask the Platform Super Admin to connect the platform server.')).'</p>';
 if($state['policy']==='overrides'){
 echo '<details><summary>Optional school media-server override</summary><p>The platform allows your school to use its own server. Leave this unset to inherit the shared platform service.</p><form method="post"><input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'"><input type="hidden" name="px_action" value="live_sfu_settings">';
 lp_input('sfu_url','LiveKit-compatible WSS URL','text','',false);lp_input('sfu_key','API key','text','',false);lp_input('sfu_secret','API secret (encrypted)','password','',false);lp_end('Save school override');px_form('live_sfu_inherit','Use central platform service');echo '</details>';
 }echo '</section>';
}
function px_sfu_save(array $u):string{return px_media_lock(fn()=>xp_tx(fn()=>px_sfu_save_impl($u)));}

function px_live_label(array $u,array $lesson):string {
 if($lesson['provider']!=='schoolos')return $lesson['provider'];
 $mode=$lesson['join_url']??'';
 $sfu=$mode==='schoolos:sfu'||($mode===''&&px_sfu_config((int)$u['tenant_id']));
 return $sfu?'SchoolOS Live · media server':'SchoolOS Live · direct fallback (8 people)';
}

function px_live_ready(array $u,int $id,string $key):array {
 return xp_tx(function()use($u,$id,$key){
  q('SELECT id FROM px_live WHERE tenant_id=? AND id=? FOR UPDATE',[$u['tenant_id'],$id]);
  $r=px_live_scope($u,$id,true);
  if((int)$r['teacher_id']!==(int)$u['id']||($r['join_url']??'')!=='schoolos:sfu'||!in_array($r['status'],['starting','live'],true)||!g('SELECT user_id FROM px_peers WHERE tenant_id=? AND lesson_id=? AND user_id=? AND peer_key=? AND last_seen>DATE_SUB(NOW(),INTERVAL 45 SECOND)',[$u['tenant_id'],$id,$u['id'],$key]))throw new RuntimeException('Host broadcast setup expired. Join again.');
  q("UPDATE px_live SET status='live' WHERE tenant_id=? AND id=?",[$u['tenant_id'],$id]);q('UPDATE px_peers SET last_seen=NOW() WHERE tenant_id=? AND lesson_id=? AND user_id=?',[$u['tenant_id'],$id,$u['id']]);
  return ['ready'=>true];
 });
}

function px_live_join(array $u,int $id):array{if(in_array($u['role'],['teacher','school_admin'],true))return px_media_lock(fn()=>px_live_join_impl($u,$id));return px_live_join_impl($u,$id);}

/** Platform-wide media configuration. Secrets stay in the current database's encrypted store. */
function px_media_invalidate():void{unset($GLOBALS['px_platform_media_cache']);}
function px_platform_media_state():array {
 global $pdo;
 $cacheId=spl_object_id($pdo).':'.(string)g('SELECT DATABASE()');
 if(isset($GLOBALS['px_platform_media_cache'][$cacheId]))return $GLOBALS['px_platform_media_cache'][$cacheId];
 $policy=xp_setting('classroom_media_policy','inherit');if(!in_array($policy,['inherit','central','overrides','direct'],true))throw new RuntimeException('Platform classroom policy is invalid. Contact the platform administrator.');
 $secrets=[];
 if(v23ready())foreach(q("SELECT name,cipher FROM v23_secrets WHERE name IN ('classroom_platform_sfu_url','classroom_platform_sfu_key','classroom_platform_sfu_secret','classroom_platform_turn_url','classroom_platform_turn_secret')") as $row){
  $raw=base64_decode($row['cipher'],true);if($raw===false||strlen($raw)<29)throw new RuntimeException('Platform media credential storage is invalid.');
  $plain=openssl_decrypt(substr($raw,28),'aes-256-gcm',v23key(),OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16));if($plain===false)throw new RuntimeException('Restore the matching private encryption key for platform media credentials.');
  $secrets[$row['name']]=$plain;
 }
 $url=$secrets['classroom_platform_sfu_url']??'';$key=$secrets['classroom_platform_sfu_key']??'';$secret=$secrets['classroom_platform_sfu_secret']??'';
 $sfu=null;if($url||$key||$secret){if(!$url||!$key||!$secret)throw new RuntimeException('The central media server configuration is incomplete. Ask the Platform Super Admin to complete it.');$sfu=['url'=>$url,'key'=>$key,'secret'=>$secret,'scope'=>'platform'];}
 $turnUrl=$secrets['classroom_platform_turn_url']??'';$turnSecret=$secrets['classroom_platform_turn_secret']??'';$turn=null;
 if($turnUrl||$turnSecret){if(!$turnUrl||!$turnSecret)throw new RuntimeException('The platform fallback relay configuration is incomplete.');$turn=['url'=>$turnUrl,'secret'=>$turnSecret,'scope'=>'platform'];}
 return $GLOBALS['px_platform_media_cache'][$cacheId]=['policy'=>$policy,'sfu'=>$sfu,'turn'=>$turn];
}
function px_media_school_override(int $tid):bool{return (string)g("SELECT cipher FROM sv_settings WHERE tenant_id=? AND setting_key='classroom_sfu_override'",[$tid])!==''&&(sv_secrets($tid)['classroom_sfu_override']??'')==='1';}
function px_school_sfu_config(int $tid):?array {
 $s=sv_secrets($tid);$url=$s['classroom_sfu_url']??'';$key=$s['classroom_sfu_key']??'';$secret=$s['classroom_sfu_secret']??'';
 if(!$url&&!$key&&!$secret)return null;if(!$url||!$key||!$secret)throw new RuntimeException('Your school media server configuration is incomplete.');
 return ['url'=>$url,'key'=>$key,'secret'=>$secret,'scope'=>'school'];
}
function px_turn_config(int $tid):?array {
 $state=px_platform_media_state();
 if($state['policy']==='overrides'&&op_has('sv_settings')&&px_media_school_override($tid)){$s=sv_secrets($tid);if(!empty($s['classroom_turn_url'])&&!empty($s['classroom_turn_secret']))return ['url'=>$s['classroom_turn_url'],'secret'=>$s['classroom_turn_secret'],'scope'=>'school'];}
 if($state['turn'])return $state['turn'];
 if($state['policy']==='inherit'){$s=sv_secrets($tid);if(!empty($s['classroom_turn_url'])&&!empty($s['classroom_turn_secret']))return ['url'=>$s['classroom_turn_url'],'secret'=>$s['classroom_turn_secret'],'scope'=>'legacy_school'];}
 return null;
}
function px_media_lock(callable $work):mixed {
 $name='schoolos-media-'.substr(hash('sha256',__DIR__.'|'.(string)g('SELECT DATABASE()')),0,30);
 if((int)g('SELECT GET_LOCK(?,5)',[$name])!==1)throw new RuntimeException('Classroom settings are busy. Try again shortly.');
 try{return $work();}finally{q('SELECT RELEASE_LOCK(?)',[$name]);}
}
function px_media_active(int $tid=0):int {
 if(!xp_has('px_live'))return 0;
 return (int)g("SELECT COUNT(*) FROM px_live l WHERE l.provider='schoolos' AND l.ends_at>NOW() AND (l.status='live' OR (l.status='starting' AND EXISTS(SELECT 1 FROM px_peers p WHERE p.tenant_id=l.tenant_id AND p.lesson_id=l.id AND p.last_seen>DATE_SUB(NOW(),INTERVAL 45 SECOND))))".($tid?' AND l.tenant_id=?':''),$tid?[$tid]:[]);
}
function px_media_validate_sfu(array $config):void {
 $parts=parse_url($config['url']);$host=$parts['host']??'';
 if(($parts['scheme']??'')!=='wss'||!preg_match('/^[A-Za-z0-9.-]+$/D',$host)||isset($parts['user'])||isset($parts['pass'])||isset($parts['query'])||isset($parts['fragment'])||!in_array($parts['path']??'',['','/'],true)||!preg_match('/^[A-Za-z0-9_-]{3,150}$/D',$config['key'])||strlen($config['secret'])<24)throw new RuntimeException('Use the LiveKit-compatible WSS server origin, API key and API secret (at least 24 characters). Self-hosted servers are supported; a paid cloud account is not required.');
}
function px_platform_media_save(array $u):string {
 if($u['role']!=='platform_super_admin'||defined('SCHOOLOS_DEMO_MODE'))throw new RuntimeException('Live Platform Super Admin access required.');
 $policy=xp_text('media_policy',20);if(!in_array($policy,['central','overrides','direct'],true))throw new RuntimeException('Choose a valid platform classroom policy.');
 $url=xp_text('sfu_url',500,false);$key=xp_text('sfu_key',150,false);$secret=xp_text('sfu_secret',500,false);$turnUrl=xp_text('turn_url',500,false);$turnSecret=xp_text('turn_secret',500,false);
 return px_media_lock(function()use($u,$policy,$url,$key,$secret,$turnUrl,$turnSecret){
  $active=px_media_active();if($active)throw new RuntimeException('End the '.$active.' active built-in broadcast(s) across all schools before changing shared media settings.');
  $previous=px_platform_media_state();$old=$previous['sfu'];$next=['url'=>$url?:($old['url']??''),'key'=>$key?:($old['key']??''),'secret'=>$secret?:($old['secret']??'')];
  if($url||$key||$secret||$policy!=='direct'){
   if(($url&&$url!==($old['url']??''))||($key&&$key!==($old['key']??'')))if(!$secret)throw new RuntimeException('Re-enter the API secret when changing the server URL or API key.');
   px_media_validate_sfu($next);
  }
  if($turnUrl||$turnSecret)if(!preg_match('~^turns?:[a-zA-Z0-9.-]+:[0-9]{2,5}(\?transport=(udp|tcp))?$~D',$turnUrl)||strlen($turnSecret)<20)throw new RuntimeException('Enter both the fallback TURN URL and its shared secret of at least 20 characters, or leave both blank to keep existing relay settings.');
  xp_tx(function()use($policy,$url,$key,$secret,$next,$turnUrl,$turnSecret){
   if($url||$key||$secret)foreach(['url','key','secret'] as $field)v23save('classroom_platform_sfu_'.$field,$field==='url'?rtrim($next[$field],'/'):$next[$field]);
   if($turnUrl&&$turnSecret){v23save('classroom_platform_turn_url',$turnUrl);v23save('classroom_platform_turn_secret',$turnSecret);}
   q("INSERT INTO xp_config(name,value) VALUES('classroom_media_policy',?) ON DUPLICATE KEY UPDATE value=VALUES(value)",[$policy]);
   q("DELETE FROM xp_config WHERE name='classroom_media_last_test'");
   audit('learning.platform_media.saved','platform',$policy);
  });px_media_invalidate();
  return $policy==='direct'?'Platform classroom policy saved. Full-class media-server mode is disabled; direct fallback and external invitations remain available.':'Central classroom configuration saved. All live schools inherit it automatically unless you explicitly enabled and a school selected an override. No paid media subscription was created.';
 });
}
function px_platform_media_test(array $u):string {
 if($u['role']!=='platform_super_admin'||defined('SCHOOLOS_DEMO_MODE'))throw new RuntimeException('Live Platform Super Admin access required.');
 $state=px_platform_media_state();$config=$state['sfu'];if(!$config)throw new RuntimeException('Save the central media server credentials first.');
 $token=px_sfu_jwt($config,'schoolos-platform-check',['roomList'=>true],time()+60);$url=preg_replace('~^wss:~','https:',$config['url']);
 $curl=curl_init(rtrim($url,'/').'/twirp/livekit.RoomService/ListRooms');$body='';
 curl_setopt_array($curl,[CURLOPT_POST=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>10,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$token,'Content-Type: application/json'],CURLOPT_POSTFIELDS=>'{}',CURLOPT_WRITEFUNCTION=>function($handle,$chunk)use(&$body){if(strlen($body)+strlen($chunk)>262144)return 0;$body.=$chunk;return strlen($chunk);}]);
 $ok=curl_exec($curl);$status=(int)curl_getinfo($curl,CURLINFO_HTTP_CODE);curl_close($curl);$data=json_decode($body,true);
 if($ok===false||$status!==200||!is_array($data)||!is_array($data['rooms']??null))throw new RuntimeException('The central media API test failed. Check the WSS origin, TLS certificate, API key/secret and server access. No classroom was created.');
 q("INSERT INTO xp_config(name,value) VALUES('classroom_media_last_test',?) ON DUPLICATE KEY UPDATE value=VALUES(value)",[date('Y-m-d H:i:s')]);audit('learning.platform_media.tested','platform');
 return 'Central media API connection verified. This read-only test did not create a room. Test real camera/audio on separate networks before inviting schools.';
}
function px_school_media_override(array $u):string {
 if($u['role']!=='school_admin'||defined('SCHOOLOS_DEMO_MODE')||px_platform_media_state()['policy']!=='overrides')throw new RuntimeException('The Platform Super Admin manages the classroom service. School overrides are not enabled.');
 return px_media_lock(function()use($u){if(px_media_active((int)$u['tenant_id']))throw new RuntimeException('End your school broadcasts before changing its media source.');q("DELETE FROM sv_settings WHERE tenant_id=? AND setting_key='classroom_sfu_override'",[$u['tenant_id']]);audit('learning.school_media.inherit');return 'Your school now uses the central platform media server.';});
}
function px_platform_media_view(array $u):void {
 if($u['role']!=='platform_super_admin')return;
 $state=px_platform_media_state();$last=xp_setting('classroom_media_last_test');
 echo '<section class="xp-panel" id="platformLiveClassrooms"><span class="xp-eyebrow">ONE PLATFORM. EVERY SCHOOL.</span><h2>Platform live classrooms</h2><p>Configure one LiveKit-compatible media server for all live schools. Self-hosted LiveKit is free software and uses server capacity/bandwidth you provide. A paid LiveKit Cloud subscription is optional. Schools do not need separate provider accounts or credentials. Each school retains separate lesson rooms and enrollment checks.</p><p>Central server: <strong>'.($state['sfu']?'credentials saved':'not configured').'</strong> · Policy: '.e($state['policy']).'. '.($last?'Last API check: '.e($last).' WAT.':'No saved API check.').'</p>';
 xp_form('platform_media_save','Save platform classroom settings',[
  'media_policy'=>['Media policy',['central'=>'Shared server for every school (recommended)','overrides'=>'Shared server; allow optional school overrides','direct'=>'Disable media-server mode; keep direct/external options'],$state['policy']==='inherit'?'central':$state['policy']],
  'sfu_url'=>['WSS origin, for example wss://live.yourplatform.ng (blank keeps saved)','text','',false],
  'sfu_key'=>['API key (blank keeps saved)','text','',false],
  'sfu_secret'=>['API secret (encrypted; blank keeps saved)','password','',false],
  'turn_url'=>['Optional shared TURN URL for the direct fallback (blank keeps saved)','text','',false],
  'turn_secret'=>['Optional shared TURN secret for the direct fallback','password','',false]
 ]);
 echo '<p>End active built-in broadcasts across all schools before changing the policy or credentials. New classrooms inherit the shared service automatically. Changing an origin/key requires re-entering the secret. The optional direct-fallback TURN relay is separate from the media server’s own relay configuration.</p>';
 xp_form('platform_media_test','Test central media API');
 echo '<details><summary>Free options and shared hosting</summary><p>Self-hosted LiveKit has no software subscription charge. It requires a persistent media server, a trusted TLS certificate and open media ports; an ordinary shared cPanel account generally cannot run that service. A free hosted quota may support a small pilot but has limits. Google Meet invitations are already supported for external free meetings. Read the release research guide before choosing a provider; this update does not purchase infrastructure or promise unlimited free bandwidth.</p></details><p>The isolated public demo does not inherit live-platform credentials. Configure a dedicated demo service separately through the platform operator if needed.</p></section>';
}
